"""Independent bounded preregistration audit; never trains or scores a model.

Reconstructs target pool/schedules, restores12 public baseline inputs, relocates
all actual dependencies and calls the real validator with optimizer/forward
tripwires and an OS file-open audit guard against the original local roots.
"""
import ast
from collections import Counter
import hashlib
import importlib.util
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import stat
import sys
import zipfile

sys.dont_write_bytecode=True
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['OMP_NUM_THREADS']='1'
import numpy as np

ROOT=Path('D:/Codex用')
WORK=ROOT/'work/sle-target-order-20261113'
HERE=WORK/'review'
PREREG=WORK/'prereg'
ORIGINAL=ROOT/'work/sle-ur1-20261113/source'
CODE=ROOT/'outputs/sle-target-order'
PUBLIC=WORK/'publication/prereg-inputs/public'
MANIFEST_SHA='db37000543b4e8e7ef4b294883ad2346fddfd61b771a17857a1c525f1df189cc'
ZIP_SHA='e710b85ca847312c5a4b4d9d4988daa54ee22135519e2fbce0ecc6eeb706c884'
INDEX_SHA='51253e19dd24e69594b5233ec601dac94b30126a9be186d7bced2c3b3191e015'

def canonical(value):
    return json.dumps(value,sort_keys=True,ensure_ascii=False,separators=(',',':'),allow_nan=False)

def sha_bytes(data): return hashlib.sha256(data).hexdigest()
def sha(path): return sha_bytes(path.read_bytes())
def strict_json(text):
    def pairs(items):
        out={}
        for k,v in items:
            assert k not in out,'Duplicate JSON key'
            out[k]=v
        return out
    def bad(v): raise ValueError('Nonfinite JSON')
    return json.loads(text,object_pairs_hook=pairs,parse_constant=bad)
def read(path): return strict_json(path.read_text(encoding='utf-8'))
def git_blob(data): return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
def json_sha(value): return sha_bytes(canonical(value).encode())
def array_sha(value): return sha_bytes(canonical([value.dtype.str,list(value.shape)]).encode()+value.tobytes(order='C'))
def state_sha(state):
    h=hashlib.sha256()
    for k,v in sorted(state.items()):
        h.update(canonical([k,v.dtype.str,list(v.shape)]).encode());h.update(v.tobytes(order='C'))
    return h.hexdigest()
def inventory(folder):
    return {p.relative_to(folder).as_posix():sha(p) for p in sorted(folder.rglob('*')) if p.is_file()}

assert sha(PREREG/'manifest.json')==MANIFEST_SHA
manifest=read(PREREG/'manifest.json')
freeze=read(PREREG/'source-freeze.json')
assert freeze['manifest_sha256']==MANIFEST_SHA
assert manifest['protocol']==read(CODE/'protocol.json')
for name,pin in manifest['local_source_hashes'].items():
    assert sha(CODE/name)==pin
    if name.endswith('.py'): ast.parse((CODE/name).read_text(encoding='utf-8'))
assert manifest['local_source_hashes']['run_target_order.py']=='efd3966a93793d68ee6ba02111bfdcc67f67e8bdf40c96940352d9e5bbe17862'
original_path=ORIGINAL/'experiments/spiral_neural/20261113_pro_notice_learning/frozen_manifest.json'
assert sha(original_path)==manifest['original_manifest_sha256']=='d74dedb0627d79a8c41057a1625a3e83ab3c5b2edfbb675fccd902e94929a7b0'
original=read(original_path)
assert manifest['rows']==original['rows'] and manifest['data_sha256']==json_sha(original['rows'])
for ref,pin in manifest['original_source_hashes'].items(): assert sha(ORIGINAL/ref)==pin

pool=[]
for row in original['rows']:
    if row['split']=='train':
        for i,target in enumerate(row['A']+'S'):
            pool.append({'index':len(pool),'row_id':row['id'],'position':i,'prefix':row['Q']+row['A'][:i],
                         'target':target,'target_n':row['target_n']})
assert pool==manifest['target_pool']==read(PREREG/'target-pool.json') and len(pool)==212
assert json_sha(pool)==manifest['target_pool_sha256'] and sha(PREREG/'target-pool.json')==manifest['target_pool_file_sha256']
assert Counter(x['target_n'] for x in pool)=={4:68,5:68,6:76}
assert sum(x['target']=='S' for x in pool)==12
expected_multiset=Counter((x['prefix'],x['target']) for x in pool)
by_id={r['id']:r for r in original['rows']}
for course in original['curricula'].values():
    for order in course['epochs']:
        assert Counter((by_id[k]['Q']+by_id[k]['A'][:i],target) for k in order for i,target in enumerate(by_id[k]['A']+'S'))==expected_multiset
assert sha(PREREG/'schedules.npz')==manifest['schedules_file_sha256']
orders={}
with np.load(PREREG/'schedules.npz',allow_pickle=False) as archive:
    assert set(archive.files)=={'seed101','seed202','seed303'}
    for seed in (101,202,303):
        value=archive[f'seed{seed}'].copy()
        assert value.shape==(128,212) and value.dtype.str=='<i8'
        rng=np.random.default_rng(seed+81000)
        assert np.array_equal(value,np.stack([rng.permutation(212) for _ in range(128)]))
        h=hashlib.sha256()
        for epoch in value:
            assert np.array_equal(np.sort(epoch),np.arange(212))
            for index in epoch:
                item=pool[int(index)];h.update((canonical([item['prefix'],item['target']])+'\n').encode())
        desc=manifest['schedules'][str(seed)]
        assert desc['array_sha256']==array_sha(value) and desc['orders_json_sha256']==json_sha(value.tolist())
        assert desc['raw_teacher_target_stream_sha256']==h.hexdigest()==freeze['schedule_stream_sha256'][str(seed)]
        assert desc['final_schedule_RNG']==rng.bit_generator.state
        orders[f'seed{seed}']=value

assert sha(PUBLIC/'baseline-inputs.zip')==ZIP_SHA and sha(PUBLIC/'baseline-inputs-manifest.json')==INDEX_SHA
index=read(PUBLIC/'baseline-inputs-manifest.json')
arc=index['archives'][0]
assert len(index['archives'])==1 and arc['entry_count']==12 and arc['sha256']==ZIP_SHA
assert git_blob((PUBLIC/'baseline-inputs.zip').read_bytes())==arc['Git_blob']
expected_inputs=manifest['control']['input_hashes']
expected_names={'manifest.json','summary.json','codex-execution-provenance.json'}|{
    f'seed{seed}/{name}' for seed in (101,202,303) for name in ('initial-state.npz','curve.json','offline-curve.json')}
assert set(expected_inputs)==expected_names and len(expected_names)==12
assert {e['path'] for e in arc['entries']}=={'baseline/'+n for n in expected_names}
fresh=HERE/'portable-restore'
fresh.mkdir(parents=True,exist_ok=False)
entries={e['path']:e for e in arc['entries']}
with zipfile.ZipFile(PUBLIC/'baseline-inputs.zip') as archive:
    assert set(archive.namelist())==set(entries) and len(archive.infolist())==12
    assert sum(info.file_size for info in archive.infolist())<4*1024*1024
    for info in archive.infolist():
        name=PurePosixPath(info.filename)
        assert not name.is_absolute() and '..' not in name.parts and '\\' not in info.filename
        assert stat.S_IFMT(info.external_attr>>16)!=stat.S_IFLNK and info.file_size<2*1024*1024
        payload=archive.read(info)
        entry=entries[info.filename]
        assert len(payload)==entry['bytes'] and sha_bytes(payload)==entry['sha256']==expected_inputs[info.filename.removeprefix('baseline/')]
        assert git_blob(payload)==entry['Git_blob']
        target=fresh.joinpath(*name.parts)
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(payload)
        if target.suffix=='.json': strict_json(payload.decode('utf-8'))

fresh_source=fresh/'source'
for ref in manifest['original_source_hashes']:
    target=fresh_source/ref;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ORIGINAL/ref,target)
target=fresh_source/'experiments/spiral_neural/20261113_pro_notice_learning/frozen_manifest.json'
shutil.copyfile(original_path,target)
fresh_code=fresh/'code';fresh_code.mkdir()
for name in manifest['local_source_hashes']: shutil.copyfile(CODE/name,fresh_code/name)
fresh_prereg=fresh/'prereg';fresh_prereg.mkdir()
for path in PREREG.iterdir():
    assert path.is_file() and path.name in {'manifest.json','source-freeze.json','target-pool.json','schedules.npz',
                    'initial-state-seed101.npz','initial-state-seed202.npz','initial-state-seed303.npz'}
    shutil.copyfile(path,fresh_prereg/path.name)

initials=[]
for seed in (101,202,303):
    baseline=fresh/f'baseline/seed{seed}/initial-state.npz'
    copied=fresh_prereg/manifest['control']['students'][str(seed)]['initial_file']
    assert sha(copied)==sha(baseline)==expected_inputs[f'seed{seed}/initial-state.npz']
    with np.load(copied,allow_pickle=False) as archive:
        state={k:archive[k].copy() for k in archive.files}
    assert len(state)==25 and state_sha(state)==manifest['control']['students'][str(seed)]['initial_state_sha256']
    assert int(state['t'])==int(state['meta_train_macs'])==int(state['meta_inference_macs'])==int(state['meta_inference_calls'])==0
    assert int(state['meta_seed'])==seed and (int(state['L']),int(state['H']))==(80,64)
    assert str(state['meta_events'])=='[]'
    for key,value in state.items():
        if value.dtype.kind in 'fciub': assert np.isfinite(value).all()
        assert value.dtype.kind!='O'
    for label in ('m','v','birth'):
        assert all(not np.any(state[f'{label}{i}']) for i in range(4))
    assert sum(state[f'{label}{i}'].nbytes for label in ('p','m','v','birth') for i in range(4))==209980
    initials.append({'seed':seed,'raw_sha256':sha(copied),'full_state_sha256':state_sha(state)})

before=inventory(fresh)
protected=[(ROOT/'work/sle-ur1-20261113').resolve(),PREREG.resolve(),CODE.resolve()]
guard_enabled=True
blocked=[]
def open_guard(event,args):
    if guard_enabled and event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
        path=Path(os.fsdecode(args[0])).resolve()
        if any(path.is_relative_to(root) for root in protected):
            blocked.append(str(path));raise AssertionError('Original local dependency access forbidden')
sys.addaudithook(open_guard)
spec=importlib.util.spec_from_file_location('independent_relocated_target_order',fresh_code/'run_target_order.py')
driver=importlib.util.module_from_spec(spec);sys.modules[spec.name]=driver;spec.loader.exec_module(driver)
loaded=driver.load_original(fresh_source)
forbidden_calls=[]
def no_science(*args,**kwargs):
    forbidden_calls.append(1);raise AssertionError('Optimizer/forward/evaluation forbidden in preregistration audit')
for name in ('step','lesson','loss_grad','forward','generate'):
    setattr(loaded['learner'].reference.Model,name,no_science)
loaded['learner'].evaluate=no_science
loaded['learner'].generate=no_science
_,validated,actual_orders=driver.validate_manifest(fresh_source,fresh/'baseline',fresh_prereg/'manifest.json',MANIFEST_SHA)
assert validated==manifest and not blocked and not forbidden_calls
for key,value in actual_orders.items(): assert np.array_equal(value,orders[key])
try:
    (ROOT/'work/sle-ur1-20261113/science/summary.json').open('rb')
except AssertionError:
    assert len(blocked)==1
else:
    raise AssertionError('Original-root tripwire did not reject test access')
guard_enabled=False
assert inventory(fresh)==before
assert sha(PREREG/'manifest.json')==MANIFEST_SHA
for name,pin in manifest['local_source_hashes'].items(): assert sha(CODE/name)==pin
engineering=read(WORK/'engineering/checks.json')
assert engineering['status']=='PASS' and engineering['formal_student_updates']==0 and engineering['formal_heldout_neural_evaluations']==0
assert engineering['local_source_hashes']==manifest['local_source_hashes']

result={'status':'passed','manifest_sha256':MANIFEST_SHA,
        'launcher_sha256':manifest['local_source_hashes']['run_target_order.py'],
        'source_hashes':manifest['local_source_hashes'],'original_source_hashes':manifest['original_source_hashes'],
        'sole_variable':'Within-epoch order of the same212 teacher-prefix/target occurrences.',
        'pool_occurrences':212,'epochs_per_seed':128,'schedules_verified':[101,202,303],
        'all384epochs_multisets_and_exact_frozen_RNG_orders_verified':True,
        'same_initial_raw_bytes_and_all_state_exact':initials,
        'baseline_package_sha256':ZIP_SHA,'baseline_package_index_sha256':INDEX_SHA,
        'baseline_public_inputs':12,'portable_restored_validation':'passed',
        'relocated_input_files_unchanged':len(before),'original_roots_read_during_validation':0,
        'optimizer_forward_or_evaluation_calls':0,'formal_students_started':0,'external_model_calls':0,
        'scientific_review':{'same_original7source_and_raw_interface':True,'same_optimizer_weights_budget':True,
          'targets_per_seed':27136,'training_dense_MAC_per_seed':571375616,
          'heldout_training_targets':0,'all3primary_then3replays_before_offline_heldout':True,
          'fixed_endpoints_no_selection_or_extension':True,'heldout_is_exposed_diagnostic':True,
          'primary_endpoint':'Final train whole/address and per-seed paired control differences;96/128 stability retained.',
          'control_role':'Reuse audited Windows replication metadata, not new independent control evidence.'},
        'resolved_findings':[{'severity':'P1','issue':'Unpublished69-file local baseline dependency with only3 initial copies.',
                              'resolution':'Exactly12 required public raw inputs; restored ZIP plus relocated source/prereg validated with original roots blocked.'}],
        'material_findings_remaining':[],
        'engineering_updates_reported_by_implementer':{'dev01':7,'final':7,'total':14},
        'required_root_pre_formal_gate':'Commit and verify exact protocol/driver/manifest/schedules/three initial states plus baseline ZIP/index before the one formal run; do not retrain the fixed control.',
        'evidence':'review/pre-run-details.json'}
details={'status':'passed','manifest_sha256':MANIFEST_SHA,'restored_file_hashes':before,
         'initial_states':initials,'schedules':manifest['schedules'],'public_baseline_entries':arc['entries'],
         'tripwire_expected_negative_cases':1,'optimizer_or_forward_tripwire_calls':0,
         'driver_validator_called':True,'formal_optimizer_calls':0,'new_model_calls':0}
for path,value in ((HERE/'pre-run-details.json',details),(HERE/'pre-run.json',result)):
    with path.open('x',encoding='utf-8',newline='\n') as stream:
        json.dump(value,stream,ensure_ascii=False,indent=2,allow_nan=False);stream.write('\n')
print(canonical({'status':'passed','manifest_sha256':MANIFEST_SHA,'baseline_inputs':12,
                 'relocated_files':len(before),'optimizer_or_forward_calls':0,'output':str(HERE/'pre-run.json')}))
