"""Independent target-order artifact audit; no scientific imports or optimizer.

Only run after root confirms the unique formal process exited0. Independently
implements the frozen two-channel tanh forward for fixed checkpoint inference.
It never calls Model, step, lesson, loss_grad, a worker, or an external service.
"""
from __future__ import annotations
import argparse
from collections import Counter
from datetime import datetime, timezone
import gzip
import hashlib
from itertools import zip_longest
import json
import math
import os
from pathlib import Path
import platform
import re
import sys
import time

sys.dont_write_bytecode=True
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['OMP_NUM_THREADS']='1'
import numpy as np

HERE=Path(__file__).resolve().parent
MANIFEST_SHA='db37000543b4e8e7ef4b294883ad2346fddfd61b771a17857a1c525f1df189cc'
LAUNCHER_SHA='efd3966a93793d68ee6ba02111bfdcc67f67e8bdf40c96940352d9e5bbe17862'
CLAIM='042bb1097a63da9b39d2d30cc63843d4467c4b83'
HEAD='19ece2819c6c2c1d7ef9fdb2389efaa045b1c35e'
CONTROL_MANIFEST_SHA='d74dedb0627d79a8c41057a1625a3e83ab3c5b2edfbb675fccd902e94929a7b0'
L,H,CAP=80,64,24
FORWARD_MAC=2*L*H+3*H
TRAIN_MAC=4*L*H+9*H
POINTS=(0,16,32,64,96,128)
ARRAY_KEYS={f'{label}{i}' for label in ('p','m','v','birth') for i in range(4)}
ALL_STATE_KEYS=ARRAY_KEYS|{'t','L','H','growth_rng','meta_seed','meta_train_macs',
                        'meta_inference_macs','meta_inference_calls','meta_events'}

def require(ok,message):
    if not ok: raise AssertionError(message)

def canonical(value):
    return json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False)

def strict_json(text):
    def pairs(items):
        out={}
        for key,value in items:
            require(key not in out,'duplicate JSON key')
            out[key]=value
        return out
    def bad(value): raise ValueError('nonfinite JSON value')
    return json.loads(text,object_pairs_hook=pairs,parse_constant=bad)

def read(path):
    require(path.stat().st_size<=16*1024*1024,'JSON file exceeds audit bound')
    return strict_json(path.read_text(encoding='utf-8-sig'))

def file_sha(path):
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''): h.update(block)
    return h.hexdigest()

def json_sha(value):
    return hashlib.sha256(canonical(value).encode()).hexdigest()

def inventory(folder):
    return {p.relative_to(folder).as_posix():{'bytes':p.stat().st_size,'sha256':file_sha(p)}
            for p in sorted(folder.rglob('*')) if p.is_file()}

def difference(actual,expected,path='root'):
    if type(actual) is not type(expected): return path+': types '+type(actual).__name__+'/'+type(expected).__name__
    if isinstance(actual,dict):
        if actual.keys()!=expected.keys(): return path+': keys differ'
        for k in actual:
            if actual[k]!=expected[k]: return difference(actual[k],expected[k],path+'.'+k)
    elif isinstance(actual,list):
        if len(actual)!=len(expected): return path+': lengths differ'
        for i,(a,b) in enumerate(zip(actual,expected)):
            if a!=b: return difference(a,b,path+f'[{i}]')
    elif actual!=expected: return path+': '+repr(actual)+' / '+repr(expected)
    return path+': values compare equal'

def equal(actual,expected,label):
    require(actual==expected,label+' '+difference(actual,expected))

def load_state(path,seed,epoch):
    with np.load(path,allow_pickle=False) as archive:
        require(set(archive.files)==ALL_STATE_KEYS,'checkpoint state fields '+path.name)
        state={k:archive[k].copy() for k in archive.files}
    shapes=((2*L,H),(H,),(H,3),(3,))
    for label in ('p','m','v','birth'):
        for i,shape in enumerate(shapes):
            value=state[label+str(i)]
            require(value.shape==shape,'state shape '+path.name)
            require(value.dtype==(np.int64 if label=='birth' else np.float32),'state dtype '+path.name)
            require(bool(np.isfinite(value).all()),'nonfinite checkpoint '+path.name)
            if label=='birth': require(not np.any(value),'unexpected nonzero birth in fixed-capacity trial')
            if label=='v': require(bool((value>=0).all()),'negative Adam second moment')
    require(sum(state[k].nbytes for k in ARRAY_KEYS)==209980,'p/m/v/birth bytes')
    require((int(state['L']),int(state['H']),int(state['meta_seed']))==(L,H,seed),'checkpoint shape/seed')
    require(int(state['t'])==epoch*212,'checkpoint target count')
    require(int(state['meta_train_macs'])==int(state['t'])*TRAIN_MAC,'checkpoint training MAC')
    require(int(state['meta_inference_macs'])==int(state['meta_inference_calls'])*FORWARD_MAC,'checkpoint inference counter')
    require(str(state['meta_events'])=='[]','unexpected capacity event')
    equal(json.loads(str(state['growth_rng'])),np.random.default_rng(seed+73000).bit_generator.state,'unchanged growth RNG')
    for value in state.values(): value.setflags(write=False)
    return state

def same_arrays(actual,expected,label):
    require(actual.keys()==expected.keys(),label+' keys')
    for k in actual:
        require(actual[k].dtype==expected[k].dtype and actual[k].shape==expected[k].shape
                and np.array_equal(actual[k],expected[k]),label+' '+k)

def state_sha(state):
    result=hashlib.sha256()
    for name,value in sorted(state.items()):
        result.update(canonical([name,value.dtype.str,list(value.shape)]).encode())
        result.update(value.tobytes(order='C'))
    return result.hexdigest()

def with_prior_inference(state,calls):
    revised=dict(state)
    for key,value in (('meta_inference_calls',calls),('meta_inference_macs',calls*FORWARD_MAC)):
        revised[key]=np.array(value,dtype=state[key].dtype)
    return revised

class ReadOnlyForward:
    def __init__(self,state):
        self.weights=tuple(state['p'+str(i)] for i in range(4))
        self.calls=0
    def logits(self,prefix):
        require(isinstance(prefix,str) and 0<len(prefix)<=L and set(prefix)<=set('01'),'independent raw binary prefix')
        slots=np.zeros((L,2),dtype=np.float32)
        for position,bit in enumerate(prefix): slots[position,0 if bit=='0' else 1]=1
        x=slots.reshape(1,2*L)
        w1,b1,w2,b2=self.weights
        hidden=np.tanh(x@w1+b1)
        self.calls+=1
        return (hidden@w2+b2)[0]
    def generate(self,q):
        tokens=''
        steps=[]
        for _ in range(CAP):
            prefix=q+tokens
            if len(prefix)>L: return tokens,True,False,steps
            logits=self.logits(prefix)
            token='01S'[int(np.argmax(logits))]
            steps.append({'prefix':prefix,'prediction':token,'logits':logits.tolist()})
            tokens+=token
            if token=='S': return tokens,False,False,steps
        return tokens,False,True,steps
    def evaluate(self,rows):
        output=[]
        for row in rows:
            q,a=row['Q'],row['A']
            actual,overflow,exhausted,steps=self.generate(q)
            expected=a+'S'
            tf=[]
            for position,target in enumerate(expected):
                logits=self.logits(q+a[:position]).astype(np.float64)
                lp=logits-np.logaddexp.reduce(logits)
                tf.append({'position':position,'target':target,'prediction':'01S'[int(np.argmax(logits))],
                           'logits':logits.tolist(),'probabilities_01S':np.exp(lp).tolist(),
                           'target_CE':-float(lp['01S'.index(target)])})
            naddr=len(row['address_bits'])
            first=next((i for i,(left,right) in enumerate(zip_longest(actual,expected)) if left!=right),None)
            output.append({'id':row['id'],'split':row['split'],'path':row['path'],'target_n':row['target_n'],
                           'Q':q,'target':expected,'generated':actual,'whole_correct':actual==expected,
                           'address_correct':actual[:naddr]==row['address_bits'],
                           'UP_correct_at_expected_position':actual[naddr:len(a)]==row['up_bits'],
                           'STOP_position_correct':actual.endswith('S') and len(actual)==len(expected),
                           'first_error_position_zero_based':first,'overflow':overflow,'cap_exhausted':exhausted,
                           'teacher_forcing':tf,'free_run':steps})
        return output

def metrics(truth):
    out={}
    for split in ('train','heldout'):
        rows=[r for r in truth if r['split']==split]
        if not rows: continue
        targets=[t for row in rows for t in row['teacher_forcing']]
        out[split]={'total':len(rows),**{key:sum(bool(row[key]) for row in rows) for key in
                    ('whole_correct','address_correct','UP_correct_at_expected_position','STOP_position_correct','overflow','cap_exhausted')},
                    'teacher_targets':len(targets),'teacher_correct':sum(t['prediction']==t['target'] for t in targets),
                    'teacher_CE_mean':sum(t['target_CE'] for t in targets)/len(targets)}
    return out

def inference_calls(truth):
    return sum(len(r['free_run'])+len(r['teacher_forcing']) for r in truth)

def expected_targets(manifest,orders,seed):
    for epoch,order in enumerate(orders[f'seed{seed}'],1):
        for ordinal,index in enumerate(order):
            yield epoch,ordinal,manifest['target_pool'][int(index)]

def audit_trace(folder,manifest,orders,seed,training_summary,curve):
    path=folder/'targets.jsonl.gz'
    h=hashlib.sha256()
    raw_targets=hashlib.sha256()
    anchors={}
    boundaries={epoch*212 for epoch in POINTS if epoch}|{epoch*212+1 for epoch in POINTS[:-1]}
    per_epoch=Counter()
    per_width=Counter()
    fields={'epoch','epoch_target_ordinal_zero_based','pool_index','row_id','position','prefix','target','prediction','loss',
            'global_update','train_dense_MAC','inference_calls','inference_dense_MAC','full_state_sha256'}
    checkpoint_calls={row['epoch']:row['inference_calls'] for row in curve}
    count=0
    with gzip.open(path,'rb') as stream:
        for count,(epoch,ordinal,item) in enumerate(expected_targets(manifest,orders,seed),1):
            prefix,target=item['prefix'],item['target']
            line=stream.readline(8193)
            require(line and len(line)<=8192 and line.endswith(b'\n'),'target line framing')
            value=strict_json(line.decode('utf-8'))
            require(set(value)==fields,'target record fields')
            require(line==(canonical(value)+'\n').encode(),'target canonical stream')
            require((value['epoch'],value['epoch_target_ordinal_zero_based'],value['pool_index'],value['row_id'],value['position'],value['prefix'],value['target'])==
                    (epoch,ordinal,item['index'],item['row_id'],item['position'],prefix,target),'target order/teacher-prefix mismatch at '+str(count))
            require(type(value['global_update']) is int and value['global_update']==count,'target update ordinal')
            require(type(value['train_dense_MAC']) is int and value['train_dense_MAC']==count*TRAIN_MAC,'target MAC counter')
            previous=max(point for point in POINTS if point<epoch)
            calls=checkpoint_calls[previous]
            require(value['inference_calls']==calls and value['inference_dense_MAC']==calls*FORWARD_MAC,'target diagnostic counter includes engineering or missing probes')
            require(value['prediction'] in ('0','1','S'),'target prediction alphabet')
            require(type(value['loss']) in (int,float) and math.isfinite(value['loss']) and value['loss']>=0,'target finite loss')
            require(isinstance(value['full_state_sha256'],str) and re.fullmatch('[0-9a-f]{64}',value['full_state_sha256']),'target state hash format')
            h.update(line)
            raw_targets.update((canonical([prefix,target])+'\n').encode())
            per_epoch[epoch]+=1
            per_width[item['target_n']]+=1
            if count in boundaries: anchors[count]=value
        require(not stream.read(1),'extra target records')
    require(count==27136 and per_epoch==Counter({epoch:212 for epoch in range(1,129)}),'full fixed target coverage')
    require(dict(per_width)=={4:8704,5:8704,6:9728},'width exposure ledger')
    equal(training_summary['trace'],{'targets':count,'uncompressed_stream_sha256':h.hexdigest()},'target stream digest')
    require(training_summary['trace_file_sha256']==file_sha(path),'gzip file digest')
    require(raw_targets.hexdigest()==manifest['schedules'][str(seed)]['raw_teacher_target_stream_sha256'],'actual teacher stream versus frozen manifest')
    return {'targets':count,'uncompressed_sha256':h.hexdigest(),'gzip_sha256':file_sha(path),
            'teacher_stream_sha256':raw_targets.hexdigest(),'width_target_exposures':dict(per_width)},anchors

def paired_difference(score,control):
    return {'train_whole_correct':score['train']['whole_correct']-control['train']['whole_correct'],
            'train_address_correct':score['train']['address_correct']-control['train']['address_correct'],
            'heldout_whole_correct_diagnostic':score['heldout']['whole_correct']-control['heldout']['whole_correct']}

def audit_seed(science,manifest,orders,prereg,seed):
    folder=science/f'seed{seed}'
    summary=read(folder/'training-summary.json')
    require(summary['seed']==seed and summary['targets']==27136 and summary['epochs']==128 and summary['author']=='Codex','seed training metadata')
    require(summary['parameters']==10499 and summary['training_dense_MAC']==571375616,'seed cost/size')
    train_curve=read(folder/'curve.json')
    trace,anchors=audit_trace(folder,manifest,orders,seed,summary,train_curve)
    initial=load_state(folder/'initial-state.npz',seed,0)
    initial_pin=manifest['control']['input_hashes'][f'seed{seed}/initial-state.npz']
    require(file_sha(folder/'initial-state.npz')==initial_pin==file_sha(prereg/manifest['control']['students'][str(seed)]['initial_file']),'exact frozen control initial raw NPZ')
    require(state_sha(initial)==manifest['control']['students'][str(seed)]['initial_state_sha256'],'complete control initial state')
    require(int(initial['meta_inference_calls'])==0,'initial inference counter')
    rng=np.random.default_rng(seed)
    expected_p0=rng.normal(0,.2,(2*L,H)).astype(np.float32)
    expected_p2=rng.normal(0,.15,(H,3)).astype(np.float32)
    require(np.array_equal(initial['p0'],expected_p0) and np.array_equal(initial['p2'],expected_p2),'initialization fixed seed')
    for key in ('p1','p3',*[f'{label}{i}' for label in ('m','v','birth') for i in range(4)]):
        require(not np.any(initial[key]),'initial zero '+key)
    offline_curve=read(folder/'offline-curve.json')
    require(len(train_curve)==len(offline_curve)==6,'six fixed checkpoint points')
    old_calls=0
    audit_calls=0
    points=[]
    state_anchors=0
    prediction_loss_anchors=0
    final_state=None
    final_metrics=None
    final_truth=None
    for index,epoch in enumerate(POINTS):
        path=folder/f'state-{epoch:03}.npz'
        state=load_state(path,seed,epoch)
        before=state_sha(state)
        inference=ReadOnlyForward(state)
        truth=inference.evaluate(manifest['rows'])
        require(inference.calls==inference_calls(truth),'independent forward count')
        audit_calls+=inference.calls
        require(state_sha(state)==before,'audit changed checkpoint arrays')
        train_truth=[r for r in truth if r['split']=='train']
        train_calls=inference_calls(train_truth)
        require(int(state['meta_inference_calls'])==old_calls+train_calls,'training diagnostic checkpoint counter')
        pre_diagnostic=with_prior_inference(state,old_calls)
        if epoch==0:
            same_arrays(pre_diagnostic,initial,'checkpoint0 versus initial boundary')
            require(before==manifest['control']['students'][str(seed)]['checkpoint_full_state_sha256']['0'],'same initial diagnostic checkpoint as control')
        else:
            require(state_sha(pre_diagnostic)==anchors[epoch*212]['full_state_sha256'],'last target versus checkpoint state anchor')
        state_anchors+=1
        if epoch<128:
            next_record=anchors[epoch*212+1]
            row=next(r for r in truth if r['id']==next_record['row_id'])
            position=next_record['position']
            require(next_record['prediction']==row['teacher_forcing'][position]['prediction']
                    and next_record['loss']==row['teacher_forcing'][position]['target_CE'],'checkpoint-to-next-update prediction/loss anchor')
            prediction_loss_anchors+=1
        old_calls=int(state['meta_inference_calls'])
        equal(read(folder/f'train-truth-{epoch:03}.json'),train_truth,'complete train truth '+str((seed,epoch)))
        expected_train_curve={'epoch':epoch,'target_updates':epoch*212,'training_dense_MAC':epoch*212*TRAIN_MAC,
                              'metrics':metrics(train_truth),'state_sha256':before,
                              'inference_calls':int(state['meta_inference_calls']),'inference_dense_MAC':int(state['meta_inference_macs'])}
        equal(train_curve[index],expected_train_curve,'training curve '+str((seed,epoch)))
        truth_name='final-truth.json' if epoch==128 else f'offline-truth-{epoch:03}.json'
        equal(read(folder/truth_name),truth,'complete independent free/TF/logits/probabilities/CE truth '+str((seed,epoch)))
        scores=metrics(truth)
        control=manifest['control']['students'][str(seed)]['points'][str(epoch)]
        expected_offline={'epoch':epoch,'target_updates':epoch*212,'training_dense_MAC':epoch*212*TRAIN_MAC,
                          'metrics':scores,'fixed_control_metrics':control,'paired_difference':paired_difference(scores,control),
                          'truth_file':truth_name,'checkpoint_file':path.name,
                          'checkpoint_sha256':file_sha(path),'diagnostic_inference_calls':inference.calls,
                          'diagnostic_dense_MAC':inference.calls*FORWARD_MAC}
        equal(offline_curve[index],expected_offline,'offline curve '+str((seed,epoch)))
        points.append({'epoch':epoch,'checkpoint_sha256':file_sha(path),'full_state_sha256':before,
                       'independent_truth_sha256':json_sha(truth),'train_whole':scores['train']['whole_correct'],
                       'heldout_whole':scores['heldout']['whole_correct'],'independent_forward_calls':inference.calls,
                       'train_probe_calls_subset':train_calls,'paired_difference':paired_difference(scores,control)})
        if epoch==128: final_state,final_metrics,final_truth=state,scores,truth
    final_archive=load_state(folder/'final-state.npz',seed,128)
    same_arrays(final_state,final_archive,'final-state versus checkpoint128')
    require(summary['state_sha256']==state_sha(final_state),'final fullstate summary digest')
    require(summary['training_diagnostic_inference_calls']==old_calls and summary['training_diagnostic_dense_MAC']==old_calls*FORWARD_MAC,'training diagnostic summary')
    require(summary['p_m_v_birth_array_bytes']==209980,'final parameter/moment/birth memory')
    equal(read(folder/'final-failures.json'),[r for r in final_truth if not r['whole_correct']],'all final failures retained')
    strong=final_metrics['train']['whole_correct']==final_metrics['train']['address_correct']==12
    expected_student={'seed':seed,'metrics':final_metrics,'strong_fit_gate':strong,
                      'paired_difference':offline_curve[-1]['paired_difference'],
                      'stability':[point for point in offline_curve if point['epoch'] in (96,128)],
                      'offline_diagnostic_inference_calls':audit_calls,'offline_diagnostic_dense_MAC':audit_calls*FORWARD_MAC,
                      'final_state_sha256':file_sha(folder/'final-state.npz')}
    return expected_student,{'seed':seed,'trace':trace,'checkpoint_count':6,'archives_loaded':8,
           'state_boundary_anchors':state_anchors,'pre_update_prediction_loss_anchors':prediction_loss_anchors,
           'training_diagnostic_calls':old_calls,'training_diagnostic_dense_MAC':old_calls*FORWARD_MAC,
           'independent_forward_calls':audit_calls,'independent_forward_dense_MAC':audit_calls*FORWARD_MAC,
           'points':points,'final_failure_count':sum(not r['whole_correct'] for r in final_truth)}

def check_inputs(prereg,source,code,baseline):
    require(file_sha(prereg/'manifest.json')==MANIFEST_SHA,'frozen target-order manifest bytes')
    manifest=read(prereg/'manifest.json')
    require(read(prereg/'source-freeze.json')['manifest_sha256']==MANIFEST_SHA,'preregistration source-freeze')
    for name,pin in manifest['local_source_hashes'].items(): require(file_sha(code/name)==pin,'new source '+name)
    require(manifest['local_source_hashes']['run_target_order.py']==LAUNCHER_SHA,'approved driver SHA')
    for name,pin in manifest['original_source_hashes'].items(): require(file_sha(source/name)==pin,'unchanged original source '+name)
    original_path=source/'experiments/spiral_neural/20261113_pro_notice_learning/frozen_manifest.json'
    require(file_sha(original_path)==CONTROL_MANIFEST_SHA,'original manifest')
    original=read(original_path)
    equal(read(baseline/'manifest.json'),original,'public fixed-control manifest')
    for name,pin in manifest['control']['input_hashes'].items(): require(file_sha(baseline/name)==pin,'public baseline input '+name)
    require(len(manifest['control']['input_hashes'])==12,'exact12 portable control inputs')
    pool=[]
    for row in original['rows']:
        if row['split']=='train':
            for i,target in enumerate(row['A']+'S'):
                pool.append({'index':len(pool),'row_id':row['id'],'position':i,'prefix':row['Q']+row['A'][:i],
                             'target':target,'target_n':row['target_n']})
    require(len(pool)==212 and sum(x['target']=='S' for x in pool)==12,'pool size/STOP count')
    equal(pool,manifest['target_pool'],'complete unchanged training target pool')
    equal(read(prereg/'target-pool.json'),pool,'saved pool')
    require(json_sha(pool)==manifest['target_pool_sha256'] and file_sha(prereg/'target-pool.json')==manifest['target_pool_file_sha256'],'pool logical/raw SHA')
    expected=Counter((x['prefix'],x['target']) for x in pool)
    by_id={r['id']:r for r in original['rows']}
    for course in original['curricula'].values():
        for order in course['epochs']:
            require(Counter((by_id[k]['Q']+by_id[k]['A'][:i],target) for k in order for i,target in enumerate(by_id[k]['A']+'S'))==expected,'control epoch multiset')
    require(file_sha(prereg/'schedules.npz')==manifest['schedules_file_sha256'],'frozen schedule NPZ bytes')
    orders={}
    with np.load(prereg/'schedules.npz',allow_pickle=False) as archive:
        require(set(archive.files)=={'seed101','seed202','seed303'},'all three schedules')
        for seed in (101,202,303):
            value=archive[f'seed{seed}'].copy()
            require(value.shape==(128,212) and value.dtype.str=='<i8','frozen schedule shape/dtype')
            rng=np.random.default_rng(seed+81000)
            require(np.array_equal(value,np.stack([rng.permutation(212) for _ in range(128)])),'independent schedule RNG')
            h=hashlib.sha256()
            for epoch in value:
                require(np.array_equal(np.sort(epoch),np.arange(212)),'epoch full permutation')
                for index in epoch:
                    item=pool[int(index)];h.update((canonical([item['prefix'],item['target']])+'\n').encode())
            desc=manifest['schedules'][str(seed)]
            require(h.hexdigest()==desc['raw_teacher_target_stream_sha256'],'frozen target stream')
            require(desc['final_schedule_RNG']==rng.bit_generator.state,'schedule RNG final state')
            orders[f'seed{seed}']=value
    return manifest,orders

def run(args):
    require(args.root_confirmed_exit0,'Root exit0 confirmation is required before loading a new checkpoint')
    require(args.preregistration_commit==CLAIM,'actual root-verified preregistration commit')
    science=args.formal_root.resolve(strict=True)
    source=args.source_root.resolve(strict=True)
    prereg=args.prereg_root.resolve(strict=True)
    code=args.code_root.resolve(strict=True)
    baseline=args.baseline_root.resolve(strict=True)
    output=args.output_root.resolve()
    require(not any(output.is_relative_to(p) for p in (science,prereg,baseline)),'audit output must not change scientific inputs')
    output.mkdir(parents=True,exist_ok=True)
    started=time.perf_counter()
    require(not any(n in sys.modules for n in ('learner','dataset','run_trial','run_target_order')),'scientific module imported')
    summary=read(science/'summary.json')
    require(summary['status']=='complete' and summary['complete_trajectories']==summary['exact_replays']==3,'all fixed trajectories not complete')
    require(not (science/'failure.json').exists(),'formal failure artifact')
    require(summary['manifest_sha256']==MANIFEST_SHA and summary['author']=='Codex','actual new execution identity')
    receipt=read(args.formal_receipt)
    require(receipt['status']=='complete' and receipt['exit_code']==0 and receipt['session_id']==25437,'actual unique formal process exit receipt')
    require(receipt['manifest_sha256']==MANIFEST_SHA and receipt['driver_sha256']==LAUNCHER_SHA and receipt['preregistration_commit']==CLAIM,'formal receipt frozen identity')
    require(receipt['authorized_formal_launches']==1 and receipt['auto_retry'] is False,'one authorized formal launch')
    start=read(science/'execution-start.json')
    require(start['formal_started'] and start['manifest_sha256']==MANIFEST_SHA and start['auto_retry'] is False,'formal start receipt')
    require((platform.python_version(),np.__version__)==('3.12.14','2.3.5'),'audit runtime')
    manifest,orders=check_inputs(prereg,source,code,baseline)
    equal(read(science/'manifest.json'),manifest,'formal manifest versus approved preregistration')
    equal(start['runtime'],manifest['runtime'],'actual frozen runtime')
    before_files=inventory(science)
    before_prereg=inventory(prereg)
    before_baseline=inventory(baseline)
    students=[]
    details=[]
    for seed in (101,202,303):
        student,detail=audit_seed(science,manifest,orders,prereg,seed)
        students.append(student);details.append(detail)
        print(canonical({'phase':'independent_read_only_target_order_audit','seed':seed,'targets':detail['trace']['targets'],
                         'train':student['metrics']['train']['whole_correct'],'heldout':student['metrics']['heldout']['whole_correct'],
                         'paired_difference':student['paired_difference']}),flush=True)
    equal(summary['students'],students,'all final student records and fixed96/128 stability')
    diagnostic_calls=sum(d['training_diagnostic_calls'] for d in details)
    diagnostic_macs=sum(d['training_diagnostic_dense_MAC'] for d in details)
    offline_calls=sum(d['independent_forward_calls'] for d in details)
    costs={'primary_targets':81408,'replay_targets':81408,'primary_training_dense_MAC':1714126848,
           'replay_training_dense_MAC':1714126848,'primary_training_diagnostic_dense_MAC':diagnostic_macs,
           'replay_training_diagnostic_dense_MAC':diagnostic_macs,'primary_training_diagnostic_inference_calls':diagnostic_calls,
           'replay_training_diagnostic_inference_calls':diagnostic_calls,'offline_evaluation_inference_calls':offline_calls,
           'offline_evaluation_dense_MAC':offline_calls*FORWARD_MAC,'p_m_v_birth_array_bytes_per_student':209980}
    for key,value in costs.items(): require(summary[key]==value,'actual cost '+key)
    require(summary['strong_fit_gate_all_three']==all(s['strong_fit_gate'] for s in students),'all-three fit criterion')
    require(summary['control_attribution']==manifest['control']['attribution'],'control is reused replication')
    require(summary['heldout_status']=='Previously viewed exposed diagnostic, not new blind test','exposed holdout status')
    require(summary['external_model_calls']==0,'formal external calls')
    timing=read(science/'timing.json')
    equal([(r['mode'],r['seed']) for r in timing['trajectories']],[(mode,seed) for mode in ('primary','replay') for seed in (101,202,303)],'actual6 trajectory timing records')
    require(all(math.isfinite(r['seconds']) and r['seconds']>0 for r in timing['trajectories']),'finite trajectory walltimes')
    require(timing['total_seconds']>=sum(r['seconds'] for r in timing['trajectories']),'walltime accounting scope')
    require(timing['total_seconds']==receipt['driver_measured_seconds'],'receipt driver walltime')
    progress=[];final_stdout=[]
    for line in args.formal_log.read_text(encoding='utf-8-sig').splitlines():
        if line.strip().startswith('{'):
            value=strict_json(line)
            if value.get('mode') in ('primary','replay'): progress.append(value)
            if value.get('status')=='complete': final_stdout.append(value)
    expected_progress=[{'mode':mode,'seed':seed,'epoch':epoch,'updates':epoch*212}
                       for mode in ('primary','replay') for seed in (101,202,303) for epoch in POINTS[1:]]
    equal(progress,expected_progress,'formal primary/replay progress')
    require(final_stdout==[summary],'formal final stdout versus result')
    equal(before_files,inventory(science),'read-only science files unchanged')
    equal(before_prereg,inventory(prereg),'approved inputs unchanged')
    equal(before_baseline,inventory(baseline),'fixed control inputs unchanged')
    for name,pin in manifest['local_source_hashes'].items(): require(file_sha(code/name)==pin,'new source unchanged after audit')
    for name,pin in manifest['original_source_hashes'].items(): require(file_sha(source/name)==pin,'original source unchanged after audit')
    scores=[{'seed':s['seed'],'train_whole_correct':s['metrics']['train']['whole_correct'],'train_address_correct':s['metrics']['train']['address_correct'],
             'train_total':12,'heldout_whole_correct':s['metrics']['heldout']['whole_correct'],'heldout_total':6,
             'strong_fit_gate':s['strong_fit_gate'],'paired_difference':s['paired_difference']} for s in students]
    result={'status':'passed','root_confirmed_formal_exit0':True,'manifest_sha256':MANIFEST_SHA,
            'launcher_sha256':LAUNCHER_SHA,'source_hashes':manifest['local_source_hashes'],
            'original_source_hashes':manifest['original_source_hashes'],'ownership_preregistration_commit':CLAIM,
            'handoff_head':HEAD,'scope':'Independent artifact and fixed-checkpoint inference audit of the new target-order treatment; no optimizer or control retraining.',
            'formal_receipt_sha256':file_sha(args.formal_receipt),'unique_formal_session':25437,
            'target_pool_occurrences_verified':212,'full_epoch_permutations_verified':384,'control_target_multiset_unchanged':True,
            'primary_target_records_verified':81408,'full_checkpoints_independently_evaluated':18,
            'NPZ_archives_loaded_including_boundary_copies':24,'whole_truth_examples_independently_recomputed':324,
            'training_truth_examples_verified_by_reusing_recomputed_rows':216,'teacher_forced_predictions_verified':5724,
            'free_run_actions_verified':offline_calls-5724,
            'checkpoint_state_boundary_anchors':sum(d['state_boundary_anchors'] for d in details),
            'independent_pre_update_prediction_loss_anchors':sum(d['pre_update_prediction_loss_anchors'] for d in details),
            'all_free_TF_logits_probabilities_CE_truth_metrics_paired_differences_and_stability_exact':True,
            'all_failures_retained_and_final_epoch128_reused':True,'formal_scores':scores,
            'pooled_final_train':{'correct':sum(s['train_whole_correct'] for s in scores),'total':36},
            'pooled_final_heldout_diagnostic':{'correct':sum(s['heldout_whole_correct'] for s in scores),'total':18},
            'strong_fit_gate_all_three':summary['strong_fit_gate_all_three'],'costs':costs,
            'audit_extra_inference_calls':offline_calls,'audit_extra_inference_dense_MAC':offline_calls*FORWARD_MAC,
            'audit_seconds':time.perf_counter()-started,'formal_walltime_seconds':timing['total_seconds'],
            'science_and_prereg_and_baseline_files_unchanged':True,'science_inventory_files':len(before_files),
            'science_inventory_sha256':json_sha(before_files),
            'replay_evidence':'Frozen driver completed3 full target replays, comparing every fullstate/prediction/loss and direct checkpoint/final arrays;6 actual trajectory logs and completion checked.',
            'independent_audit_limit':'All primary target metadata/cost/digests checked. Intermediate weights not recomputed;18 saved-state boundaries and15 pre-update predictions/losses independently anchored.',
            'interpretation_limit':'Three paired seeds in the already exposed finite domain; no broad causal mechanism, blind generalization or notification-benefit claim.',
            'new_students':0,'optimizer_step_lesson_loss_grad_calls':0,'external_model_calls':0,
            'scientific_modules_imported':False,'results_selected_or_extended':False,'details':'review/post-run-details.json'}
    detail={'status':'passed','manifest_sha256':MANIFEST_SHA,'source_hashes':manifest['local_source_hashes'],
            'seeds':details,'science_file_inventory':before_files,'prereg_file_inventory':before_prereg,
            'baseline_file_inventory':before_baseline,'formal_progress_records':len(progress),'new_optimizer_calls':0,'new_students':0}
    for path,value in ((output/'post-run-details.json',detail),(output/'post-run.json',result)):
        with path.open('x',encoding='utf-8',newline='\n') as stream:
            json.dump(value,stream,ensure_ascii=False,indent=2,allow_nan=False);stream.write('\n')
    return result

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ('formal-root','source-root','prereg-root','code-root','baseline-root','formal-log','formal-receipt'):
        parser.add_argument('--'+name,type=Path,required=True)
    parser.add_argument('--output-root',type=Path,default=HERE)
    parser.add_argument('--preregistration-commit',required=True)
    parser.add_argument('--root-confirmed-exit0',action='store_true')
    args=parser.parse_args()
    try:
        result=run(args)
    except Exception as exc:
        now=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
        failure={'status':'failed','error_type':type(exc).__name__,'message':str(exc),'new_optimizer_calls':0,'new_students':0,'external_model_calls':0}
        args.output_root.mkdir(parents=True,exist_ok=True)
        path=args.output_root/('post-run-failure-'+now+'.json')
        path.write_text(json.dumps(failure,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        print(canonical(failure|{'evidence':str(path)}),flush=True)
        return 1
    print(canonical({k:result[k] for k in ('status','primary_target_records_verified','full_checkpoints_independently_evaluated',
          'whole_truth_examples_independently_recomputed','formal_scores','audit_extra_inference_calls','audit_seconds')}),flush=True)
    return 0

if __name__=='__main__':
    raise SystemExit(main())
