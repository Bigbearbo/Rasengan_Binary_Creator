"""Independent UR1 artifact audit; no scientific-module imports or optimizer.

Only run after root confirms the unique formal process exited0. Independently
implements the frozen two-channel tanh forward for fixed checkpoint inference.
It never calls Model, step, lesson, loss_grad, a worker, or an external service.
"""
from __future__ import annotations
import argparse
from collections import Counter
from datetime import datetime, timezone
import gzip
import hashlib
from itertools import zip_longest
import json
import math
import os
from pathlib import Path
import platform
import re
import sys
import time

sys.dont_write_bytecode=True
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['OMP_NUM_THREADS']='1'
import numpy as np

ROOT=Path('D:/Codex用')
WORK=ROOT/'work/sle-ur1-20261113'
SOURCE=WORK/'source'
HERE=WORK/'review'
MANIFEST_SHA='d74dedb0627d79a8c41057a1625a3e83ab3c5b2edfbb675fccd902e94929a7b0'
LAUNCHER_SHA='ca04801fe4fb3af84fe03280108cdd356b0d11bf3deba87dc0f19a8919af00fb'
CLAIM='47175a513f4fb08c5231cdb354f99f18c2936938'
HEAD='0b6de1d24481c2886833e412d173645fca98609c'
L,H,CAP=80,64,24
FORWARD_MAC=2*L*H+3*H
TRAIN_MAC=4*L*H+9*H
POINTS=(0,16,32,64,96,128)
ARRAY_KEYS={f'{label}{i}' for label in ('p','m','v','birth') for i in range(4)}
ALL_STATE_KEYS=ARRAY_KEYS|{'t','L','H','growth_rng','meta_seed','meta_train_macs',
                        'meta_inference_macs','meta_inference_calls','meta_events'}

def require(ok,message):
    if not ok: raise AssertionError(message)

def canonical(value):
    return json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False)

def strict_json(text):
    def pairs(items):
        out={}
        for key,value in items:
            require(key not in out,'duplicate JSON key')
            out[key]=value
        return out
    def bad(value): raise ValueError('nonfinite JSON value')
    return json.loads(text,object_pairs_hook=pairs,parse_constant=bad)

def read(path):
    require(path.stat().st_size<=16*1024*1024,'JSON file exceeds audit bound')
    return strict_json(path.read_text(encoding='utf-8-sig'))

def file_sha(path):
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''): h.update(block)
    return h.hexdigest()

def json_sha(value):
    return hashlib.sha256(canonical(value).encode()).hexdigest()

def inventory(folder):
    return {p.relative_to(folder).as_posix():{'bytes':p.stat().st_size,'sha256':file_sha(p)}
            for p in sorted(folder.rglob('*')) if p.is_file()}

def difference(actual,expected,path='root'):
    if type(actual) is not type(expected): return path+': types '+type(actual).__name__+'/'+type(expected).__name__
    if isinstance(actual,dict):
        if actual.keys()!=expected.keys(): return path+': keys differ'
        for k in actual:
            if actual[k]!=expected[k]: return difference(actual[k],expected[k],path+'.'+k)
    elif isinstance(actual,list):
        if len(actual)!=len(expected): return path+': lengths differ'
        for i,(a,b) in enumerate(zip(actual,expected)):
            if a!=b: return difference(a,b,path+f'[{i}]')
    elif actual!=expected: return path+': '+repr(actual)+' / '+repr(expected)
    return path+': values compare equal'

def equal(actual,expected,label):
    require(actual==expected,label+' '+difference(actual,expected))

def load_state(path,seed,epoch):
    with np.load(path,allow_pickle=False) as archive:
        require(set(archive.files)==ALL_STATE_KEYS,'checkpoint state fields '+path.name)
        state={k:archive[k].copy() for k in archive.files}
    shapes=((2*L,H),(H,),(H,3),(3,))
    for label in ('p','m','v','birth'):
        for i,shape in enumerate(shapes):
            value=state[label+str(i)]
            require(value.shape==shape,'state shape '+path.name)
            require(value.dtype==(np.int64 if label=='birth' else np.float32),'state dtype '+path.name)
            require(bool(np.isfinite(value).all()),'nonfinite checkpoint '+path.name)
            if label=='birth': require(not np.any(value),'unexpected nonzero birth in fixed-capacity trial')
            if label=='v': require(bool((value>=0).all()),'negative Adam second moment')
    require(sum(state[k].nbytes for k in ARRAY_KEYS)==209980,'p/m/v/birth bytes')
    require((int(state['L']),int(state['H']),int(state['meta_seed']))==(L,H,seed),'checkpoint shape/seed')
    require(int(state['t'])==epoch*212,'checkpoint target count')
    require(int(state['meta_train_macs'])==int(state['t'])*TRAIN_MAC,'checkpoint training MAC')
    require(int(state['meta_inference_macs'])==int(state['meta_inference_calls'])*FORWARD_MAC,'checkpoint inference counter')
    require(str(state['meta_events'])=='[]','unexpected capacity event')
    equal(json.loads(str(state['growth_rng'])),np.random.default_rng(seed+73000).bit_generator.state,'unchanged growth RNG')
    for value in state.values(): value.setflags(write=False)
    return state

def same_arrays(actual,expected,label):
    require(actual.keys()==expected.keys(),label+' keys')
    for k in actual:
        require(actual[k].dtype==expected[k].dtype and actual[k].shape==expected[k].shape
                and np.array_equal(actual[k],expected[k]),label+' '+k)

def state_sha(state):
    result=hashlib.sha256()
    for name,value in sorted(state.items()):
        result.update(canonical([name,value.dtype.str,list(value.shape)]).encode())
        result.update(value.tobytes(order='C'))
    return result.hexdigest()

def with_prior_inference(state,calls):
    revised=dict(state)
    for key,value in (('meta_inference_calls',calls),('meta_inference_macs',calls*FORWARD_MAC)):
        revised[key]=np.array(value,dtype=state[key].dtype)
    return revised

class ReadOnlyForward:
    def __init__(self,state):
        self.weights=tuple(state['p'+str(i)] for i in range(4))
        self.calls=0
    def logits(self,prefix):
        require(isinstance(prefix,str) and 0<len(prefix)<=L and set(prefix)<=set('01'),'independent raw binary prefix')
        slots=np.zeros((L,2),dtype=np.float32)
        for position,bit in enumerate(prefix): slots[position,0 if bit=='0' else 1]=1
        x=slots.reshape(1,2*L)
        w1,b1,w2,b2=self.weights
        hidden=np.tanh(x@w1+b1)
        self.calls+=1
        return (hidden@w2+b2)[0]
    def generate(self,q):
        tokens=''
        steps=[]
        for _ in range(CAP):
            prefix=q+tokens
            if len(prefix)>L: return tokens,True,False,steps
            logits=self.logits(prefix)
            token='01S'[int(np.argmax(logits))]
            steps.append({'prefix':prefix,'prediction':token,'logits':logits.tolist()})
            tokens+=token
            if token=='S': return tokens,False,False,steps
        return tokens,False,True,steps
    def evaluate(self,rows):
        output=[]
        for row in rows:
            q,a=row['Q'],row['A']
            actual,overflow,exhausted,steps=self.generate(q)
            expected=a+'S'
            tf=[]
            for position,target in enumerate(expected):
                logits=self.logits(q+a[:position]).astype(np.float64)
                lp=logits-np.logaddexp.reduce(logits)
                tf.append({'position':position,'target':target,'prediction':'01S'[int(np.argmax(logits))],
                           'logits':logits.tolist(),'probabilities_01S':np.exp(lp).tolist(),
                           'target_CE':-float(lp['01S'.index(target)])})
            naddr=len(row['address_bits'])
            first=next((i for i,(left,right) in enumerate(zip_longest(actual,expected)) if left!=right),None)
            output.append({'id':row['id'],'split':row['split'],'path':row['path'],'target_n':row['target_n'],
                           'Q':q,'target':expected,'generated':actual,'whole_correct':actual==expected,
                           'address_correct':actual[:naddr]==row['address_bits'],
                           'UP_correct_at_expected_position':actual[naddr:len(a)]==row['up_bits'],
                           'STOP_position_correct':actual.endswith('S') and len(actual)==len(expected),
                           'first_error_position_zero_based':first,'overflow':overflow,'cap_exhausted':exhausted,
                           'teacher_forcing':tf,'free_run':steps})
        return output

def metrics(truth):
    out={}
    for split in ('train','heldout'):
        rows=[r for r in truth if r['split']==split]
        if not rows: continue
        targets=[t for row in rows for t in row['teacher_forcing']]
        out[split]={'total':len(rows),**{key:sum(bool(row[key]) for row in rows) for key in
                    ('whole_correct','address_correct','UP_correct_at_expected_position','STOP_position_correct','overflow','cap_exhausted')},
                    'teacher_targets':len(targets),'teacher_correct':sum(t['prediction']==t['target'] for t in targets),
                    'teacher_CE_mean':sum(t['target_CE'] for t in targets)/len(targets)}
    return out

def inference_calls(truth):
    return sum(len(r['free_run'])+len(r['teacher_forcing']) for r in truth)

def expected_targets(manifest,seed):
    by_id={r['id']:r for r in manifest['rows'] if r['split']=='train'}
    for epoch,order in enumerate(manifest['curricula'][str(seed)]['epochs'],1):
        for row_id in order:
            row=by_id[row_id]
            for position,target in enumerate(row['A']+'S'):
                yield epoch,row,position,row['Q']+row['A'][:position],target

def audit_trace(folder,manifest,seed,training_summary):
    path=folder/'targets.jsonl.gz'
    h=hashlib.sha256()
    raw_targets=hashlib.sha256()
    anchors={}
    boundaries={epoch*212 for epoch in POINTS if epoch}|{epoch*212+1 for epoch in POINTS[:-1]}
    per_epoch=Counter()
    per_width=Counter()
    fields={'epoch','row_id','position','prefix','target','prediction','loss','global_update','train_dense_MAC','full_state_sha256'}
    count=0
    with gzip.open(path,'rb') as stream:
        for count,(epoch,row,position,prefix,target) in enumerate(expected_targets(manifest,seed),1):
            line=stream.readline(8193)
            require(line and len(line)<=8192 and line.endswith(b'\n'),'target line framing')
            value=strict_json(line.decode('utf-8'))
            require(set(value)==fields,'target record fields')
            require(line==(canonical(value)+'\n').encode(),'target canonical stream')
            require((value['epoch'],value['row_id'],value['position'],value['prefix'],value['target'])==
                    (epoch,row['id'],position,prefix,target),'target course/teacher-prefix mismatch at '+str(count))
            require(type(value['global_update']) is int and value['global_update']==count,'target update ordinal')
            require(type(value['train_dense_MAC']) is int and value['train_dense_MAC']==count*TRAIN_MAC,'target MAC counter')
            require(value['prediction'] in ('0','1','S'),'target prediction alphabet')
            require(type(value['loss']) in (int,float) and math.isfinite(value['loss']) and value['loss']>=0,'target finite loss')
            require(isinstance(value['full_state_sha256'],str) and re.fullmatch('[0-9a-f]{64}',value['full_state_sha256']),'target state hash format')
            h.update(line)
            raw_targets.update((canonical([prefix,target])+'\n').encode())
            per_epoch[epoch]+=1
            per_width[row['target_n']]+=1
            if count in boundaries: anchors[count]=value
        require(not stream.read(1),'extra target records')
    require(count==27136 and per_epoch==Counter({epoch:212 for epoch in range(1,129)}),'full fixed target coverage')
    require(dict(per_width)=={4:8704,5:8704,6:9728},'width exposure ledger')
    equal(training_summary['trace'],{'targets':count,'uncompressed_stream_sha256':h.hexdigest()},'target stream digest')
    require(training_summary['trace_file_sha256']==file_sha(path),'gzip file digest')
    require(raw_targets.hexdigest()==manifest['curricula'][str(seed)]['raw_teacher_target_stream_sha256'],'actual teacher stream versus frozen manifest')
    return {'targets':count,'uncompressed_sha256':h.hexdigest(),'gzip_sha256':file_sha(path),
            'teacher_stream_sha256':raw_targets.hexdigest(),'width_target_exposures':dict(per_width)},anchors

def audit_seed(science,manifest,seed):
    folder=science/f'seed{seed}'
    summary=read(folder/'training-summary.json')
    require(summary['seed']==seed and summary['targets']==27136 and summary['lessons']==1536,'seed training metadata')
    require(summary['parameters']==10499 and summary['training_dense_MAC']==571375616,'seed cost/size')
    trace,anchors=audit_trace(folder,manifest,seed,summary)
    initial=load_state(folder/'initial-state.npz',seed,0)
    require(int(initial['meta_inference_calls'])==0,'initial inference counter')
    rng=np.random.default_rng(seed)
    expected_p0=rng.normal(0,.2,(2*L,H)).astype(np.float32)
    expected_p2=rng.normal(0,.15,(H,3)).astype(np.float32)
    require(np.array_equal(initial['p0'],expected_p0) and np.array_equal(initial['p2'],expected_p2),'initialization fixed seed')
    for key in ('p1','p3',*[f'{label}{i}' for label in ('m','v','birth') for i in range(4)]):
        require(not np.any(initial[key]),'initial zero '+key)
    train_curve=read(folder/'curve.json')
    offline_curve=read(folder/'offline-curve.json')
    require(len(train_curve)==len(offline_curve)==6,'six fixed checkpoint points')
    old_calls=0
    audit_calls=0
    points=[]
    state_anchors=0
    prediction_loss_anchors=0
    final_state=None
    final_metrics=None
    final_truth=None
    for index,epoch in enumerate(POINTS):
        path=folder/f'state-{epoch:03}.npz'
        state=load_state(path,seed,epoch)
        before=state_sha(state)
        inference=ReadOnlyForward(state)
        truth=inference.evaluate(manifest['rows'])
        require(inference.calls==inference_calls(truth),'independent forward count')
        audit_calls+=inference.calls
        require(state_sha(state)==before,'audit changed checkpoint arrays')
        train_truth=[r for r in truth if r['split']=='train']
        train_calls=inference_calls(train_truth)
        require(int(state['meta_inference_calls'])==old_calls+train_calls,'training diagnostic checkpoint counter')
        pre_diagnostic=with_prior_inference(state,old_calls)
        if epoch==0:
            same_arrays(pre_diagnostic,initial,'checkpoint0 versus initial boundary')
        else:
            require(state_sha(pre_diagnostic)==anchors[epoch*212]['full_state_sha256'],'last target versus checkpoint state anchor')
        state_anchors+=1
        if epoch<128:
            next_record=anchors[epoch*212+1]
            row=next(r for r in truth if r['id']==next_record['row_id'])
            require(next_record['position']==0 and next_record['prediction']==row['teacher_forcing'][0]['prediction']
                    and next_record['loss']==row['teacher_forcing'][0]['target_CE'],'checkpoint-to-next-update prediction/loss anchor')
            prediction_loss_anchors+=1
        old_calls=int(state['meta_inference_calls'])
        equal(read(folder/f'train-truth-{epoch:03}.json'),train_truth,'complete train truth '+str((seed,epoch)))
        expected_train_curve={'epoch':epoch,'target_updates':epoch*212,'training_dense_MAC':epoch*212*TRAIN_MAC,
                              'metrics':metrics(train_truth),'state_sha256':before}
        equal(train_curve[index],expected_train_curve,'training curve '+str((seed,epoch)))
        truth_name='final-truth.json' if epoch==128 else f'offline-truth-{epoch:03}.json'
        equal(read(folder/truth_name),truth,'complete independent free/TF/logits/probabilities/CE truth '+str((seed,epoch)))
        scores=metrics(truth)
        expected_offline={'epoch':epoch,'target_updates':epoch*212,'training_dense_MAC':epoch*212*TRAIN_MAC,
                          'metrics':scores,'truth_file':truth_name,'checkpoint_file':path.name,
                          'checkpoint_sha256':file_sha(path),'diagnostic_inference_calls':inference.calls,
                          'diagnostic_dense_MAC':inference.calls*FORWARD_MAC}
        equal(offline_curve[index],expected_offline,'offline curve '+str((seed,epoch)))
        points.append({'epoch':epoch,'checkpoint_sha256':file_sha(path),'full_state_sha256':before,
                       'independent_truth_sha256':json_sha(truth),'train_whole':scores['train']['whole_correct'],
                       'heldout_whole':scores['heldout']['whole_correct'],'independent_forward_calls':inference.calls,
                       'train_probe_calls_subset':train_calls})
        if epoch==128: final_state,final_metrics,final_truth=state,scores,truth
    final_archive=load_state(folder/'final-state.npz',seed,128)
    same_arrays(final_state,final_archive,'final-state versus checkpoint128')
    require(summary['state_sha256']==state_sha(final_state),'final fullstate summary digest')
    require(summary['training_diagnostic_inference_calls']==old_calls and summary['training_diagnostic_dense_MAC']==old_calls*FORWARD_MAC,'training diagnostic summary')
    equal(read(folder/'final-failures.json'),[r for r in final_truth if not r['whole_correct']],'all final failures retained')
    strong=final_metrics['train']['whole_correct']==12 and final_metrics['heldout']['whole_correct']==6
    expected_student={'seed':seed,'metrics':final_metrics,'strong_gate':strong,
                      'offline_diagnostic_inference_calls':audit_calls,'offline_diagnostic_dense_MAC':audit_calls*FORWARD_MAC,
                      'final_diagnostic_inference_calls_subset':points[-1]['independent_forward_calls'],
                      'final_diagnostic_dense_MAC_subset':points[-1]['independent_forward_calls']*FORWARD_MAC,
                      'checkpoint_sha256':file_sha(folder/'final-state.npz')}
    return expected_student,{'seed':seed,'trace':trace,'checkpoint_count':6,'archives_loaded':8,
           'state_boundary_anchors':state_anchors,'pre_update_prediction_loss_anchors':prediction_loss_anchors,
           'training_diagnostic_calls':old_calls,'training_diagnostic_dense_MAC':old_calls*FORWARD_MAC,
           'independent_forward_calls':audit_calls,'independent_forward_dense_MAC':audit_calls*FORWARD_MAC,
           'points':points,'final_failure_count':sum(not r['whole_correct'] for r in final_truth)}

def run(science,root_exit0):
    require(root_exit0,'Root exit0 confirmation flag is required before loading a formal checkpoint')
    require(science.is_relative_to(WORK.resolve()) and science!=SOURCE.resolve(),'formal path must be the dedicated local evidence tree')
    started=time.perf_counter()
    require(not any(n in sys.modules for n in ('learner','dataset','run_trial')),'scientific module imported')
    summary=read(science/'summary.json')
    provenance=read(science/'codex-execution-provenance.json')
    require(summary['status']==provenance['status']=='complete','formal result is not complete')
    require(summary['complete_trajectories']==summary['exact_replays']==3,'three primary plus three replay trajectories')
    require(not (science/'failure.json').exists(),'formal failure artifact present')
    equal(provenance['execution_author'],'Codex','actual executor')
    equal(provenance['design_implementation_author'],'ChatGPT Pro','design author')
    require(provenance['ownership_preregistration_commit']==CLAIM and provenance['source_head']==HEAD,'frozen preregistration/source identity')
    require(provenance['manifest_sha256']==summary['manifest_sha256']==MANIFEST_SHA,'approved manifest identity')
    require(provenance['launcher_sha256']==LAUNCHER_SHA==file_sha(ROOT/'outputs/sle-ur1/run_codex.py'),'frozen launcher identity')
    require(provenance['source_verification_after']['status']=='PASS' and provenance['source_verification_after']['normalized_manifest_exact'],'native post-run source gate')
    source_manifest=SOURCE/'experiments/spiral_neural/20261113_pro_notice_learning/frozen_manifest.json'
    require(file_sha(source_manifest)==MANIFEST_SHA,'original frozen manifest bytes')
    manifest=read(source_manifest)
    equal(read(science/'manifest.json'),manifest,'actual manifest contents')
    require((platform.python_version(),np.__version__)==('3.12.14','2.3.5'),'independent audit runtime')
    require(manifest['runtime']=={'python':'3.12.14','numpy':'2.3.5','OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1'},'frozen runtime')
    for ref,expected in manifest['source_hashes'].items(): require(file_sha(SOURCE/ref)==expected,'scientific source '+ref)
    imports=read(WORK/'source-import.json')
    require(imports['base_head']==HEAD and len(imports['files'])==20,'public source import lineage')
    for item in imports['files']:
        content=(SOURCE/item['path']).read_bytes()
        require(hashlib.sha1(b'blob '+str(len(content)).encode()+b'\0'+content).hexdigest()==item['git_blob'],'Git source blob '+item['path'])
    before_files=inventory(science)
    expected_students=[]
    details=[]
    for seed in (101,202,303):
        student,detail=audit_seed(science,manifest,seed)
        expected_students.append(student)
        details.append(detail)
        print(canonical({'phase':'independent_read_only_audit','seed':seed,'targets':detail['trace']['targets'],
                         'checkpoints':6,'train':student['metrics']['train']['whole_correct'],
                         'heldout':student['metrics']['heldout']['whole_correct']}),flush=True)
    equal(summary['students'],expected_students,'all final student records')
    primary_diagnostic=sum(d['training_diagnostic_dense_MAC'] for d in details)
    offline_calls=sum(d['independent_forward_calls'] for d in details)
    expected_cost={'primary_targets':81408,'replay_targets':81408,'primary_training_dense_MAC':1714126848,
                   'replay_training_dense_MAC':1714126848,'primary_training_diagnostic_dense_MAC':primary_diagnostic,
                   'replay_training_diagnostic_dense_MAC':primary_diagnostic,'offline_evaluation_inference_calls':offline_calls,
                   'offline_evaluation_dense_MAC':offline_calls*FORWARD_MAC,'p_m_v_birth_array_bytes_per_student':209980}
    for key,value in expected_cost.items(): require(summary[key]==value,'complete cost '+key)
    require(summary['strong_gate_all_three']==all(s['strong_gate'] for s in expected_students),'strong criterion')
    require(summary['author']=='ChatGPT Pro' and summary['nvidia_calls']==0 and summary['nvidia_status']=='skipped_unavailable','unaltered native source attribution')
    timing=read(science/'timing.json')
    equal([(r['mode'],r['seed']) for r in timing['trajectories']],[(mode,seed) for mode in ('primary','replay') for seed in (101,202,303)],'six actual trajectory timing records')
    require(all(math.isfinite(r['seconds']) and r['seconds']>0 for r in timing['trajectories']),'actual trajectory walltimes')
    require(timing['total_seconds']>=sum(r['seconds'] for r in timing['trajectories']),'walltime scope')
    progress=[]
    final_stdout=[]
    for line in (WORK/'formal.log').read_text(encoding='utf-8-sig').splitlines():
        if line.strip().startswith('{'):
            value=strict_json(line)
            if value.get('mode') in ('primary','replay'): progress.append(value)
            if value.get('status')=='complete': final_stdout.append(value)
    expected_progress=[{'mode':mode,'seed':seed,'epoch':epoch,'updates':epoch*212}
                       for mode in ('primary','replay') for seed in (101,202,303) for epoch in POINTS[1:]]
    equal(progress,expected_progress,'actual primary/replay process progress')
    require(final_stdout==[summary],'formal process final stdout versus artifact')
    after_files=inventory(science)
    equal(before_files,after_files,'read-only science inventory unchanged')
    for ref,expected in manifest['source_hashes'].items(): require(file_sha(SOURCE/ref)==expected,'source unchanged after audit')
    scores=[{'seed':s['seed'],'train_whole_correct':s['metrics']['train']['whole_correct'],'train_total':12,
             'heldout_whole_correct':s['metrics']['heldout']['whole_correct'],'heldout_total':6,
             'strong_gate':s['strong_gate']} for s in expected_students]
    result={'status':'passed','scope':'Independent read-only artifact and fixed-checkpoint inference audit; no optimizer replay or new student.',
            'source_head':HEAD,'manifest_sha256':MANIFEST_SHA,'launcher_sha256':LAUNCHER_SHA,
            'ownership_preregistration_commit':CLAIM,'root_confirmed_formal_exit0':True,
            'source_Git_blobs_verified':20,'scientific_source_hashes_verified':7,
            'primary_target_records_verified':sum(d['trace']['targets'] for d in details),
            'full_checkpoints_independently_evaluated':18,'NPZ_archives_loaded_including_boundary_copies':24,
            'whole_truth_examples_independently_recomputed':324,
            'training_truth_examples_verified_by_reusing_recomputed_rows':216,
            'checkpoint_state_boundary_anchors':sum(d['state_boundary_anchors'] for d in details),
            'independent_pre_update_prediction_loss_anchors':sum(d['pre_update_prediction_loss_anchors'] for d in details),
            'all_free_and_TF_tokens_logits_probabilities_CE_and_curves_exact':True,
            'all_failures_retained_and_final_epoch128_reused':True,
            'formal_scores':scores,'pooled_final_train':{'correct':sum(s['train_whole_correct'] for s in scores),'total':36},
            'pooled_final_heldout':{'correct':sum(s['heldout_whole_correct'] for s in scores),'total':18},
            'strong_gate_all_three':summary['strong_gate_all_three'],'costs':expected_cost,
            'audit_extra_inference_calls':offline_calls,'audit_extra_inference_dense_MAC':offline_calls*FORWARD_MAC,
            'audit_seconds':time.perf_counter()-started,'formal_walltime_seconds':timing['total_seconds'],
            'science_files_unchanged':True,'science_inventory_files':len(after_files),'science_inventory_sha256':json_sha(after_files),
            'attribution':'ChatGPT Pro design/implementation; Codex actual execution; native author/NVIDIA fields preserve original design metadata.',
            'current_external_review':'One actual NVIDIA review, cost0, independently semantic_rejected; Gemini skipped for the existing unverified runtime path.',
            'replay_evidence':'Original fixed driver completed3 full target-loop replays and checked every recorded full-state/prediction/loss plus direct checkpoints; six trajectory logs and completion verified.',
            'independent_audit_limit':'Every primary target metadata/cost/digest was checked. Intermediate weights were not recomputed: optimizer calls are prohibited. Saved-state boundary hashes and15 pre-update predictions/losses were independently anchored.',
            'new_students':0,'optimizer_step_lesson_loss_grad_calls':0,'external_model_calls':0,
            'scientific_modules_imported':False,'results_selected_or_extended':False,
            'details':'review/post-run-details.json'}
    detail_report={'status':'passed','seeds':details,'science_file_inventory':after_files,
                   'source_hashes':manifest['source_hashes'],'formal_progress_records':len(progress),
                   'new_optimizer_calls':0,'new_students':0}
    for path,value in ((HERE/'post-run-details.json',detail_report),(HERE/'post-run.json',result)):
        with path.open('x',encoding='utf-8',newline='\n') as stream:
            json.dump(value,stream,ensure_ascii=False,indent=2,allow_nan=False)
            stream.write('\n')
    return result

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--formal-root',type=Path,required=True)
    parser.add_argument('--root-confirmed-exit0',action='store_true')
    args=parser.parse_args()
    try:
        result=run(args.formal_root.resolve(strict=True),args.root_confirmed_exit0)
    except Exception as exc:
        now=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
        failure={'status':'failed','error_type':type(exc).__name__,'message':str(exc),
                 'new_optimizer_calls':0,'new_students':0,'external_model_calls':0}
        path=HERE/('post-run-failure-'+now+'.json')
        path.write_text(json.dumps(failure,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        print(canonical(failure|{'evidence':str(path)}),flush=True)
        return 1
    print(canonical({k:result[k] for k in ('status','primary_target_records_verified','full_checkpoints_independently_evaluated',
          'whole_truth_examples_independently_recomputed','formal_scores','audit_extra_inference_calls','audit_seconds')}),flush=True)
    return 0

if __name__=='__main__':
    raise SystemExit(main())
