"""Independent completed full-domain artifact audit: literal NumPy forward only.

Requires coordinator-confirmed exit0, then verifies every metadata path/schema
before inference. Never imports a learner/driver or computes an optimizer step.
"""
import argparse
import ast
from collections import Counter
import datetime
import hashlib
import io
import json
import math
import os
from pathlib import Path
import platform
import re
import sys
import time
import zipfile

sys.dont_write_bytecode = True
os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["OMP_NUM_THREADS"] = "1"
import numpy as np

APPROVED = "dabdb58a54ffd93afa350f19876a53550bcfcfd6de9b5199ee8b3b26d2b8d658"
ZIP_SHA = "82e5c9240d7217ee88399a4c84068715a336db208a3f942e956cb930fa5c4271"
COMMIT = "1d6ab7fd7fbb75525886226b10b1ed0a744ad9ff"
DRIVER = "9c100c1b8d6e9d1aca4acfc0f5a89d1a4716286aae1fae44692cbb5d0066593e"
SEEDS = (101, 202, 303)
HERE = Path(__file__).resolve().parent
TRAIN_MAC, FORWARD_MAC = 6969, 3381
EPOCH_FIELDS = {"epoch", "updates", "training_dense_MAC", "training", "scores", "streak", "stop_reason", "epoch_probe_inference_calls", "epoch_probe_inference_MAC", "cumulative_probe_inference_calls", "cumulative_probe_inference_MAC", "full_state_sha256"}
TRAIN_FIELDS = {"targets", "pre_update_prediction_correct", "CE_loss_sum", "CE_loss_mean", "canonical_target_trace_sha256"}
GEN_FIELDS = {"scores", "rows", "inference_calls", "inference_dense_MAC"}
ROW_FIELDS = {"input_id", "op", "value", "tokens", "overflow", "context_exhausted", "cap_exhausted", "whole_correct"}
TF_FIELDS = {"position", "prefix", "target", "prediction", "logits_01S", "probabilities_01S", "target_CE"}
SUMMARY_FIELDS = {"seed", "epochs", "stop_reason", "streak", "training_updates", "training_dense_MAC", "probe_inference_calls", "probe_inference_MAC", "final_scores", "final_full_state_sha256", "p_m_v_birth_array_bytes"}


def need(condition, message):
    if not condition:
        raise AssertionError(message)


def canonical(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"), allow_nan=False)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def sha(path):
    return digest(path.read_bytes())


def finite_json(value):
    if isinstance(value, float):
        need(math.isfinite(value), "nonfinite JSON number")
    elif isinstance(value, dict):
        for item in value.values():
            finite_json(item)
    elif isinstance(value, list):
        for item in value:
            finite_json(item)


def parse(text):
    def pairs(items):
        result = {}
        for key, value in items:
            need(key not in result, "duplicate JSON key")
            result[key] = value
        return result
    result = json.loads(text, object_pairs_hook=pairs)
    finite_json(result)
    return result


def read(path):
    return parse(path.read_text(encoding="utf-8-sig"))


def write(path, value):
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False)
        stream.write("\n")


def equal(left, right, label):
    need(left == right, label + " differs")


def keys(value, expected, label):
    need(isinstance(value, dict) and set(value) == set(expected), label + " schema")


def integer(value, minimum, maximum, label):
    need(type(value) is int and minimum <= value <= maximum, label + " integer range")


def inventory(root):
    return {path.relative_to(root).as_posix(): {"bytes": path.stat().st_size, "sha256": sha(path)} for path in sorted(root.rglob("*")) if path.is_file()}


def state_sha(state):
    result = hashlib.sha256()
    for name, value in sorted(state.items()):
        result.update(canonical([name, value.dtype.str, list(value.shape)]).encode())
        result.update(value.tobytes(order="C"))
    return result.hexdigest()


def same_state(left, right, label):
    need(left.keys() == right.keys(), label + " keys")
    for name in left:
        a, b = left[name], right[name]
        need(a.dtype == b.dtype and a.shape == b.shape and np.array_equal(a, b), label + " " + name)


def load_state(raw, seed, epoch, probe_calls):
    with np.load(io.BytesIO(raw), allow_pickle=False) as archive:
        state = {name: archive[name].copy() for name in archive.files}
    expected = {f"{label}{index}" for label in ("p", "m", "v", "birth") for index in range(4)}
    expected |= {"t", "L", "H", "growth_rng", "meta_seed", "meta_events", "meta_train_macs", "meta_inference_macs", "meta_inference_calls"}
    need(set(state) == expected, "all25 state fields")
    for label in ("p", "m", "v", "birth"):
        for index, shape in enumerate(((46, 69), (69,), (69, 3), (3,))):
            value = state[f"{label}{index}"]
            need(value.shape == shape and value.dtype == (np.int64 if label == "birth" else np.float32), "state array shape/dtype")
            need(bool(np.isfinite(value).all()), "finite state arrays")
            if label == "birth":
                need(not np.any(value), "unexpected parameter growth/birth")
            if label == "v":
                need(bool((value >= 0).all()), "negative Adam second moment")
    for name in ("t", "L", "H", "meta_seed", "meta_train_macs", "meta_inference_macs", "meta_inference_calls"):
        need(state[name].shape == () and state[name].dtype == np.int64, "state scalar integer dtype")
    need((int(state["L"]), int(state["H"]), int(state["meta_seed"])) == (23, 69, seed), "state identity")
    need(int(state["t"]) == epoch * 5120 and int(state["meta_train_macs"]) == epoch * 5120 * TRAIN_MAC, "state training counters")
    need(int(state["meta_inference_calls"]) == probe_calls and int(state["meta_inference_macs"]) == probe_calls * FORWARD_MAC, "state epoch-probe counters")
    need(str(state["meta_events"]) == "[]", "unexpected growth event")
    equal(parse(str(state["growth_rng"])), np.random.default_rng(seed + 73000).bit_generator.state, "growth RNG unchanged")
    need(sum(state[f"{label}{i}"].nbytes for label in ("p", "m", "v", "birth") for i in range(4)) == 69060, "state parameter/moment/birth memory")
    for value in state.values():
        value.setflags(write=False)
    return state


def inputs(args):
    need(sha(args.manifest) == APPROVED, "approved manifest SHA")
    manifest = read(args.manifest)
    freeze = read(args.manifest.parent / "source-freeze.json")
    need(freeze["manifest_sha256"] == APPROVED and freeze["source_hashes"] == manifest["source_hashes"], "source freeze")
    need(manifest["source_hashes"]["run_full_domain.py"] == DRIVER, "frozen driver")
    for name, pin in manifest["source_hashes"].items():
        need(sha(args.code_root / name) == pin, "frozen core source")
    need((platform.python_version(), np.__version__) == ("3.12.14", "2.3.5"), "audit runtime")
    need(manifest["runtime"]["python"] == platform.python_version() and manifest["runtime"]["numpy"] == np.__version__, "frozen runtime")
    archive_path = args.manifest.parent / manifest["archive"]["file"]
    need(sha(archive_path) == manifest["archive"]["sha256"] == ZIP_SHA, "frozen portable ZIP")
    names = {"source/p030_binary_continual.py", "plan.json", "question-pool.json"}
    names |= {f"initial/seed{seed}.npz" for seed in SEEDS} | {f"schedules/seed{seed}.npy" for seed in SEEDS}
    with zipfile.ZipFile(archive_path) as archive:
        need(len(archive.namelist()) == 9 and set(archive.namelist()) == names == set(manifest["files"]), "nine unique portable inputs")
        content = {name: archive.read(name) for name in names}
    for name, raw in content.items():
        equal({"bytes": len(raw), "sha256": digest(raw)}, manifest["files"][name], "input bytes/hash")
    need(content["plan.json"] == (args.code_root / "protocol.json").read_bytes(), "original protocol bytes")
    need(digest(content["source/p030_binary_continual.py"]) == manifest["protocol"]["source_sha256"], "original source SHA")
    node = next(n for n in ast.parse(content["source/p030_binary_continual.py"].decode("utf-8")).body if isinstance(n, ast.ClassDef) and n.name == "Model")
    need(digest(ast.dump(node, include_attributes=False).encode()) == manifest["protocol"]["Model_AST_sha256"], "unmodified original Model AST")
    pool = []
    for op in (0, 1):
        for value in range(256):
            bits = format(value, "08b")
            q = "01" + format(op, "02b") + "0" + bits + "0"
            a = (bits if op == 0 else "".join(str(1 - int(bit)) for bit in bits)) + "0"
            pool.append({"input_id": op * 256 + value, "op": op, "value": value, "Q": q, "A": a})
    equal(parse(content["question-pool.json"].decode()), pool, "independent full512 question pool")
    need(digest(canonical(pool).encode()) == manifest["question_pool_sha256"], "question pool canonical SHA")
    initials, courses = {}, {}
    schedule_pool = np.array([(op, value) for op in (0, 1) for value in range(256)], dtype="<i8")
    for seed in SEEDS:
        state = load_state(content[f"initial/seed{seed}.npz"], seed, 0, 0)
        need(state_sha(state) == manifest["initial_states"][str(seed)]["full_state_sha256"], "frozen complete initial state")
        rng = np.random.default_rng(seed)
        need(np.array_equal(state["p0"], rng.normal(0, .2, (46, 69)).astype(np.float32)), "fresh initial W1")
        need(np.array_equal(state["p2"], rng.normal(0, .15, (69, 3)).astype(np.float32)), "fresh initial W2")
        for name in ("p1", "p3", *[f"{label}{index}" for label in ("m", "v", "birth") for index in range(4)]):
            need(not np.any(state[name]), "initial zeros")
        initials[seed] = state
        rng = np.random.default_rng(seed + 221000)
        expected = np.stack([schedule_pool[rng.permutation(512)] for _ in range(40)])
        course = np.load(io.BytesIO(content[f"schedules/seed{seed}.npy"]), allow_pickle=False)
        need(course.shape == (40, 512, 2) and course.dtype.str == "<i8" and np.array_equal(course, expected), "all40 independently reconstructed epoch schedules")
        equal(manifest["schedules"][str(seed)]["final_schedule_RNG"], rng.bit_generator.state, "schedule RNG endpoint")
        need(all(Counter(map(tuple, epoch.tolist())) == Counter(map(tuple, schedule_pool.tolist())) for epoch in course), "all512 questions exactly once per epoch")
        courses[seed] = course
    return manifest, pool, initials, courses


def scores_schema(scores):
    keys(scores, {"0", "1"}, "two op scores")
    for value in scores.values():
        keys(value, {"questions", "whole_correct"}, "op scores")
        need(value["questions"] == 256, "all256 questions/op")
        integer(value["whole_correct"], 0, 256, "whole answer correct count")


def generation_schema(value, pool):
    keys(value, GEN_FIELDS, "generation file")
    scores_schema(value["scores"])
    need(len(value["rows"]) == 512, "all512 generated rows")
    for row, task in zip(value["rows"], pool, strict=True):
        keys(row, ROW_FIELDS, "generated row")
        need((row["input_id"], row["op"], row["value"]) == (task["input_id"], task["op"], task["value"]), "generation row identity/order")
        need(isinstance(row["tokens"], str) and set(row["tokens"]) <= set("01S") and len(row["tokens"]) <= 16, "generated tokens domain")
        need(all(type(row[name]) is bool for name in ("overflow", "context_exhausted", "cap_exhausted", "whole_correct")), "generation boolean fields")
    integer(value["inference_calls"], 512, 5120, "generation forward calls")
    need(value["inference_dense_MAC"] == value["inference_calls"] * FORWARD_MAC, "generation dense MAC")


def preflight(args, manifest, pool, initials):
    """Resolve all paths and validate all result schemas before a single forward."""
    required = [args.formal_log, args.formal_stderr, args.receipt]
    required += [args.science / name for name in ("manifest.json", "execution-start.json", "compact.json", "timing.json", "storage.json")]
    need(all(path.is_file() for path in required), "required top metadata/log/receipt paths exist")
    receipt, compact, start = read(args.receipt), read(args.science / "compact.json"), read(args.science / "execution-start.json")
    need(receipt["status"] == "exit0" and receipt["session_id"] == 77220 and receipt["command_invocations"] == 1 and receipt["formal_exit"] == 0, "actual one-process exit0 receipt")
    need(receipt["manifest_sha256"] == APPROVED and receipt["preregistration_commit"] == COMMIT, "receipt prereg identity")
    stamp = lambda value: datetime.datetime.fromisoformat(value.replace("Z", "+00:00"))
    need(stamp(receipt["PR_created_UTC"]) < stamp(receipt["execution_start_file_creation_UTC"]), "public preregistration precedes execution")
    equal(read(args.science / "manifest.json"), manifest, "actual scientific manifest")
    need(start["manifest_sha256"] == compact["manifest_sha256"] == APPROVED, "actual execution manifest")
    need(start["preregistration_commit"] == compact["preregistration_commit"] == COMMIT and start["auto_retry"] is False, "actual preregistration and no retry")
    need(compact["status"] == "complete" and compact["primary_students"] == 3 and compact["exact_full_replays"] == [101], "all planned trajectories completed")
    need(len(compact["students"]) == 3 and [row["seed"] for row in compact["students"]] == list(SEEDS), "all fixed primary seeds retained")
    for name in ("primary_students", "primary_updates", "replay_updates", "primary_training_dense_MAC", "replay_training_dense_MAC", "all_confirmed_full_train_fit"):
        equal(receipt[name], compact[name], "receipt versus actual complete run")
    equal(receipt["actual_primary_epochs"], [{"seed": row["seed"], "epochs": row["epochs"], "questions_presented": row["epochs"] * 512, "training_updates": row["epochs"] * 5120} for row in compact["students"]], "receipt trajectory counts")
    expected = {"manifest.json", "execution-start.json", "compact.json", "timing.json", "storage.json"}
    bundles = {}
    for row in compact["students"]:
        seed, count = row["seed"], row["epochs"]
        integer(count, 1, 40, "actual stopped epoch count")
        folder = args.science / f"seed{seed}"
        file_names = {"initial-state.npz", "final-state.npz", "training-summary.json", "curve.json", "final-truth.json", "final-failures.json"}
        file_names |= {f"{kind}-{epoch:03}.{extension}" for epoch in range(1, count + 1) for kind, extension in (("state", "npz"), ("epoch", "json"), ("generation", "json"))}
        need(all((folder / name).is_file() for name in file_names), "all declared epoch/final files exist")
        expected |= {f"seed{seed}/{name}" for name in file_names}
        summary, curve = read(folder / "training-summary.json"), read(folder / "curve.json")
        keys(summary, SUMMARY_FIELDS, "training summary")
        keys(row, SUMMARY_FIELDS | {"replay_status", "final_TF_metrics", "final_TF_inference_calls", "final_TF_inference_MAC"}, "compact student")
        need(len(curve) == count and summary["epochs"] == count and summary["seed"] == seed, "curve epoch identity")
        same_state(load_state((folder / "initial-state.npz").read_bytes(), seed, 0, 0), initials[seed], "science initial versus frozen initial")
        records, generations, states = [], [], []
        for epoch, point in enumerate(curve, 1):
            keys(point, EPOCH_FIELDS, "curve point")
            equal(read(folder / f"epoch-{epoch:03}.json"), point, "epoch versus curve record")
            need(point["epoch"] == epoch and point["updates"] == epoch * 5120 and point["training_dense_MAC"] == epoch * 5120 * TRAIN_MAC, "epoch target/MAC counters")
            keys(point["training"], TRAIN_FIELDS, "training aggregate")
            training = point["training"]
            need(training["targets"] == 5120, "targets per epoch")
            integer(training["pre_update_prediction_correct"], 0, 5120, "pre-update prediction aggregate")
            need(training["CE_loss_sum"] >= 0 and training["CE_loss_mean"] == training["CE_loss_sum"] / 5120, "finite sequential loss aggregate")
            need(re.fullmatch("[0-9a-f]{64}", training["canonical_target_trace_sha256"]) is not None, "per-target prediction/loss digest form")
            scores_schema(point["scores"])
            generation = read(folder / f"generation-{epoch:03}.json")
            generation_schema(generation, pool)
            state = load_state((folder / f"state-{epoch:03}.npz").read_bytes(), seed, epoch, point["cumulative_probe_inference_calls"])
            need(state_sha(state) == point["full_state_sha256"], "complete epoch state SHA")
            records.append(point)
            generations.append(generation)
            states.append(state)
        final_state = load_state((folder / "final-state.npz").read_bytes(), seed, count, summary["probe_inference_calls"])
        same_state(final_state, states[-1], "final NPZ exact full epoch-state copy")
        truth = read(folder / "final-truth.json")
        keys(truth, {"truth", "metrics", "inference_calls", "inference_dense_MAC", "learning_state_unchanged", "free_generation_reused_from_final_epoch"}, "final TF file")
        need(len(truth["truth"]) == 512, "all512 final TF questions")
        for task, item in zip(pool, truth["truth"], strict=True):
            keys(item, {"input_id", "op", "value", "Q", "A", "expected", "generation", "TF"}, "final truth row")
            need(all(item[key] == value for key, value in task.items()) and item["expected"] == task["A"] + "S", "final truth grammar and identity")
            need(len(item["TF"]) == 10, "all ten true-prefix TF targets")
            for index, token in enumerate(task["A"] + "S"):
                point = item["TF"][index]
                keys(point, TF_FIELDS, "TF token")
                need((point["position"], point["prefix"], point["target"]) == (index, task["Q"] + task["A"][:index], token), "TF teacher prefix/label")
                need(point["prediction"] in "01S" and len(point["prediction"]) == 1, "TF predicted action")
                need(len(point["logits_01S"]) == len(point["probabilities_01S"]) == 3, "TF vector shape")
                need(all(0 <= value <= 1 for value in point["probabilities_01S"]) and point["target_CE"] >= 0, "TF probability/CE domain")
        failures = read(folder / "final-failures.json")
        need(isinstance(failures, list) and len(failures) <= 512, "all failures file")
        bundles[seed] = {"summary": summary, "compact": row, "records": records, "generations": generations, "states": states, "final_state": final_state, "truth": truth, "failures": failures}
    science_inventory = inventory(args.science)
    equal(set(science_inventory), expected, "exact complete science inventory with no failure files")
    timing, storage = read(args.science / "timing.json"), read(args.science / "storage.json")
    equal([(row["mode"], row["seed"]) for row in timing["trajectories"]], [("primary", 101), ("primary", 202), ("primary", 303), ("replay", 101)], "actual trajectory timing identity")
    need(all(math.isfinite(row["seconds"]) and row["seconds"] > 0 for row in timing["trajectories"]), "finite actual trajectory durations")
    need(timing["total_seconds"] >= sum(row["seconds"] for row in timing["trajectories"]), "walltime includes full run")
    need(receipt["formal_seconds"] == timing["total_seconds"], "receipt actual formal walltime")
    need(storage["input_archive_bytes"] == manifest["archive"]["bytes"], "input storage bytes")
    need(storage["output_bytes_before_this_record"] == sum(row["bytes"] for name, row in science_inventory.items() if name != "storage.json"), "output storage bytes")
    progress, final_stdout = [], []
    for line in args.formal_log.read_text(encoding="utf-8-sig").splitlines():
        if not line.strip():
            continue
        item = parse(line)
        if item.get("mode") in ("primary", "replay"):
            progress.append(item)
        elif item.get("status") == "complete":
            final_stdout.append(item)
        else:
            need(False, "unrecognized formal stdout record")
    expected_progress = []
    for mode, seed in (("primary", 101), ("primary", 202), ("primary", 303), ("replay", 101)):
        for point in bundles[seed]["records"]:
            expected_progress.append({"mode": mode, "seed": seed, "epoch": point["epoch"], "E": point["scores"]["0"]["whole_correct"], "N": point["scores"]["1"]["whole_correct"], "streak": point["streak"], "stop": point["stop_reason"]})
    equal(progress, expected_progress, "actual primary/replay epoch stdout")
    equal(final_stdout, [compact], "actual process completion stdout")
    metadata = {"receipt_sha256": sha(args.receipt), "stdout_sha256": sha(args.formal_log), "stdout_bytes": args.formal_log.stat().st_size, "stderr_sha256": sha(args.formal_stderr), "stderr_bytes": args.formal_stderr.stat().st_size, "epoch_progress_records": len(progress), "actual_timing_trajectories": 4, "preregistration_precedes_execution": True}
    return compact, bundles, science_inventory, timing, metadata


class Cost:
    def __init__(self):
        self.calls = 0
        self.phase_calls = Counter()

    def increment(self, phase):
        self.calls += 1
        self.phase_calls[phase] += 1

    def record(self):
        return {"forward_calls": self.calls, "dense_MAC": self.calls * FORWARD_MAC, "calls_by_phase": dict(self.phase_calls), "optimizer_calls": 0, "new_students": 0, "external_model_calls": 0}


class Forward:
    def __init__(self, state, cost, phase):
        self.state, self.cost, self.phase = state, cost, phase
        self.calls = 0

    def __call__(self, text):
        need(0 < len(text) <= 23 and set(text) <= set("01"), "raw binary input within23")
        x = np.zeros((23, 2), np.float32)
        for index, bit in enumerate(text):
            x[index, int(bit)] = 1
        hidden = np.tanh(x.reshape(1, 46) @ self.state["p0"] + self.state["p1"])
        logits = (hidden @ self.state["p2"] + self.state["p3"])[0]
        self.calls += 1
        self.cost.increment(self.phase)
        need(bool(np.isfinite(logits).all()), "finite independent logits")
        return logits

    def generate(self, q):
        tokens = ""
        for _ in range(16):
            if len(q + tokens) > 23:
                return {"tokens": tokens, "overflow": True, "context_exhausted": True, "cap_exhausted": False}
            token = "01S"[int(np.argmax(self(q + tokens)))]
            tokens += token
            if token == "S":
                return {"tokens": tokens, "overflow": False, "context_exhausted": False, "cap_exhausted": False}
        return {"tokens": tokens, "overflow": False, "context_exhausted": False, "cap_exhausted": True}


def independent_generation(state, pool, cost):
    before = state_sha(state)
    forward = Forward(state, cost, "epoch_free_generation")
    rows = []
    for task in pool:
        result = forward.generate(task["Q"])
        rows.append({"input_id": task["input_id"], "op": task["op"], "value": task["value"], **result, "whole_correct": result["tokens"] == task["A"] + "S" and not result["overflow"]})
    scores = {str(op): {"whole_correct": sum(row["whole_correct"] for row in rows if row["op"] == op), "questions": 256} for op in (0, 1)}
    need(state_sha(state) == before, "state unchanged during independent free inference")
    return {"scores": scores, "rows": rows, "inference_calls": forward.calls, "inference_dense_MAC": forward.calls * FORWARD_MAC}


def independent_tf(state, pool, generation, cost):
    before = state_sha(state)
    forward = Forward(state, cost, "final_TF")
    truth = []
    for task, free in zip(pool, generation["rows"], strict=True):
        targets = []
        for position, label in enumerate(task["A"] + "S"):
            prefix = task["Q"] + task["A"][:position]
            logits = forward(prefix).astype(np.float64)
            logp = logits - np.logaddexp.reduce(logits)
            targets.append({"position": position, "prefix": prefix, "target": label, "prediction": "01S"[int(logits.argmax())], "logits_01S": logits.tolist(), "probabilities_01S": np.exp(logp).tolist(), "target_CE": -float(logp["01S".index(label)])})
        truth.append({**task, "expected": task["A"] + "S", "generation": free, "TF": targets})
    metrics = {str(op): {"questions": 256, "TF_data_correct": sum(point["prediction"] == point["target"] for row in truth if row["op"] == op for point in row["TF"][:8]), "TF_data_targets": 2048, "TF_tail0_correct": sum(row["TF"][8]["prediction"] == "0" for row in truth if row["op"] == op), "TF_STOP_correct": sum(row["TF"][9]["prediction"] == "S" for row in truth if row["op"] == op)} for op in (0, 1)}
    need(state_sha(state) == before, "state unchanged during independent TF")
    need(forward.calls == 5120, "all final TF forwards")
    return {"truth": truth, "metrics": metrics, "inference_calls": forward.calls, "inference_dense_MAC": forward.calls * FORWARD_MAC, "learning_state_unchanged": True, "free_generation_reused_from_final_epoch": True}


def audit_student(seed, bundle, pool, course, output, cost):
    started_calls = cost.calls
    streak = calls = 0
    first_full, reason = None, None
    points, last_generation = [], None
    for epoch, (record, state, actual) in enumerate(zip(bundle["records"], bundle["states"], bundle["generations"], strict=True), 1):
        need(reason is None, "training continued after fixed stop")
        generated = independent_generation(state, pool, cost)
        equal(generated, actual, "all512 independently generated rows and scores")
        calls += generated["inference_calls"]
        passed = all(generated["scores"][str(op)]["whole_correct"] == 256 for op in (0, 1))
        if passed and first_full is None:
            first_full = epoch
        streak = streak + 1 if passed else 0
        reason = "two_consecutive_full_training_passes" if streak >= 2 else "epoch_cap" if epoch == 40 else None
        equal(record["scores"], generated["scores"], "independent epoch scores")
        need(record["streak"] == streak and record["stop_reason"] == reason, "independent streak and stop reason")
        need(record["epoch_probe_inference_calls"] == generated["inference_calls"] and record["epoch_probe_inference_MAC"] == generated["inference_dense_MAC"], "actual epoch-probe costs")
        need(record["cumulative_probe_inference_calls"] == calls and record["cumulative_probe_inference_MAC"] == calls * FORWARD_MAC, "actual cumulative probe costs")
        teacher = hashlib.sha256()
        for op, value in course[epoch - 1]:
            task = pool[int(op) * 256 + int(value)]
            for position, label in enumerate(task["A"] + "S"):
                teacher.update((canonical([task["input_id"], position, task["Q"] + task["A"][:position], label]) + "\n").encode())
        proof = {"status": "passed", "seed": seed, "epoch": epoch, "full_state_sha256": state_sha(state), "scores": generated["scores"], "streak": streak, "stop_reason": reason, "generated_questions_verified": 512, "independent_generation_canonical_sha256": digest(canonical(generated).encode()), "main_generation_exact_equal": True, "independent_forward_calls": generated["inference_calls"], "independent_dense_MAC": generated["inference_dense_MAC"], "frozen_teacher_course_sha256": teacher.hexdigest(), "training_pred_loss_digest_form_checked": True, "actual_intermediate_gradient_recomputed": False}
        write(output / f"seed{seed}-epoch{epoch:03}.json", proof)
        points.append(proof)
        last_generation = generated
    count = len(points)
    need(reason is not None and (count == 40 or streak == 2), "actual fixed termination")
    summary = {"seed": seed, "epochs": count, "stop_reason": reason, "streak": streak, "training_updates": count * 5120, "training_dense_MAC": count * 5120 * TRAIN_MAC, "probe_inference_calls": calls, "probe_inference_MAC": calls * FORWARD_MAC, "final_scores": last_generation["scores"], "final_full_state_sha256": state_sha(bundle["final_state"]), "p_m_v_birth_array_bytes": 69060}
    equal(summary, bundle["summary"], "full independently derived training summary")
    tf = independent_tf(bundle["final_state"], pool, last_generation, cost)
    equal(tf, bundle["truth"], "all final5120 TF logits/probabilities/predictions/CE")
    failures = [row for row in tf["truth"] if not row["generation"]["whole_correct"]]
    equal(failures, bundle["failures"], "all final failures exact")
    compact_row = {**summary, "replay_status": "complete_exact" if seed == 101 else "not_planned", "final_TF_metrics": tf["metrics"], "final_TF_inference_calls": 5120, "final_TF_inference_MAC": 5120 * FORWARD_MAC}
    equal(compact_row, bundle["compact"], "complete compact student")
    proof = {"status": "passed", "seed": seed, "epochs": count, "first_full_training_epoch": first_full, "streak": streak, "stop_reason": reason, "final_scores": summary["final_scores"], "final_TF_metrics": tf["metrics"], "free_generations_verified": count * 512, "TF_logits_probabilities_CE_verified": 5120, "final_failure_count": len(failures), "final_failure_input_ids": [row["input_id"] for row in failures], "final_truth_independent_canonical_sha256": digest(canonical(tf).encode()), "final_failures_independent_canonical_sha256": digest(canonical(failures).encode()), "full_state_sha256": summary["final_full_state_sha256"], "independent_forward_calls": cost.calls - started_calls, "independent_dense_MAC": (cost.calls - started_calls) * FORWARD_MAC, "epoch_proofs": [f"numeric-proof/seed{seed}-epoch{epoch:03}.json" for epoch in range(1, count + 1)], "summary": summary, "optimizer_calls": 0}
    write(output / f"seed{seed}-student.json", proof)
    print(canonical({"phase": "independent_student_complete", "seed": seed, "epochs": count, "final_scores": summary["final_scores"], "audit_forward_calls": cost.calls - started_calls}), flush=True)
    return compact_row, proof


def run(args, cost):
    need(args.root_confirmed_exit0, "coordinator exit0 confirmation required before trained-state access")
    for path in (args.manifest, args.manifest.parent / "source-freeze.json", args.manifest.parent / "inputs.zip", args.formal_log, args.formal_stderr, args.receipt):
        need(path.is_file(), "required external input/log/receipt paths exist")
    manifest, pool, initials, courses = inputs(args)
    compact, bundles, before, timing, metadata = preflight(args, manifest, pool, initials)
    prereg_before = inventory(args.manifest.parent)
    write(args.output_root / "metadata-preflight.json", {"status": "passed", "manifest_sha256": APPROVED, "all_required_paths_and_schemas_checked_before_forward": True, "science_files": len(before), "epochs_by_seed": {str(seed): len(bundle["records"]) for seed, bundle in bundles.items()}, "model_forward_calls": 0, **metadata})
    proof_root = args.output_root / "numeric-proof"
    proof_root.mkdir(exist_ok=False)
    rows, details = [], []
    for seed in SEEDS:
        row, detail = audit_student(seed, bundles[seed], pool, courses[seed], proof_root, cost)
        rows.append(row)
        details.append(detail)
    primary_updates = sum(row["training_updates"] for row in rows)
    primary_train = sum(row["training_dense_MAC"] for row in rows)
    primary_probes = sum(row["probe_inference_calls"] for row in rows)
    expected = {"id": manifest["id"], "status": "complete", "author": "Codex", "manifest_sha256": APPROVED, "preregistration_commit": COMMIT, "students": rows, "primary_students": 3, "exact_full_replays": [101], "primary_updates": primary_updates, "primary_training_dense_MAC": primary_train, "replay_updates": rows[0]["training_updates"], "replay_training_dense_MAC": rows[0]["training_dense_MAC"], "primary_epoch_probe_inference_calls": primary_probes, "primary_epoch_probe_inference_MAC": primary_probes * FORWARD_MAC, "replay_epoch_probe_inference_calls": rows[0]["probe_inference_calls"], "replay_epoch_probe_inference_MAC": rows[0]["probe_inference_MAC"], "final_TF_inference_calls": 15360, "final_TF_inference_MAC": 15360 * FORWARD_MAC, "array_bytes_per_student": 69060, "all_confirmed_full_train_fit": all(row["streak"] >= 2 for row in rows), "external_model_calls": 0, "scope": manifest["protocol"]["scope"], "limits": manifest["protocol"]["limits"]}
    equal(compact, expected, "entire independently recomputed compact")
    need(cost.calls == primary_probes + 15360, "independent actual forward accounting")
    equal(before, inventory(args.science), "science unchanged during audit")
    equal(prereg_before, inventory(args.manifest.parent), "all frozen inputs unchanged during audit")
    for name, pin in manifest["source_hashes"].items():
        need(sha(args.code_root / name) == pin, "core source unchanged after audit")
    need(sha(args.receipt) == metadata["receipt_sha256"] and sha(args.formal_log) == metadata["stdout_sha256"] and sha(args.formal_stderr) == metadata["stderr_sha256"], "execution metadata unchanged")
    science_npz = sum(name.endswith(".npz") for name in before)
    result = {"status": "passed", "root_confirmed_formal_exit0": True, "formal_session": 77220, "manifest_sha256": APPROVED, "inputs_zip_sha256": ZIP_SHA, "preregistration_commit": COMMIT, "source_hashes": manifest["source_hashes"], "actual_primary_students": 3, "actual_full_replay_seeds": [101], "not_replayed_seeds": [202, 303], "actual_epochs_by_seed": {str(row["seed"]): row["epochs"] for row in rows}, "first_full_training_epoch_by_seed": {str(row["seed"]): row["first_full_training_epoch"] for row in details}, "stop_reasons_by_seed": {str(row["seed"]): row["stop_reason"] for row in rows}, "final_scores_by_seed": {str(row["seed"]): row["final_scores"] for row in rows}, "frozen_schedule_permutations_independently_verified": 120, "actual_epoch_512_question_generations_verified": sum(row["epochs"] for row in rows), "whole_free_generations_verified": sum(row["epochs"] for row in rows) * 512, "final_TF_logits_probabilities_CE_verified": 15360, "science_fullstate_NPZ_verified": science_npz, "frozen_initial_states_verified": 3, "primary_updates_evidenced_by_epoch_counters": primary_updates, "primary_training_dense_MAC": primary_train, "replay_updates_seed101": rows[0]["training_updates"], "replay_training_dense_MAC_seed101": rows[0]["training_dense_MAC"], "primary_epoch_probe_forward_calls": primary_probes, "replay_epoch_probe_forward_calls_seed101": rows[0]["probe_inference_calls"], "native_final_TF_forward_calls": 15360, "audit_extra_forward_calls": cost.calls, "audit_extra_dense_MAC": cost.calls * FORWARD_MAC, "audit_attempt_count": 1, "metadata_checked_before_first_forward": True, "each_epoch_and_student_numeric_proof_persisted": True, "all_science_input_and_source_files_unchanged": True, "all_exact_generation_TF_failures_curves_stops_and_costs": True, "formal_wall_seconds": timing["total_seconds"], "replay_scope": "Frozen driver and actual exit0/timing/stdout evidence establish one independent target-loop replay of seed101, with each epoch prediction/loss digest, full arrays, generation and stop equality. Seeds202/303 are not replayed.", "independent_limit": "All archived full states, epoch free generations, final TF, grammar, schedules, aggregates, digests' form, stops and costs are checked. Raw per-target loss/prediction records and intermediate weight hashes were not archived; the auditor does not reconstruct their hidden contents or recompute gradients/optimizer trajectories.", "interpretation_limit": "Full finite8-bit training-domain fit with training-score stopping; not heldout/generalization or pure question-count causal evidence. Input width/window/parameters also changed; finite success does not identify an internal algorithm.", "optimizer_calls": 0, "new_students": 0, "external_model_calls": 0, "legacy_or_driver_modules_imported": False, "details": "review/post-run-details.json", "metadata": metadata}
    write(args.output_root / "post-run-details.json", {"status": "passed", "students": details, "science_inventory": before, "prereg_inventory": prereg_before})
    write(args.output_root / "post-run.json", result)
    print(canonical({"status": "passed", "epochs_by_seed": result["actual_epochs_by_seed"], "final_scores": result["final_scores_by_seed"], "audit_cost": cost.record()}), flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("manifest", "science", "code-root", "formal-log", "formal-stderr", "receipt"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--output-root", type=Path, default=HERE)
    parser.add_argument("--root-confirmed-exit0", action="store_true")
    args = parser.parse_args()
    need(not any((args.output_root / name).exists() for name in ("metadata-preflight.json", "numeric-proof", "post-run.json", "audit-cost.json", "audit-failure.json")), "audit output must not already contain a prior attempt")
    args.output_root.mkdir(parents=True, exist_ok=True)
    started, cost, status = time.perf_counter(), Cost(), "failed"
    try:
        run(args, cost)
        status = "passed"
    except Exception as error:
        write(args.output_root / "audit-failure.json", {"status": "failed", "error_type": type(error).__name__, "message": str(error), "cost": cost.record(), "script_sha256": sha(Path(__file__)), "durable_epoch_and_student_proofs_retained": True})
        raise
    finally:
        write(args.output_root / "audit-cost.json", {"status": status, **cost.record(), "seconds": time.perf_counter() - started, "script_sha256": sha(Path(__file__)), "attempts": 1})


if __name__ == "__main__":
    main()
