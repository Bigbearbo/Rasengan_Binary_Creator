"""Independent protocol arithmetic only; no learner import or trained-state access."""
from pathlib import Path
import json


def main():
    width, op_width, hidden, length = 8, 2, 69, 23
    q_length = 2 + op_width + 1 + width + 1
    answer_actions = width + 1 + 1
    stop_prefix = q_length + width + 1
    params = (2 * length) * hidden + hidden + hidden * 3 + 3
    forward_mac = (2 * length) * hidden + hidden * 3
    train_mac = 2 * (2 * length) * hidden + 3 * hidden * 3
    lessons = 2 * (2 ** width)
    updates = lessons * answer_actions
    epoch_mac = updates * train_mac
    assert (q_length, answer_actions, stop_prefix) == (14, 10, 23)
    assert (params, forward_mac, train_mac) == (3453, 3381, 6969)
    assert (lessons, updates, epoch_mac) == (512, 5120, 35681280)
    assert (40 * updates, 40 * epoch_mac) == (204800, 1427251200)
    result = {
        "status": "protocol_arithmetic_passed_code_gate_pending",
        "round_id": "FULL-DOMAIN-MIX-20261113",
        "scope": "Pre-inference arithmetic and interpretation review only. This does not authorize formal execution or certify unread implementation.",
        "computed": {
            "Q_length": q_length,
            "A_actions_including_tail0_STOP": answer_actions,
            "maximum_legal_teacher_prefix_length": stop_prefix,
            "L": length,
            "H": hidden,
            "parameters": params,
            "dense_forward_MAC": forward_mac,
            "dense_training_MAC_per_target": train_mac,
            "unique_Q_per_epoch": lessons,
            "targets_per_epoch": updates,
            "dense_training_MAC_per_epoch": epoch_mac,
            "max_targets_per_seed": 40 * updates,
            "max_training_MAC_per_seed": 40 * epoch_mac,
            "max_primary_targets_three_seeds": 3 * 40 * updates,
            "max_primary_training_MAC_three_seeds": 3 * 40 * epoch_mac,
            "max_replay_training_MAC_seed101_only": 40 * epoch_mac,
        },
        "required_code_gates": [
            "Freeze full initial state and all40 RNG(seed+221000) permutations of all512 distinct Q for each seed before training; no legacy trained state import.",
            "Use native P030 learning AST and exact8 information bits plus fixed tail0 plus external STOP; neither complement the tail0 nor confuse numeric bit strings with an AE1 lexicon.",
            "Greedy wrapper calls no forward aboveL23. A missing STOP at the limit is an explicit context failure, not truncated success or a synthetic STOP; cap16 is only an additional ceiling.",
            "Stop only after both ops each have256 exact free answers including STOP at two consecutive epoch-end evaluations, or after epoch40; count all training and generation costs separately.",
            "Only predesignated seed101 receives full replay. Its independent target stream, epoch state, probe, streak and stopping decision must match; do not claim seed202 or303 were replayed.",
            "Audit metadata paths before trained forward, then persist independently computed numerical proof before optional presentation checks.",
        ],
        "interpretation_limits": [
            "This measures fitting all512 Q in a fixed finite domain. The full-domain training score controls stopping and is not a heldout or blind generalization score.",
            "This is a single policy. Q width, fixed window and parameter count change from the earlier3bit experiment, so differences cannot be attributed to adding examples alone.",
            "All three seeds answer the same512 Q; seed repetitions are not1536 distinct domain examples.",
            "Complete success is consistent with either a finite lookup or a copy/complement algorithm and does not identify internal mechanism.",
            "No longer-width probe is included: n9 would require STOP prefix25, outsideL23. A context limit must not be presented as a general learning failure.",
        ],
        "model_forward_calls": 0,
        "optimizer_calls": 0,
        "formal_students": 0,
        "external_model_calls": 0,
    }
    path = Path(__file__).with_name("protocol-review.json")
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps({"status": result["status"], "computed": result["computed"], "optimizer_calls": 0}))


if __name__ == "__main__":
    main()
