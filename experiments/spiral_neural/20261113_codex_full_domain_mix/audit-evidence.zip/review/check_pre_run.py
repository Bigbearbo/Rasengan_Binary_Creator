"""Independent full-domain input/portability gate: no optimizer or model forward."""
from collections import Counter
import argparse
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import shutil
import sys
import zipfile

sys.dont_write_bytecode = True
os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["OMP_NUM_THREADS"] = "1"
import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def canonical(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"), allow_nan=False)


def state_sha(state):
    digest = hashlib.sha256()
    for key, value in sorted(state.items()):
        digest.update(canonical([key, value.dtype.str, list(value.shape)]).encode())
        digest.update(value.tobytes(order="C"))
    return digest.hexdigest()


def main(args):
    manifest_path, code = args.manifest.resolve(), args.code_root.resolve()
    prereg = manifest_path.parent
    assert sha(manifest_path.read_bytes()) == args.approved_manifest_sha
    manifest = read(manifest_path)
    freeze = read(prereg / "source-freeze.json")
    pins = manifest["source_hashes"]
    assert set(pins) == {"run_full_domain.py", "protocol.json", "test_full_domain.py"}
    assert freeze["manifest_sha256"] == args.approved_manifest_sha
    assert freeze["source_hashes"] == pins
    for name, pin in pins.items():
        assert sha((code / name).read_bytes()) == pin
    zip_path = prereg / "inputs.zip"
    assert zip_path.stat().st_size == manifest["archive"]["bytes"]
    assert sha(zip_path.read_bytes()) == manifest["archive"]["sha256"] == freeze["inputs_zip_sha256"]
    expected_names = {"source/p030_binary_continual.py", "plan.json", "question-pool.json"}
    expected_names |= {f"initial/seed{s}.npz" for s in (101, 202, 303)}
    expected_names |= {f"schedules/seed{s}.npy" for s in (101, 202, 303)}
    with zipfile.ZipFile(zip_path) as archive:
        assert len(archive.namelist()) == len(set(archive.namelist())) == 9
        assert set(archive.namelist()) == expected_names == set(manifest["files"])
        data = {name: archive.read(name) for name in expected_names}
    for name, value in data.items():
        assert {"bytes": len(value), "sha256": sha(value)} == manifest["files"][name]
    assert data["plan.json"] == (code / "protocol.json").read_bytes()
    assert json.loads(data["plan.json"]) == manifest["protocol"]
    assert manifest["protocol"]["seeds"] == [101, 202, 303]
    assert manifest["protocol"]["replay_seeds"] == [101]
    assert manifest["protocol"]["model"] == {"L": 23, "H": 69, "parameters": 3453}
    assert manifest["formal_optimizer_calls_before_freeze"] == manifest["formal_inference_calls_before_freeze"] == 0
    pool = []
    teacher = {}
    labels = Counter()
    for op in (0, 1):
        for value in range(256):
            bits = format(value, "08b")
            q = "01" + format(op, "02b") + "0" + bits + "0"
            a = (bits if op == 0 else "".join(str(1 - int(bit)) for bit in bits)) + "0"
            pool.append({"input_id": op * 256 + value, "op": op, "value": value, "Q": q, "A": a})
            assert len(q) == 14 and len(a) == 9
            for position, target in enumerate(a + "S"):
                prefix = q + a[:position]
                assert len(prefix) <= 23 and prefix not in teacher
                teacher[prefix] = target
                labels[target] += 1
    assert len(teacher) == 5120 and dict(labels) == {"0": 2560, "S": 512, "1": 2048}
    assert json.loads(data["question-pool.json"]) == pool
    assert sha(canonical(pool).encode()) == manifest["question_pool_sha256"]
    initial_states, courses = {}, {}
    schedule_pool = np.array([(op, value) for op in (0, 1) for value in range(256)], dtype="<i8")
    shapes = ((46, 69), (69,), (69, 3), (3,))
    for seed in (101, 202, 303):
        key = str(seed)
        with np.load(io.BytesIO(data[f"initial/seed{seed}.npz"]), allow_pickle=False) as archive:
            saved = {name: archive[name].copy() for name in archive.files}
        assert len(saved) == 25 and state_sha(saved) == manifest["initial_states"][key]["full_state_sha256"]
        assert (int(saved["L"]), int(saved["H"]), int(saved["meta_seed"])) == (23, 69, seed)
        assert all(int(saved[name]) == 0 for name in ("t", "meta_train_macs", "meta_inference_calls", "meta_inference_macs"))
        assert str(saved["meta_events"]) == "[]"
        for label in ("p", "m", "v", "birth"):
            for index, shape in enumerate(shapes):
                value = saved[f"{label}{index}"]
                assert value.shape == shape and value.dtype == (np.int64 if label == "birth" else np.float32)
                assert np.isfinite(value).all()
                if label != "p":
                    assert not np.any(value)
        rng = np.random.default_rng(seed)
        assert np.array_equal(saved["p0"], rng.normal(0, .2, (46, 69)).astype(np.float32))
        assert np.array_equal(saved["p2"], rng.normal(0, .15, (69, 3)).astype(np.float32))
        assert not np.any(saved["p1"]) and not np.any(saved["p3"])
        assert sum(saved[f"{label}{i}"].nbytes for label in ("p", "m", "v", "birth") for i in range(4)) == 69060
        initial_states[key] = saved
        rng = np.random.default_rng(seed + 221000)
        expected = np.stack([schedule_pool[rng.permutation(512)] for _ in range(40)])
        course = np.load(io.BytesIO(data[f"schedules/seed{seed}.npy"]), allow_pickle=False)
        assert course.shape == (40, 512, 2) and course.dtype.str == "<i8"
        assert np.array_equal(course, expected)
        assert manifest["schedules"][key]["final_schedule_RNG"] == rng.bit_generator.state
        assert all(Counter(map(tuple, epoch.tolist())) == Counter(map(tuple, schedule_pool.tolist())) for epoch in course)
        courses[key] = course
    fresh = HERE / "portable-gate"
    fresh.mkdir(exist_ok=False)
    for name in pins:
        shutil.copyfile(code / name, fresh / name)
    for name in ("manifest.json", "inputs.zip", "source-freeze.json"):
        shutil.copyfile(prereg / name, fresh / name)
    before = {path.name: sha(path.read_bytes()) for path in fresh.iterdir()}
    enabled, forbidden, blocked = True, [], []

    def hook(event, values):
        if enabled and event == "open" and isinstance(values[0], (str, bytes, os.PathLike)):
            path = Path(os.fsdecode(values[0])).resolve()
            if path.is_relative_to(ROOT) and not path.is_relative_to(fresh):
                blocked.append(1)
                raise AssertionError("Original workspace dependency read")

    sys.addaudithook(hook)
    spec = importlib.util.spec_from_file_location("relocated_full_domain_gate", fresh / "run_full_domain.py")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    native = module.source_model

    def denied(*values, **kwargs):
        forbidden.append(1)
        raise AssertionError("Model optimizer/inference forbidden in pre-run gate")

    def guarded(content):
        cls = native(content)
        for name in ("step", "lesson", "loss_grad", "forward", "generate", "grow"):
            setattr(cls, name, denied)
        return cls

    module.source_model = guarded
    for name in ("execute", "run_seed", "one_lesson", "probe", "final_tf", "generate"):
        setattr(module, name, denied)
    actual, cls, actual_pool, actual_initials, actual_courses = module.validate_inputs(fresh / "manifest.json", args.approved_manifest_sha)
    assert actual == manifest and actual_pool == pool and not forbidden and not blocked
    for key in courses:
        assert np.array_equal(courses[key], actual_courses[key])
        assert actual_initials[key].keys() == initial_states[key].keys()
        assert all(np.array_equal(value, actual_initials[key][name]) and value.dtype == actual_initials[key][name].dtype for name, value in initial_states[key].items())
    enabled = False
    assert before == {path.name: sha(path.read_bytes()) for path in fresh.iterdir()}
    engineering = read(args.engineering)
    assert engineering["status"] == "PASS" and engineering["source_hashes"] == pins
    assert engineering["formal_optimizer_updates"] == engineering["formal_inference_calls"] == 0
    for name, pin in pins.items():
        assert sha((code / name).read_bytes()) == pin
    assert sha(manifest_path.read_bytes()) == args.approved_manifest_sha
    assert sha(zip_path.read_bytes()) == manifest["archive"]["sha256"]
    result = {
        "status": "passed",
        "round_id": "FULL-DOMAIN-MIX-20261113",
        "manifest_sha256": args.approved_manifest_sha,
        "inputs_zip_sha256": manifest["archive"]["sha256"],
        "source_hashes": pins,
        "portable_archive_entries": 9,
        "fresh_bundle_real_validator_passed_original_workspace_reads_blocked": True,
        "fresh_input_files_before_after_exact": 6,
        "complete_initial_states_independently_checked": 3,
        "independent_frozen_schedules": 3,
        "permutations_verified": 120,
        "distinct_Q_per_epoch": 512,
        "unique_consistent_teacher_prefixes_per_epoch": 5120,
        "teacher_label_counts_per_epoch": dict(labels),
        "all_40epoch_schedules_are_fixed_before_any_score": True,
        "source_review": {
            "unchanged_native_P030_Model_AST": True,
            "fresh_fixed_L23_H69_3453params_no_router_or_growth": True,
            "only_Q_plus_prior_true_A_to_training": True,
            "free_generation_only_Q_plus_generated_tokens": True,
            "missing_STOP_context_overflow_explicit_no_truncation_or_forced_STOP": True,
            "full512_exact_free_outputs_two_consecutive_epoch_stopping_else40cap": True,
            "only_seed101_full_replay_with_independent_stop_and_full_epoch_states": True,
            "seeds202_303_explicitly_not_planned_for_replay": True,
            "final_TF_after_all_primary_and_planned_replay_reuses_final_free": True,
            "primary_replay_epoch_probe_and_final_TF_costs_separate": True,
            "per_target_prediction_loss_digest_without_per_target_statehash_claim": True,
        },
        "synthetic_engineering_separate": {
            "tests": engineering["tests"],
            "native_optimizer_updates": engineering["synthetic_native_optimizer_updates"],
            "native_inference_calls": engineering["synthetic_native_inference_calls"],
        },
        "interpretation_limits": [
            "Full finite8-bit training-domain fit; scores control stopping and are not blind/heldout generalization.",
            "Input width, window and parameters changed together with question count, so no pure number-of-examples causal attribution.",
            "Finite-domain success cannot identify lookup versus copy/complement algorithm or internal routing.",
            "No longer-width probe; n9 requires context25 beyond current23.",
        ],
        "material_findings_remaining": [],
        "required_root_before_formal": "Verify public Git preregistration exact raw bytes and this exact manifest/source freeze, then one fresh formal output directory.",
        "reviewer_optimizer_calls": 0,
        "reviewer_model_forward_calls": 0,
        "reviewer_formal_students": 0,
        "external_model_calls": 0,
    }
    with (HERE / "pre-run.json").open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")
    print(canonical({"status": "passed", "manifest_sha256": args.approved_manifest_sha, "archive_entries": 9, "permutations": 120, "optimizer_and_forward_calls": 0}))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--approved-manifest-sha", required=True)
    parser.add_argument("--code-root", type=Path, required=True)
    parser.add_argument("--engineering", type=Path, required=True)
    main(parser.parse_args())
