"""Continuation-only audit layer over pinned, previously checked independent NumPy definitions."""
import argparse, ast, hashlib, io, json, math, os, platform, re, sys, time, zipfile
from collections import Counter
from pathlib import Path
if sys.flags.optimize: raise RuntimeError('Nonoptimized Python required')
os.environ['OPENBLAS_NUM_THREADS'] = os.environ['OMP_NUM_THREADS'] = '1'
sys.dont_write_bytecode = True
import numpy as np
HERE=Path(__file__).resolve().parent
APPROVED='3db5f30d1f32f47333674ee8eb456851087e62b4b49d8c331b318042fb7b8794'
CORE={'run_continue.py':'f5481161818ecf8edad221d55bd3a16a8c0d4fd4447a402bb5784acfd8db3639','protocol.json':'4deeff5fe415b899ec660744d83c0a5ab6bb1ca6bc4095d313cff31783445f5a','test_continue.py':'823f583675cc1f462c91f4f48ebb6a3c01e7241cff37cccfc95ded2efe804d38'}
PRIOR=HERE/'vendor/e3_probe_audit.py'
PRIOR_SHA='cff693544debfa6bbd730af6df20fe3bed2be7c667b2c6e2714879a2b2c8bc30'
VENDOR=HERE/'vendor/f2_stability_audit.py'
VENDOR_SHA='443ad00cb9cebe94c6cc5e22602f139586c35c7310e48623e21d515b2e72aacc'
SEEDS=(101,202,303);CLASSES=('E1','E2','F1','F2','E3')
FORWARD_MAC,TRAIN_MAC=10432,21056
WORD_FIELDS=('information5_correct','tail0_correct','complete6_correct')
CHURN_FIELDS=('previous_correct_to_wrong','previous_wrong_to_correct','retained_correct','retained_wrong')

def pure_math():
    raw=PRIOR.read_bytes();assert hashlib.sha256(raw).hexdigest()==PRIOR_SHA
    wanted={'borrow','names','readout','generation','teacher','churn','without'}
    nodes=[n for n in ast.parse(raw).body if isinstance(n,ast.FunctionDef) and n.name in wanted]
    assert {n.name for n in nodes}==wanted
    ns=dict(globals());exec(compile(ast.Module(body=nodes,type_ignores=[]),'<pinned-independent-E3-definitions>','exec'),ns)
    ns['M']=ns['borrow']()
    for n in ('need','canonical','digest','sha','finite','parse','read','write','equal','inventory','state_sha','same_state','Cost','Forward','counters','load_state'):ns[n]=ns['M'][n]
    return ns

M=pure_math()
for _n in ('need','canonical','digest','sha','finite','parse','read','write','equal','inventory','state_sha','same_state','Cost','counters','load_state','generation','teacher','readout','churn','without'):globals()[_n]=M[_n]

def inputs(a):
    need(sha(a.manifest)==APPROVED,'approved manifest');m=read(a.manifest)
    equal(m['source_hashes'],CORE,'manifest core');equal({n:sha(a.code_dir/n) for n in CORE},CORE,'actual core')
    equal(m['runtime'],{'python':platform.python_version(),'numpy':np.__version__,'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1'},'runtime')
    raw=(a.manifest.parent/'inputs.zip').read_bytes()
    need(digest(raw)==m['archive']['sha256']=='e2889728eccb95498df95cdcfdcf64e7eed5a9151b1e056f4d7c516ba3e1fde7' and len(raw)==4452849,'frozen ZIP')
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        need(len(z.namelist())==len(set(z.namelist()))==23,'23 inputs');c={n:z.read(n) for n in z.namelist()}
    equal({n:{'sha256':digest(b),'bytes':len(b)} for n,b in c.items()},m['files'],'member hashes')
    equal(c['plan.json'],(a.code_dir/'protocol.json').read_bytes(),'plan exact')
    rows,bank=parse(c['questions.json'].decode()),parse(c['payloads.json'].decode());need(len(rows)==4500 and len(bank)==900,'fixed bank')
    for qid,row in enumerate(rows):
        k,pair=divmod(qid,900);r=(1,2,1,2,3)[k];op='100' if k in (2,3) else '010';payload=bank[pair]
        word=lambda v:format(v,'05b')+'0'
        equal(row,{'question_id':qid,'pair_id':pair,'r':r,'payload':payload,'Q':'01'+op+format(r,'03b')+'0'+''.join(word(v) for v in payload)+'111100','A':''.join(word(31-v if op=='100' else v) for v in payload[:r]),'class':CLASSES[k],'op':op},'independent grammar')
    pool=np.asarray([(pair+900*k,pos) for pair in range(900) for k,count in enumerate((7,13,7,13,19)) for pos in range(count)],dtype='<u2')
    parents={}
    for seed,t in ((101,1070100),(202,1281600),(303,1215000)):
        parents[seed]=load_state(c[f'initial/seed{seed}.npz'],seed);need(int(parents[seed]['t'])==t,'parent t')
        equal(state_sha(parents[seed]),m['parents'][str(seed)]['full_state_sha256'],'complete parent canonical hash')
        rng=np.random.default_rng(seed+666000)
        need(np.array_equal(np.load(io.BytesIO(c[f'first-orders/seed{seed}.npy']),allow_pickle=False),pool[rng.permutation(53100)]),'original first order')
        orders=np.load(io.BytesIO(c[f'orders/seed{seed}.npy']),allow_pickle=False)
        need(orders.shape==(8,53100,2) and orders.dtype.str=='<u2','next8 shape')
        need(all(np.array_equal(o,pool[rng.permutation(53100)]) for o in orders),'exact next8 permutations')
    return m,c,rows,parents

BASE=('initial-state.npz','baseline-before.npz','baseline-after.npz','baseline-generation.json','baseline.json','final-state.npz','final-generation.json','curve.json','training-summary.json','final-truth.json','final-after-TF.npz')
EPOCH=('entry-state.npz','final-state.npz','generation.json','token-metrics.json','training.json','controller.json')

def preflight(a,bundle):
    m,c,rows,parents=bundle;science=a.work/'science'
    top={n:a.work/n for n in ('execution-receipt.json','execution.stdout.log','execution.stderr.log','git-prereg-receipt.json','formal-command-result.json')}
    need(all(p.is_file() for p in top.values()) and all((science/n).is_file() for n in ('compact.json','timing.json','execution-intent.json')),'metadata paths before NN')
    compact,receipt=read(science/'compact.json'),read(top['execution-receipt.json'])
    equal(receipt['status'],'exit0','formal exit0')
    for k,v in (('formal_exit',0),('exit_code',0),('session_id',a.formal_session),('command_invocations',1)):
        need(type(receipt[k]) is int and receipt[k]==v,'receipt '+k)
    equal(receipt['manifest_sha256'],APPROVED,'receipt manifest');equal(receipt['preregistration_commit'],a.preregistration_commit,'actual commit')
    equal(receipt['students'],compact['students'],'all students receipt');equal([s['seed'] for s in compact['students']],list(SEEDS),'all3 retained')
    epochs={s['seed']:s['epochs'] for s in compact['students']};need(all(type(e) is int and 1<=e<=8 for e in epochs.values()),'bounded epochs')
    updates=sum(epochs.values())*53100
    need(compact['status']=='complete' and compact['new_updates']==updates<=1274400 and compact['new_training_dense_MAC']==updates*TRAIN_MAC,'actual bounded updates')
    equal(receipt['new_optimizer_updates'],updates,'actual receipt updates');equal(receipt['new_training_dense_MAC'],updates*TRAIN_MAC,'actual receipt training MAC')
    need(compact['new_replay_updates']==compact['new_replay_training_dense_MAC']==0 and compact['exact_full_replays']==[],'no formal replay')
    for k in compact:
        if k.startswith('physical_'):equal(receipt[k],compact[k],'physical receipt '+k)
    command=read(top['formal-command-result.json']);equal((command['exit_code'],command['command_invocations'],command['formal_seconds']),(0,1,receipt['formal_seconds']),'actual command closure/time')
    git=read(top['git-prereg-receipt.json']);need(git['all_actual_bytes_verified'] is True and git['preregistration_commit']==a.preregistration_commit,'Git actual bytes')
    from datetime import datetime
    need(datetime.fromisoformat(receipt['prereg_PR_created_UTC'].replace('Z','+00:00'))<datetime.fromisoformat(receipt['intent_created_UTC'].replace('Z','+00:00')),'prereg before launch')
    equal(read(science/'execution-intent.json'),{'approved_manifest_sha256':APPROVED,'preregistration_commit':a.preregistration_commit,'source_hashes':CORE,'replay_seeds':[],'auto_retry':False},'native intent')
    expected={'compact.json','timing.json','execution-intent.json'}
    for seed,e in epochs.items():
        expected.update(f'seed{seed}/{n}' for n in BASE)
        expected.update(f'seed{seed}/epoch-{i:03}/{n}' for i in range(1,e+1) for n in EPOCH)
    inv=inventory(science);equal(set(inv),expected,'complete actual science inventory')
    states={p:load_state((science/p).read_bytes(),int(p.split('/')[0][4:])) for p in inv if p.endswith('.npz')}
    logs=[parse(line) for line in top['execution.stdout.log'].read_text(encoding='utf-8-sig').splitlines() if line.strip()]
    equal(logs[-1],compact,'stdout compact');need(len(logs)==sum(epochs.values())+1 and top['execution.stderr.log'].stat().st_size==0,'progress count/stderr')
    timing=read(science/'timing.json');need(len(timing['epoch_trajectories'])==sum(epochs.values()),'actual epoch timings')
    for seed,e in epochs.items():
        folder=science/f'seed{seed}';truth=read(folder/'final-truth.json')
        need(len(truth['truth'])==4500 and truth['inference_calls']==sum(len(r['TF']) for r in truth['truth'])==53100,'all final TF shape')
        for i in range(1,e+1):
            trace=read(folder/f'epoch-{i:03}/training.json')['training']
            need(trace['targets']==53100 and 0<=trace['pre_update_prediction_correct']<=53100 and trace['CE_loss_sum']>=0,'recorded training aggregate')
            need(trace['CE_loss_mean']==trace['CE_loss_sum']/53100 and re.fullmatch('[0-9a-f]{64}',trace['canonical_target_trace_sha256']),'aggregate mean/digest form')
    guards={n:{'bytes':p.stat().st_size,'sha256':sha(p)} for n,p in top.items()}
    for n in ('root-intent.json','execution-intent.json','execution-start.json'):
        if (a.work/n).is_file():guards[n]={'bytes':(a.work/n).stat().st_size,'sha256':sha(a.work/n)}
    write(a.out/'metadata-preflight.json',{'status':'passed','manifest_sha256':APPROVED,'source_hashes':CORE,'formal_session':a.formal_session,'preregistration_commit':a.preregistration_commit,'receipt_sha256':guards['execution-receipt.json']['sha256'],'root_confirmed_formal_exit0':True,'science_files':len(inv),'NPZ':len(states),'epochs':epochs,'all_paths_schema_checked_before_NN':True,'forward_calls':0})
    return compact,receipt,inv,guards,states,timing,logs

def proof(a,cost,seed,point,value):
    write(a.out/'numeric-proof'/f'seed{seed}-{point}.json',{'status':'passed','seed':seed,'point':point,'strict_equality':True,**value,'audit_cost_cumulative':cost.record()});cost.persist('running')

def audit_seed(a,cost,seed,bundle,context):
    m,c,rows,parents=bundle;compact,receipt,inv,guards,states,timing,logs=context
    folder=a.work/'science'/f'seed{seed}';get=lambda n:states[f'seed{seed}/'+n]
    parent=parents[seed];inf={'meta_inference_calls','meta_inference_macs'}
    equal((folder/'initial-state.npz').read_bytes(),c[f'initial/seed{seed}.npz'],'initial raw parent')
    same_state(get('initial-state.npz'),parent,'initial complete parent');same_state(get('baseline-before.npz'),parent,'baseline starts parent')
    baseline=generation(parent,rows,cost,f'seed{seed}_baseline')
    equal(baseline,read(folder/'baseline-generation.json'),'all baseline free');equal(baseline,parse(c[f'historical/seed{seed}.json'].decode()),'historical nonperfect baseline exact')
    current=get('baseline-after.npz');without(parent,current,inf,'baseline immutable learningstate')
    need(counters(current)['inference_calls']-counters(parent)['inference_calls']==baseline['inference_calls'],'baseline counterdelta')
    base_record={'seed':seed,'archived_generation_exact':True,'scores':baseline['scores'],'inference_calls':baseline['inference_calls'],'inference_MAC':baseline['inference_dense_MAC'],'baseline_streak':0,'new_updates':0,'learning_state_unchanged':True}
    equal(base_record,read(folder/'baseline.json'),'baseline record')
    proof(a,cost,seed,'baseline',{'whole_questions':4500,'scores':baseline['scores'],'inference_calls':baseline['inference_calls'],'state_sha256':state_sha(current)})
    previous=baseline;streak=0;first_E3=first_all=stable=None;curve=[];events=[]
    total_epochs=next(s['epochs'] for s in compact['students'] if s['seed']==seed)
    immutable={'L','H','meta_seed','meta_events','growth_rng',*(f'birth{i}' for i in range(4))}
    for epoch in range(1,total_epochs+1):
        point=folder/f'epoch-{epoch:03}';entry,end=get(f'epoch-{epoch:03}/entry-state.npz'),get(f'epoch-{epoch:03}/final-state.npz')
        same_state(entry,current,'next epoch fullstate exact')
        same_state({k:entry[k] for k in immutable},{k:end[k] for k in immutable},'immutable metadata/birth/RNG')
        need(int(end['t'])-int(entry['t'])==53100 and int(end['meta_train_macs'])-int(entry['meta_train_macs'])==1118073600,'epoch step/MACdelta')
        free=generation(end,rows,cost,f'seed{seed}_epoch{epoch:03}');equal(free,read(point/'generation.json'),'all epoch ownoutput')
        metrics=readout(rows,free['rows']);equal(metrics,read(point/'token-metrics.json'),'all word3/bit/STOP/firsterror readout')
        need(counters(end)['inference_calls']-counters(entry)['inference_calls']==free['inference_calls'],'epoch inference delta')
        train=read(point/'training.json')
        equal(train,{'seed':seed,'arm':'eta001','eta':.001,'entry_shared_state_sha256':state_sha(entry),'parent_counters':counters(parent),'entry_counters':counters(entry),'endpoint_counters':counters(end),'new_updates':53100,'new_training_dense_MAC':1118073600,'training':train['training'],'scores':free['scores'],'new_probe_inference_calls':free['inference_calls'],'new_probe_inference_MAC':free['inference_dense_MAC'],'full_state_sha256':state_sha(end),'replay_status':'not_planned','shared_baseline_cost_billed_in_this_arm':False},'unchanged original training record')
        full=all(free['scores'][n]=={'questions':900,'whole_correct':900} for n in CLASSES);streak=streak+1 if full else 0
        if first_E3 is None and free['scores']['E3']['whole_correct']==900:first_E3=epoch
        if first_all is None and full:first_all=epoch
        if streak>=2:stable=epoch
        reason='two_consecutive_new_epoch_all_class_passes' if streak>=2 else 'epoch_cap' if epoch==8 else None
        status={'epoch':epoch,'streak':streak,'all_five_full':full,'first_E3_full_epoch':first_E3,'first_all_five_full_epoch':first_all,'stable_pass_epoch':stable,'stop_reason':reason,'cumulative_new_updates':epoch*53100,'cumulative_new_training_dense_MAC':epoch*1118073600,'scores':free['scores'],'churn':churn(rows,previous['rows'],free['rows'])}
        equal(status,read(point/'controller.json'),'independent stop/reset/firstfull/churn')
        need((reason is None)==(epoch<total_epochs),'stop at exact first permitted decision')
        curve.append(status);events.append({'seed':seed,'epoch':epoch,'scores':free['scores'],'streak':streak,'stop':reason})
        proof(a,cost,seed,f'epoch-{epoch:03}',{'whole_questions':4500,'inference_calls':free['inference_calls'],'controller':status,'metrics':metrics['by_class'],'per_question_readout_sha256':digest(canonical(metrics['per_question']).encode()),'state_sha256':state_sha(end)})
        current,previous=end,free
    equal(curve,read(folder/'curve.json'),'all curve decisions')
    equal((folder/'final-state.npz').read_bytes(),(folder/f'epoch-{total_epochs:03}/final-state.npz').read_bytes(),'last state rawcopy')
    same_state(current,get('final-state.npz'),'final state same');equal(previous,read(folder/'final-generation.json'),'reuse last free')
    summary={'seed':seed,'epochs':total_epochs,'stop_reason':reason,'first_E3_full_epoch':first_E3,'first_all_five_full_epoch':first_all,'stable_pass_epoch':stable,'streak':streak,'new_updates':total_epochs*53100,'new_training_dense_MAC':total_epochs*1118073600,'final_scores':curve[-1]['scores'],'parent_counters':counters(parent),'preTF_final_counters':counters(current),'replay_status':'not_planned'}
    equal(summary,read(folder/'training-summary.json'),'training summary')
    tf=teacher(current,rows,previous,cost,f'seed{seed}_finalTF');equal(tf,read(folder/'final-truth.json'),'all finalTF exact logits/probs/CE')
    final=get('final-after-TF.npz');without(current,final,inf,'TF immutable learningstate')
    need(counters(final)['inference_calls']-counters(current)['inference_calls']==53100,'single finalTF counterdelta')
    summary.update(TF_metrics=tf['metrics'],final_TF_inference_calls=53100,final_TF_inference_MAC=53100*10432,baseline=base_record,final_counters=counters(final))
    equal(summary,next(s for s in compact['students'] if s['seed']==seed),'full student summary')
    proof(a,cost,seed,'student',{'whole_questions_free_not_repeated':4500,'TF_targets':53100,'TF_metrics':tf['metrics'],'stop_reason':reason,'epochs':total_epochs,'stable_pass_epoch':stable,'final_state_sha256':state_sha(final)})
    return summary,events

def run(a,cost):
    bundle=inputs(a);context=preflight(a,bundle);cost.persist('metadata_passed')
    guarded={str(p):sha(p) for p in (Path(__file__),PRIOR,VENDOR,a.manifest,a.manifest.parent/'inputs.zip',*(a.code_dir/n for n in CORE))}
    results=[audit_seed(a,cost,seed,bundle,context) for seed in SEEDS];students=[r[0] for r in results]
    compact,receipt,inv,guards,states,timing,logs=context
    equal([e for _,events in results for e in events],logs[:-1],'actual progress events independently verified')
    epochs=sum(s['epochs'] for s in students);base=sum(s['baseline']['inference_calls'] for s in students)
    probe=sum(cost.phases[f'seed{s}_epoch{e:03}'] for s in SEEDS for e in range(1,next(x['epochs'] for x in students if x['seed']==s)+1))
    expected={'id':'E3-CONTINUE8-20261113','status':'complete','students':students,'new_updates':epochs*53100,'new_training_dense_MAC':epochs*1118073600,'stable_pass_seeds':[s['seed'] for s in students if s['stable_pass_epoch'] is not None],'physical_baseline_inference_calls':base,'physical_epoch_probe_inference_calls':probe,'physical_final_TF_inference_calls':159300,'physical_new_inference_calls_total':base+probe+159300,'physical_new_inference_MAC_total':(base+probe+159300)*10432,'new_replay_updates':0,'new_replay_training_dense_MAC':0,'exact_full_replays':[],'external_model_calls':0}
    equal(compact,expected,'complete summary/cost recomputation')
    need(cost.calls==expected['physical_new_inference_calls_total'],'no duplicate free or TF audit')
    equal(inventory(a.work/'science'),inv,'all science unchanged');equal({p:sha(Path(p)) for p in guarded},guarded,'all source/input/auditdefs unchanged')
    equal({n:{'bytes':(a.work/n).stat().st_size,'sha256':sha(a.work/n)} for n in guards},guards,'formal receipt/log/intent unchanged')
    refs=sorted(p.relative_to(a.out).as_posix() for p in (a.out/'numeric-proof').iterdir());need(len(refs)==epochs+6,'bounded complete proofs')
    proof_inventory={n:{'bytes':(a.out/n).stat().st_size,'sha256':sha(a.out/n)} for n in refs}
    details={'status':'passed','manifest_sha256':APPROVED,'source_hashes':CORE,'pure_vendor_sha256':{'e3_probe_audit.py':PRIOR_SHA,'f2_stability_audit.py':VENDOR_SHA},'root_confirmed_formal_exit0':True,'receipt_sha256':guards['execution-receipt.json']['sha256'],'science_file_inventory':inv,'numeric_proof_refs':refs,'numeric_proof_inventory':proof_inventory,'students':students,'audit_cost':cost.record(),'formal_seconds':receipt['formal_seconds'],'timing':timing,'sources_inputs_science_receipts_unchanged':True}
    write(a.out/'post-run-details.json',details)
    report={'schema':'e3-continuation-independent-post-run-v1','status':'passed','manifest_sha256':APPROVED,'source_hashes':CORE,'review_source_sha256':sha(Path(__file__)),'root_confirmed_formal_exit0':True,'formal_session':a.formal_session,'preregistration_commit':a.preregistration_commit,'receipt_sha256':details['receipt_sha256'],'free_questions_independently_generated':(epochs+3)*4500,'TF_targets_independently_recomputed':159300,'strict_equality':True,'optimizer_calls':0,'new_students':0,'actual_training_replays':0,'epochs':epochs,'science_files':len(inv),'proofs':len(refs),'students':[{k:s[k] for k in ('seed','epochs','first_E3_full_epoch','first_all_five_full_epoch','stable_pass_epoch','stop_reason','final_scores')} for s in students],'audit_cost':cost.record(),'details_sha256':sha(a.out/'post-run-details.json'),'limits':['Exact independent inference/readout and counter/source audit only; training aggregate digest is source/provenance/form checked, not a gradient or optimizer replay.','Finite previously exposed bank and inherited low-rate states; cap is bounded nonattainment, stability is two new epoch taskbank passes.']}
    write(a.out/'post-run.json',report);cost.persist('passed');return report

def main():
    p=argparse.ArgumentParser(description=__doc__)
    for n in ('work','code-dir','manifest','out'):p.add_argument('--'+n,type=Path,required=True)
    p.add_argument('--formal-session',type=int,required=True);p.add_argument('--preregistration-commit',required=True);p.add_argument('--root-confirmed-exit0',action='store_true')
    a=p.parse_args();need(a.root_confirmed_exit0 and re.fullmatch('[0-9a-f]{40}',a.preregistration_commit),'explicit root POST-GO')
    for n in ('work','code_dir','manifest','out'):setattr(a,n,getattr(a,n).resolve())
    need(not any((a.out/n).exists() for n in ('audit-cost.json','metadata-preflight.json','numeric-proof','post-run.json','post-run-details.json')),'one actual audit only')
    (a.out/'numeric-proof').mkdir();cost=Cost(a.out);cost.persist('starting_metadata_only')
    try:
        r=run(a,cost);print(canonical({'status':r['status'],'epochs':r['epochs'],'students':r['students'],**cost.record()}),flush=True)
    except Exception as e:
        cost.persist('failed');write(a.out/'audit-failure.json',{'status':'failed','type':type(e).__name__,'message':str(e),'actual_cost':cost.record(),'retry_authorized':False});raise
if __name__=='__main__':main()
