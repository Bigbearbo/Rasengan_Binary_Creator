"""Bounded zero-NN gate for the frozen continuation controller."""
import ast
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import shutil
import sys
import zipfile
os.environ['OPENBLAS_NUM_THREADS'] = os.environ['OMP_NUM_THREADS'] = '1'
sys.dont_write_bytecode = True
import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
CODE = ROOT/'outputs/e3-continuation'
PREREG = HERE.parent/'prereg'
APPROVED = '3db5f30d1f32f47333674ee8eb456851087e62b4b49d8c331b318042fb7b8794'
ZIP_SHA = 'e2889728eccb95498df95cdcfdcf64e7eed5a9151b1e056f4d7c516ba3e1fde7'
CORE = {'run_continue.py':'f5481161818ecf8edad221d55bd3a16a8c0d4fd4447a402bb5784acfd8db3639',
        'protocol.json':'4deeff5fe415b899ec660744d83c0a5ab6bb1ca6bc4095d313cff31783445f5a',
        'test_continue.py':'823f583675cc1f462c91f4f48ebb6a3c01e7241cff37cccfc95ded2efe804d38'}

def sha(raw): return hashlib.sha256(raw).hexdigest()
def record(path): return {'sha256':sha(path.read_bytes()),'bytes':path.stat().st_size}

def main():
    assert not sys.flags.optimize
    assert {n:sha((CODE/n).read_bytes()) for n in CORE} == CORE
    mraw, zraw = (PREREG/'manifest.json').read_bytes(), (PREREG/'inputs.zip').read_bytes()
    assert sha(mraw) == APPROVED and sha(zraw) == ZIP_SHA and len(zraw) == 4452849
    m = json.loads(mraw)
    assert m['source_hashes'] == CORE
    with zipfile.ZipFile(io.BytesIO(zraw)) as z:
        assert len(z.namelist()) == len(set(z.namelist())) == 23
        contents = {n:z.read(n) for n in z.namelist()}
    assert {n:{'sha256':sha(b),'bytes':len(b)} for n,b in contents.items()} == m['files']
    vendor_ast = ast.parse(contents['vendor/run_probe.py'])
    expected_defs = {n.name:sha(ast.dump(n,include_attributes=False).encode()) for n in vendor_ast.body if isinstance(n,ast.FunctionDef) and n.name in m['reused_def_AST_sha256']}
    assert len(expected_defs) == 21 and expected_defs == m['reused_def_AST_sha256']
    rows = json.loads(contents['questions.json'])
    assert len(rows) == 4500
    pool = np.asarray([(pair+900*k,pos) for pair in range(900) for k,count in enumerate((7,13,7,13,19)) for pos in range(count)],dtype='<u2')
    for seed,t in ((101,1070100),(202,1281600),(303,1215000)):
        rng = np.random.default_rng(seed+666000)
        first = np.load(io.BytesIO(contents[f'first-orders/seed{seed}.npy']),allow_pickle=False)
        assert np.array_equal(first,pool[rng.permutation(53100)])
        orders = np.load(io.BytesIO(contents[f'orders/seed{seed}.npy']),allow_pickle=False)
        assert orders.dtype.str == '<u2' and orders.shape == (8,53100,2)
        assert all(np.array_equal(order,pool[rng.permutation(53100)]) for order in orders)
        with np.load(io.BytesIO(contents[f'initial/seed{seed}.npz']),allow_pickle=False) as z:
            state = {n:z[n].copy() for n in z.files}
        assert len(state) == 25 and int(state['t']) == t and int(state['meta_seed']) == seed
        assert all(np.isfinite(v).all() for v in state.values() if v.dtype.kind in 'fiu')
        assert int(state['meta_train_macs']) == t*21056
        assert int(state['meta_inference_macs']) == int(state['meta_inference_calls'])*10432
    fresh = HERE/'portable-bundle'
    fresh.mkdir()
    (fresh/'tool').mkdir(); (fresh/'prereg').mkdir()
    for name in CORE: shutil.copyfile(CODE/name,fresh/'tool'/name)
    for name in ('manifest.json','inputs.zip'): shutil.copyfile(PREREG/name,fresh/'prereg'/name)
    tracked = [*sorted((fresh/'tool').iterdir()),*sorted((fresh/'prereg').iterdir())]
    before = {p.relative_to(fresh).as_posix():record(p) for p in tracked}
    original_before = {str(p):record(p) for p in [*(CODE/n for n in CORE),PREREG/'manifest.json',PREREG/'inputs.zip']}
    armed = [True]; rejected = []; attempts = []
    def audit(event,args):
        if not armed[0] or event != 'open' or not isinstance(args[0],(str,bytes,os.PathLike)): return
        p = Path(os.fsdecode(args[0])).resolve()
        if p.is_relative_to(ROOT) and not p.is_relative_to(fresh):
            rejected.append('original_workspace_open')
            raise PermissionError('Original workspace reads/writes blocked during portable validation')
    def profile(frame,event,arg):
        if event == 'call' and frame.f_code.co_filename == '<P030-single-eta-arm>' and frame.f_code.co_name in ('forward','step','loss_grad','lesson','generate','grow'):
            attempts.append(frame.f_code.co_name)
            raise AssertionError('NN entry forbidden in portable gate')
    def blocked(*args,**kwargs):
        attempts.append('blocked_NN_method')
        raise AssertionError('No model inference/optimizer in zero-NN gate')
    sys.addaudithook(audit)
    try:
        try: (CODE/'protocol.json').read_bytes()
        except PermissionError: pass
        else: raise AssertionError('Original workspace denial positive control failed')
        assert rejected == ['original_workspace_open']
        spec=importlib.util.spec_from_file_location('continuation_portable',fresh/'tool/run_continue.py')
        module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        original_vendor=module.vendor
        def guarded_vendor(*args):
            v,defs=original_vendor(*args); maker=v.model_classes
            def guarded_classes(*args):
                result=maker(*args)
                for cls in result[0].values():
                    for name in ('forward','step','loss_grad','lesson','generate','grow'):
                        if hasattr(cls,name): setattr(cls,name,blocked)
                return result
            v.model_classes=guarded_classes
            return v,defs
        module.vendor=guarded_vendor
        sys.setprofile(profile)
        actual,_,data=module.validate_inputs(fresh/'prereg/manifest.json',APPROVED)
        sys.setprofile(None)
        assert actual == m and data[8] == expected_defs
        assert attempts == [] and rejected == ['original_workspace_open']
    finally:
        sys.setprofile(None);armed[0]=False
    assert {p.relative_to(fresh).as_posix():record(p) for p in tracked} == before
    assert {p:record(Path(p)) for p in original_before} == original_before
    engineering=json.loads((HERE.parent/'engineering/checks.json').read_text(encoding='utf-8'))
    assert engineering['status']=='passed' and engineering['tests']==4 and engineering['source_hashes']==CORE
    assert all(engineering[n]==0 for n in ('synthetic_forward_calls','synthetic_optimizer_updates','trained_forward_calls','trained_optimizer_calls'))
    report={'schema':'e3-continuation-independent-pre-run-v1','status':'passed','manifest_sha256':APPROVED,'source_hashes':CORE,'inputs_zip_sha256':ZIP_SHA,
            'members':23,'finite_parent_states':3,'frozen_new_epoch_orders':24,'teacher_targets_per_order':53100,'reused_def_AST_count':21,
            'native_validate_inputs_fresh_bundle':True,'original_workspace_denial_positive_control_passed':True,'original_workspace_reads_during_validation':0,
            'blocked_model_NN_attempts':0,'profile_NN_entries':0,'trained_forward_calls':0,'optimizer_calls':0,'new_students':0,
            'portable_files_unchanged':5,'original_source_inputs_unchanged':True,'author_engineering':{'tests':4,'status':'passed','mock_epochs_not_NN':5,'synthetic_forward_calls':0,'synthetic_optimizer_updates':0,'repeated_by_reviewer':False},
            'static_checks':['All3 archived baseline generation equality before any optimizer; preexisting errors allowed.','Baseline streak0; all5 classes each900 includingSTOP for2new epochs; reset/cap/firstfull/stable distinct.','Same parent complete state and previous epoch fullstate/counters carried; t/Adam/birth/RNG not reset.','Original first order verified then exactly next8 frozen permutations, same bank/Model/eta001.','After all3 stop/cap: finalTF once perseed, reuse last free outputs, inherited counters not rebilled.','No optimizer replay; source/targettrace digest provenance does not claim independent gradient reconstruction.'],
            'material_findings':[],'review_source_sha256':sha(Path(__file__).read_bytes())}
    with (HERE/'pre-run.json').open('x',encoding='utf-8',newline='\n') as f: json.dump(report,f,sort_keys=True,indent=2);f.write('\n')
    print(json.dumps({'status':'passed','manifest_sha256':APPROVED,'trained_forward_calls':0,'optimizer_calls':0,'report_sha256':sha((HERE/'pre-run.json').read_bytes())}),flush=True)

if __name__=='__main__': main()
