"""Read saved tokens only; no model import, forward or optimizer."""
import json
from pathlib import Path
import zipfile

root = Path(__file__).resolve().parent
with zipfile.ZipFile(root / 'prereg/inputs.zip') as archive:
    rows = json.loads(archive.read('questions.json'))
out = []
for seed in (101, 202, 303):
    folder = root / 'science' / f'seed{seed}'
    baseline = json.loads((folder / 'baseline-generation.json').read_text(encoding='utf-8'))
    final = json.loads((folder / 'final-generation.json').read_text(encoding='utf-8'))
    curve = json.loads((folder / 'curve.json').read_text(encoding='utf-8'))
    maps = [{x['question_id']: x['tokens'] for x in g['rows']} for g in (baseline, final)]
    churn = {}
    for cls in ('E1', 'E2', 'F1', 'F2', 'E3'):
        ids = {k: [] for k in ('retained_correct', 'newly_wrong', 'recovered', 'retained_wrong')}
        for row in rows:
            if row['class'] != cls:
                continue
            qid, expected = row['question_id'], row['A'] + 'S'
            before, after = (m[qid] == expected for m in maps)
            key = 'retained_correct' if before and after else 'newly_wrong' if before else 'recovered' if after else 'retained_wrong'
            ids[key].append(qid)
        churn[cls] = {'counts': {k: len(v) for k, v in ids.items()}, 'QIDs': ids}
    old = ('E1', 'E2', 'F1', 'F2')
    out.append({'seed': seed, 'baseline_E3': baseline['scores']['E3']['whole_correct'],
                'final_E3': final['scores']['E3']['whole_correct'],
                'old_wrong_baseline': 3600 - sum(baseline['scores'][c]['whole_correct'] for c in old),
                'old_wrong_final': 3600 - sum(final['scores'][c]['whole_correct'] for c in old),
                'old_newly_wrong': sum(churn[c]['counts']['newly_wrong'] for c in old),
                'old_recovered': sum(churn[c]['counts']['recovered'] for c in old),
                'E3_curve': [p['scores']['E3']['whole_correct'] for p in curve],
                'old_wrong_curve': [3600 - sum(p['scores'][c]['whole_correct'] for c in old) for p in curve],
                'baseline_to_endpoint_churn': churn})
payload = {'NN_calls': 0, 'optimizer_calls': 0, 'source': 'Saved baseline/final token strings and epoch scores', 'students': out}
with (root / 'derived-readout.json').open('x', encoding='utf-8') as stream:
    json.dump(payload, stream, indent=2)
    stream.write('\n')
print(json.dumps([{k: v for k, v in s.items() if k != 'baseline_to_endpoint_churn'} for s in out]))
