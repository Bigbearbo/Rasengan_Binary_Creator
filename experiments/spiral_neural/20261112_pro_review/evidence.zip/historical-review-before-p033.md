# Historical ChatGPT Pro review — before P033 PR #7

This preserves the prior read-only review. Its pending P033 status and no-remote-write statement describe that earlier review, not the current publication. See the repository CURRENT_RESEARCH_STATUS.md and PRO_RESEARCH_DESIGN_20261112.md for the updated conclusions.

# Git 研究審查與 P033 唯讀診斷

日期：2026-11-12（Asia/Taipei）
倉庫：[Bigbearbo/Rasengan_Binary_Creator](https://github.com/Bigbearbo/Rasengan_Binary_Creator)
任務：閱讀 Git 原始資料並提出建議；本輪未修改或推送遠端、未合併 PR、未重新訓練神經網路。

## 1. 固定證據版本

| 研究線 | 本輪固定版本 | 狀態 |
|---|---|---|
| main／P033 計畫 | 9118abf4e895204588f7c5aa1bfc2615d0ab52b8 | 從第一課混教已列入，尚未有新訓練結果 |
| P031 共用題庫，PR #5 | cee9fb7c331f23d9b7495f7240cc45060c19838d | 題庫與接口已實作；本輪17/17工程測試通過 |
| P032，PR #6 | f003980f719f84b366cda13601091ecf8c256d51 | 原有24組訓練已完成；本輪只讀診斷 |
| 最新已見 VM 停止原因分支 | 44d23b934dbea141e436c24e52b60a500d09e162 | 比 PR #2 的原始匯入更新；本輪靜態閱讀，未重跑其10個VM測試 |
| 解析器 | main 的 experiments/spiral_parser | 乾淨下載執行75項：56通過、19缺檔；先生成前置狀態後75/75通過 |

U：作者既有構想；F：倉庫原始材料；T：本輪真實執行結果；A：本輪建議或假說。不要將本輪 A 倒填為作者原始意思。

## 2. P032 新診斷：中位錯誤不能主要推給生成級聯（T）

載入原封存36份 checkpoint，其中12份是暖身結束、24份是加入Neg後的模型。逐題重算480筆，做4320組單位元翻轉探測；24份加入Neg後的模型，其自由生成與正確前綴下的逐位預測均吻合原封存。沒有訓練；模型權重、Adam狀態、RNG與原檔保持不變。

三個資訊位按高、中、低排列，中位記為 b1。加入Neg後的 test 共48筆模型×算符評估（24份checkpoint各測Echo/Neg），不是48道互相獨立的新題。

| 項目 | 本輪重算 |
|---|---:|
| 第一次答錯就在最高資訊位 | 8/48 |
| 第一次答錯就在中間資訊位 | 38/48 |
| 整題完全正確 | 2/48 |
| 自由生成的中位正確 | 10/48 |
| 餵正確先前答案後，中位正確 | 2/48 |
| 同一條件下，val中位正確 | 48/48 |

因此錯誤並非主要由前面輸出錯誤一路帶偏；中位本身的映射已有直接失敗。某些自由生成前綴甚至偶然使中位答對，但整題仍錯。val與test的資料中位恰好分別固定為0與1，不能只用整體平均掩蓋這個差別。

進一步以相同模型、算符及正確首答案位，將S0的值4改成6、S1的值5改成7。這只翻轉輸入中位，而且共同答案前綴對兩題都合法。48/48探測的0/1 logit差都朝正確方向改變，只有2/48真的改變輸出決策。

具體例：S0、seed101、H72、neg70、Echo。Q從010001000改為010001100，共同首答案位為1；logit(1)-logit(0)從-13.3538升到-3.2344，模型仍選0。可說模型對該輸入位有功能性敏感度；不可說它完全沒讀到該位，也不可據此斷言已懂正確算法。

[更新] 中位本身已有直接預測錯誤；模型有讀到對應位元的影響，但通常不足以改變決策。
[取代] 將中位錯誤主要解釋成前面答錯的連鎖結果，或直接說模型完全忽略該輸入位。兩者原本都只是候選解釋。
[原因] 正確前綴下中位仍僅2/48正確；合法位元翻轉48/48方向正確、僅2/48改變決策。
[狀態] 觀測結果信心高；是哪個上下文關聯壓過正確訊號、以及教材缺口的因果作用，仍待干預實驗。

這完成 P033-D 的部分唯讀診斷，不代表 P033 全部完成。一般敏感度矩陣中 input_bit < output_bit 的探測會刻意使用不一致前綴；它們不當成合法教學題。上述48組中位對照沒有這個問題。

## 3. P031 題庫合法，但預設分割不能直接當啟蒙課程（F/T/A）

本輪直接執行 PR #5 的 run_checks.py：17/17 PASS。重新生成1,342筆題目、15個profile、288個語義群；雙回呼收取的raw位元SHA相同。這是工程與傳輸驗收，未執行真VM解題或新NN訓練。

枚舉其預設 SHA 分割後：

| 階段／算符 | train | val | test |
|---|---|---|---|
| 1資訊位 Echo | 0 | 1 | 無 |
| 2資訊位 Echo | 0,3 | 1,2 | 無 |
| 3資訊位 Echo | 0,3,7 | 1,2,4 | 5,6 |
| 3資訊位 Neg | 0,1,2,3,4,5,6 | 無 | 7 |

README已說明小集合不保證精確比例，因此這不是未揭露的分割錯誤；新發現是它對實際啟蒙教學的影響。如果第一課只給0→0，教材本身無法區分「照抄」和「恆輸出零」，不應將未能外推到1全歸咎於容量。

建議保留現有題庫封存，另立教學manifest：最初0/1作完整啟蒙例，明記沒有當階盲測；之後在更大值域預留未見組合，並檢查每個算符、每一資訊位的0/1覆蓋、所需位元組合及非空評估集。早期教過的語義值要進跨階曝光台帳，不能升階後換碼就再稱未見。

P031沒有用來訓練P032。這項建議針對下一輪共用題庫教學，不是P032失敗的回溯原因。

## 4. 解析器乾淨重播入口缺前置資料（T）

固定main原始README指令，75測例中19個FileNotFoundError。18個需要spiral_dialogue_v03_run/teacher_tree.json，1個需要student_tree.json。Git只提交了另一個位置的student fixture，沒有測試直接讀取的run目錄。

在獨立暫存副本先執行：

```sh
python -B spiral_dialogue_v03.py --out spiral_dialogue_v03_run
python -B -m unittest -q test_spiral_parser test_spiral_dialogue test_spiral_dialogue_v02 test_spiral_dialogue_v03 test_spiral_tree_packet_v04 test_spiral_tree_packet_v05 test_spiral_tree_nodes_v06
```

結果75/75 PASS。高信心結論是公開重播入口漏初始化依賴；不能說解析算法壞了，也不能否定原始封存環境曾通過。

最小修正是補bootstrap；較穩的修正是測試在臨時目錄自建合成狀態或讀取明確提交的fixture，再將乾淨下載的測試接進CI。目前CMake根目錄缺CMakeLists是既有已知問題，本輪未把它當新發現。

## 5. 優先執行建議（A）

研究：沿用P033的教材覆蓋×教學時序控制，先不再增加寬度與算符。將計畫已有的T0B「先Echo，再混教新舊」提升為主要基準，與「從第一課混教」比較；固定合法profile、初始模型與相同訓練多重集合。純Echo→純Neg可保留為輔助對照，避免主結論只是較容易忘記的極端順序輸給混教。保持同曝光、題次、target-token更新與成本紀錄，觀察未見值、首錯位與b1的決策邊際。

工程：先修解析器的乾淨重播入口，再把P031題庫接入一條真正VM客體執行、回覆、評分與錯答記憶的完整路徑。最新VM分支已處理ptr-only revision、typed stop reason與失敗仍付成本；不要重做。尚待正式入口整合、避免同次嘗試重複use_hp結算，這是分支本來已有的下一步。保留全拷貝參考版本作可成長實作的正確性對照。

協作：落實既有current與派工MVP，先讓新視窗只讀短現況就能找到目前SHA／PR、證據與下一步。主README與AGENTS連同一份現況，歷史文件保持原貌。Git可見分支尚無可驗收的dispatcher／共用記憶MVP，不能據此推斷使用者本機沒做。一次真任務的「讀來源→派工→驗證→保存→重啟找回」比再增加規格長文更值得先做。

記憶驗收可用四題：P032究竟測了哪種混教？從第一課混教有沒有跑？PR #5的題庫有沒有拿去教P032？位元組合缺口與其因果作用分別有什麼證據？不要讓舊摘要洗掉這些區分。

## 6. 重跑材料與邊界

本包只含新審查程式、合成輸出、實跑日誌、來源雜湊與本報告；原始倉庫與checkpoint仍以固定Git版本為準，未再打包整份repo。

```sh
git clone https://github.com/Bigbearbo/Rasengan_Binary_Creator.git repo
git -C repo worktree add --detach ../p031 cee9fb7c331f23d9b7495f7240cc45060c19838d
git -C repo worktree add --detach ../p032 f003980f719f84b366cda13601091ecf8c256d51
python -B audit_bank.py --bank-code ../p031/experiments/spiral_teaching/math_benchmark --out p031-audit-new.json
python -B review_probe.py --p032-dir ../p032/experiments/spiral_neural/20261112_p032 --out p032-probe-new
```

路徑按實際解壓位置調整。audit_bank只需Python標準庫；神經probe需NumPy，先驗p032.py、p030_reference.py及evidence.zip的Git blob身份。neural/manifest.json記本輪版本與所有輸出雜湊。

本輪NVIDIA：nvidia_status=skipped_unavailable；呼叫0次；目前工作環境沒有已配置的OpenRouter/NVIDIA呼叫工具或相應憑證環境變數，不能存取使用者Windows本機配置。使用本環境三個研究子任務獨立閱讀、Python實測與主代理核對，不冒稱NVIDIA參與。本輪新診斷不是新訓練、不是新盲測、不是自主習得成果。

## 原始來源

[P033計畫](https://github.com/Bigbearbo/Rasengan_Binary_Creator/blob/9118abf4e895204588f7c5aa1bfc2615d0ab52b8/docs/ai_orchestration/P033_位元組合覆蓋與泛化干擾診斷_20261112.md)

[P032 PR #6](https://github.com/Bigbearbo/Rasengan_Binary_Creator/pull/6)

[P031 PR #5](https://github.com/Bigbearbo/Rasengan_Binary_Creator/pull/5)

[P031 teacher.py](https://github.com/Bigbearbo/Rasengan_Binary_Creator/blob/cee9fb7c331f23d9b7495f7240cc45060c19838d/experiments/spiral_teaching/math_benchmark/teacher.py)

[解析器README](https://github.com/Bigbearbo/Rasengan_Binary_Creator/blob/9118abf4e895204588f7c5aa1bfc2615d0ab52b8/experiments/spiral_parser/README.md)

[VM最新決策](https://github.com/Bigbearbo/Rasengan_Binary_Creator/blob/44d23b934dbea141e436c24e52b60a500d09e162/experiments/hamu_vm/DECISIONS.md)

[共用記憶實作計畫](https://github.com/Bigbearbo/Rasengan_Binary_Creator/blob/9118abf4e895204588f7c5aa1bfc2615d0ab52b8/docs/ai_orchestration/CODEX_MULTI_AGENT_MEMORY_PLAN_20261112.md)

