"""Read only prior source/report metadata. No model imports or inference."""
import hashlib
import json
from pathlib import Path
ROOT=Path('D:/Codex用')
HERE=ROOT/'work/early-mix-experiment-20261113/review'
def read(path): return json.loads(path.read_text(encoding='utf-8'))
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
reports=[ROOT/'outputs/sle-research-review'/name for name in (
 'P027-修正教學方式與教材覆蓋-2026-11-12.md','P028-學習所需題次與提前停止-2026-11-12.md',
 'P029-論文四逐階不退回實測-2026-11-12.md','P030-純二元動態網路第一批結果-2026-11-12.md')]
reports.append(ROOT/'outputs/sle-p033/P033-覆蓋與從頭混教實測結果-2026-11-12.md')
assert 'NegEcho沒進神經訓練' in reports[2].read_text(encoding='utf-8')
p030=[]
for seed in (101,202,303):
 path=ROOT/f'work/sle-research-review/p030-binary-continual-20261112/dynamic-{seed}/2b_add_neg/summary.json'
 r=read(path)
 assert (r['L'],r['H'],r['parameters'])==(13,69,2073)
 p030.append({'seed':seed,'Echo_train':r['train_validation']['train']['by_op']['echo']['whole'],
              'Neg_train':r['train_validation']['train']['by_op']['neg']['whole'],
              'Neg_validation':r['train_validation']['validation']['by_op']['neg']['whole'],
              'Neg_test':r['final_test']['by_op']['neg']['whole'],'source_sha256':sha(path)})
assert [x['Neg_train'] for x in p030]==[6,6,6]
assert [x['Neg_validation'] for x in p030]==[1,1,0] and [x['Neg_test'] for x in p030]==[0,0,0]
timing_path=ROOT/'work/sle-p033/trial-20261112/timing/results.json'
timing=read(timing_path)
totals={}
for mode in ('T1','T0B'):
 rows=[r for r in timing if r['timing']==mode]
 assert len(rows)==6 and all(r['parameters']==2595 for r in rows)
 totals[mode]={key:sum(r['metrics'][split]['by_op'][op]['whole'] for r in rows)
               for key,split,op in (('Echo_train','train','echo'),('Neg_train','train','neg'),
                                    ('Echo_validation','val','echo'),('Neg_validation','val','neg'),
                                    ('Echo_test','test','echo'),('Neg_test','test','neg'))}
 assert totals[mode]['Echo_train']==totals[mode]['Neg_train']==36
assert sum(v for k,v in totals['T1'].items() if not k.endswith('_train'))==0
assert sum(v for k,v in totals['T0B'].items() if not k.endswith('_train'))==1
sources=[ROOT/'outputs/sle-research-review'/n for n in ('echo_teaching_comparison.py','echo_learning_time.py','echo_monotonic_curriculum.py','p030_binary_continual.py')]
sources.append(ROOT/'outputs/sle-p033/p033.py')
result={'status':'passed','scope':'Historical reports,source inspection and existing result metadata only;no old experiments rerun.',
 'small1171':{'P027_P028':'Neural Echo training succeeded in the fixed8bit192/64 domain;not Neg training;external question/answer separator present.',
             'P029':'Same1171 model,neural curriculum onlyEcho;Neg fixture is explicit host oracle,not an input to the main model.',
             'conclusion':'No1171-parameter Neg learning result in these studies;absence of that test does not establish inability or a minimum capacity.'},
 'P030_dynamic2073':p030,'P033_fixed2595':totals,
 'P033_scope':'Already matched complete initialization,total lesson multiset and per-op value streams forT0/T1/T0B. T1 unseen val+test0/24;T0B1/24.',
 'new_design_difference':'Smaller fixedL13/H69 model,C0 six-value split,2400lesson budget,matched prefix multisets by1200,and identical final1200lesson suffix;not a first-ever earlymix or matched-multiset study.',
 'new_schedule_review_notes':['Freeze the root-approved122000/123000/124000 op RNG streams,not the supersededEN/NNE illustration.',
   'At1200 each arm hasE600/N600,each(op,value)100;at2400 E1200/N1200,each(op,value)200.',
   'First300Early op counts are random rather than necessarily150/150;Late has300Echo. This is the intended timing-policy contrast.',
   'Same final suffix and matched total budgets support this policy comparison,not a unique biological/internal failure mechanism or blind heldout claim.'],
 'report_hashes':{p.name:sha(p) for p in reports},'code_hashes':{p.name:sha(p) for p in sources},
 'existing_P033_result_sha256':sha(timing_path),'new_optimizer_calls':0,'new_model_forward_calls':0,'external_model_calls':0}
with (HERE/'history-review.json').open('x',encoding='utf-8',newline='\n') as stream:
 json.dump(result,stream,ensure_ascii=False,indent=2);stream.write('\n')
print(json.dumps({'status':'passed','P030_Neg_train':[x['Neg_train'] for x in p030],
                  'P030_Neg_val':[x['Neg_validation'] for x in p030],'P030_Neg_test':[x['Neg_test'] for x in p030],
                  'P033':totals,'model_calls':0},ensure_ascii=False))
