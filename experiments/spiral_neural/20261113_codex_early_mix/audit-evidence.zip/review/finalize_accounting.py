"""Record both authorized readonly audit attempts; metadata only, no NumPy/model imports."""
from pathlib import Path
import datetime
import hashlib
import json

HERE = Path(__file__).resolve().parent
RUN = HERE.parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def write_new(path, value):
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")


def main():
    result_path = HERE / "post-run.json"
    result = read(result_path)
    failed = read(HERE / "attempt-01" / "attempt.json")
    details = read(HERE / "post-run-details.json")
    receipt = read(RUN / "execution-receipt.json")
    assert result["status"] == details["status"] == "passed"
    assert result["manifest_sha256"] == receipt["manifest_sha256"]
    assert result["formal_session"] == receipt["session_id"] == 32331
    assert receipt["status"] == "exit0" and receipt["command_invocations"] == 1
    assert result["audit_extra_forward_calls"] == failed["numeric_forward_calls"] == 3546
    assert result["audit_extra_dense_MAC"] == failed["numeric_dense_MAC"] == 7095546
    assert result["optimizer_calls"] == failed["optimizer_calls"] == 0
    assert not failed["independent_numeric_buffers_were_persisted"]
    assert sha(HERE / "audit_results.py") == failed["script_sha256"]
    assert sha(HERE / "attempt-01" / "audit_results.py") == failed["script_sha256"]
    assert sha(HERE / "attempt-01" / "original.stderr.txt") == failed["stderr_sha256"]
    log = RUN / "execution.stdout.log"
    stderr = RUN / "execution.stderr.log"
    assert log.stat().st_size == 93891 and stderr.stat().st_size == 0
    stamp = lambda text: datetime.datetime.fromisoformat(text.replace("Z", "+00:00"))
    assert stamp(receipt["PR_created_UTC"]) < stamp(receipt["execution_start_file_creation_UTC"])
    assert receipt["primary_updates"] == receipt["replay_updates"] == 72000
    assert receipt["formal_training_dense_MAC"] == 606096000
    assert receipt["offline_forward"] == result["native_offline_forward_calls"] == 3546
    assert receipt["offline_dense_MAC"] == result["native_offline_dense_MAC"] == 7095546
    archive = HERE / "attempt-02"
    archive.mkdir(exist_ok=False)
    (archive / "post-run.single-invocation.json").write_bytes(result_path.read_bytes())
    successful = {
        "status": "passed",
        "script_sha256": sha(HERE / "audit_results.py"),
        "corrected_argument": "--formal-log work/early-mix-experiment-20261113/execution.stdout.log",
        "numeric_forward_calls": 3546,
        "numeric_dense_MAC": 7095546,
        "optimizer_calls": 0,
        "new_students": 0,
        "external_model_calls": 0,
        "independent_numeric_buffers_were_persisted": True,
        "single_invocation_result_sha256": sha(archive / "post-run.single-invocation.json"),
        "durable_numeric_details_sha256": sha(HERE / "post-run-details.json"),
    }
    write_new(archive / "attempt.json", successful)
    result.update({
        "audit_attempt_count": 2,
        "audit_metadata_failure_count": 1,
        "audit_successful_pass_forward_calls": 3546,
        "audit_successful_pass_dense_MAC": 7095546,
        "audit_prior_metadata_failed_pass_forward_calls": 3546,
        "audit_prior_metadata_failed_pass_dense_MAC": 7095546,
        "audit_extra_forward_calls": 7092,
        "audit_extra_dense_MAC": 14191092,
        "audit_extra_cost_scope": "Total of two actual independent readonly passes. Attempt1 completed numerical comparisons but failed opening a misnamed formal log before writing durable numeric details. Root authorized exactly one corrected full pass; attempt2 passed and wrote the numeric details. No zero-forward reconstruction of lost numeric buffers was claimed.",
        "audit_attempts": ["review/attempt-01/attempt.json", "review/attempt-02/attempt.json"],
        "audit_successful_single_invocation_result": "review/attempt-02/post-run.single-invocation.json",
        "metadata_only_finalization": {
            "status": "passed",
            "helper": "review/finalize_accounting.py",
            "helper_sha256": sha(Path(__file__)),
            "forward_calls": 0,
            "optimizer_calls": 0,
            "execution_receipt_sha256": sha(RUN / "execution-receipt.json"),
            "formal_stdout_bytes": log.stat().st_size,
            "formal_stdout_sha256": sha(log),
            "formal_stderr_bytes": stderr.stat().st_size,
            "formal_stderr_sha256": sha(stderr),
            "prereg_PR_created_before_execution_start": True,
        },
    })
    result_path.write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps({"status": result["status"], "audit_attempts": 2, "forward_calls_total": 7092, "dense_MAC_total": 14191092, "optimizer_calls": 0, "metadata_finalization_forward_calls": 0}))


if __name__ == "__main__":
    main()
