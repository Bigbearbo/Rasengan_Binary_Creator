"""Retain the observed failed checker attempt; no inference or science writes."""
import hashlib,json
from pathlib import Path
import shutil
here=Path(__file__).resolve().parent
target=here/'attempt-01'
source=here/'audit_results.py'
shutil.copyfile(source,target/'audit_results.py')
assert 'args.formal_log.read_text' in source.read_text(encoding='utf-8').splitlines()[279]
record={'status':'metadata_failed_after_complete_numeric_comparisons','exit_code':1,
 'error':'FileNotFoundError from incorrect CLI formal-log argument formal.log; actual stream is execution.stdout.log.',
 'error_line':280,'script_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
 'stderr_sha256':hashlib.sha256((target/'original.stderr.txt').read_bytes()).hexdigest(),
 'stderr_capture_scope':'Verbatim traceback copied from the original tool output; no process rerun to generate it.',
 'observed_numeric_stage':'All six student truth/state/trace comparisons, compact equality, paired differences, costs and12 timing checks returned before the failed log open.',
 'numeric_forward_calls':3546,'numeric_dense_MAC':7095546,'optimizer_calls':0,'new_students':0,'external_model_calls':0,
 'independent_numeric_buffers_were_persisted':False,'success_details_written':False,
 'retry_authority':'Root explicitly authorized one corrected full readonly audit after this failure; all attempts must be counted.'}
with (target/'attempt.json').open('x',encoding='utf-8',newline='\n') as stream:
 json.dump(record,stream,ensure_ascii=False,indent=2);stream.write('\n')
print(json.dumps({'status':'failure_evidence_retained','script_sha256':record['script_sha256'],'forward_calls':3546}))
