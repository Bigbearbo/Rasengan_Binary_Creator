"""Bounded portable early/late preregistration gate; no optimizer or inference."""
from collections import Counter
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import shutil
import sys
import zipfile
sys.dont_write_bytecode=True
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['OMP_NUM_THREADS']='1'
import numpy as np

ROOT=Path('D:/Codex用')
WORK=ROOT/'work/early-mix-experiment-20261113'
HERE=WORK/'review'
CODE=ROOT/'outputs/early-mix-experiment'
P=WORK/'prereg'
APPROVED='c97a49f84e85ad801c9c4e93fbbd1194c217382b23bb16b9afeab0711d9080c7'
ZIP_SHA='3dd9be905ec50e2069c2fc1bd3c70616d6272218a11faa4a397e5a19400a471c'
TRAIN=(0,1,2,3,4,7)
def sha(v): return hashlib.sha256(v).hexdigest()
def canonical(v): return json.dumps(v,sort_keys=True,ensure_ascii=False,separators=(',',':'),allow_nan=False)
def read(path): return json.loads(path.read_text(encoding='utf-8'))
def state_sha(s):
    h=hashlib.sha256()
    for name,v in sorted(s.items()): h.update(canonical([name,v.dtype.str,list(v.shape)]).encode());h.update(v.tobytes(order='C'))
    return h.hexdigest()
assert sha((P/'manifest.json').read_bytes())==APPROVED
m=read(P/'manifest.json');freeze=read(P/'source-freeze.json')
assert freeze['manifest_sha256']==APPROVED and sha((P/'inputs.zip').read_bytes())==m['archive']['sha256']==ZIP_SHA
assert m['local_source_hashes']==freeze['source_hashes']
for name,pin in m['local_source_hashes'].items(): assert sha((CODE/name).read_bytes())==pin
assert m['local_source_hashes']['run_early_mix.py']=='decbb4e6b843433c446fed067f806c5d586768067e306a7341692dd08e9130be'
with zipfile.ZipFile(P/'inputs.zip') as z:
    names={'source/p030_binary_continual.py','plan.json'}|{f'initial/seed{s}.npz' for s in (101,202,303)}|{f'schedules/{arm}-seed{s}.npy' for arm in ('early','late') for s in (101,202,303)}
    assert set(z.namelist())==names and len(z.namelist())==11
    data={name:z.read(name) for name in names}
for name,raw in data.items(): assert {'sha256':sha(raw),'bytes':len(raw)}==m['files'][name]
assert data['plan.json']==(CODE/'protocol.json').read_bytes()
courses={};initials={};metadata=[]
for seed in (101,202,303):
    with np.load(io.BytesIO(data[f'initial/seed{seed}.npz']),allow_pickle=False) as a:
        s={name:a[name].copy() for name in a.files}
    assert len(s)==25 and state_sha(s)==m['initial_states'][str(seed)]['full_state_sha256']
    assert (int(s['L']),int(s['H']),int(s['meta_seed']))==(13,69,seed)
    assert int(s['t'])==int(s['meta_train_macs'])==int(s['meta_inference_calls'])==int(s['meta_inference_macs'])==0
    assert str(s['meta_events'])=='[]'
    shapes=((26,69),(69,),(69,3),(3,))
    for label in ('p','m','v','birth'):
        for i,shape in enumerate(shapes):
            v=s[f'{label}{i}'];assert v.shape==shape and v.dtype==(np.int64 if label=='birth' else np.float32)
            assert np.isfinite(v).all()
            if label!='p': assert not np.any(v)
    rng=np.random.default_rng(seed)
    assert np.array_equal(s['p0'],rng.normal(0,.2,(26,69)).astype(np.float32))
    assert np.array_equal(s['p2'],rng.normal(0,.15,(69,3)).astype(np.float32))
    assert not np.any(s['p1']) and not np.any(s['p3'])
    assert sum(s[f'{label}{i}'].nbytes for label in ('p','m','v','birth') for i in range(4))==41460
    initials[str(seed)]=s
    streams={}
    for op in (0,1):
        rng=np.random.default_rng(seed+121000+op)
        streams[op]=[int(x) for _ in range(200) for x in rng.permutation(TRAIN)]
    rng=np.random.default_rng(seed+122000)
    early=list(rng.permutation([0,1]))+list(rng.permutation([0]*599+[1]*599))
    late=[0]*300+list(np.random.default_rng(seed+123000).permutation([0]*300+[1]*600))
    tail=list(np.random.default_rng(seed+124000).permutation([0]*600+[1]*600))
    for arm,prefix in (('early',early),('late',late)):
        cursors=[0,0];expected=[]
        for op in prefix+tail:
            op=int(op);expected.append((op,streams[op][cursors[op]]));cursors[op]+=1
        course=np.load(io.BytesIO(data[f'schedules/{arm}-seed{seed}.npy']),allow_pickle=False)
        assert course.dtype.str=='<i8' and course.shape==(2400,2) and np.array_equal(course,np.array(expected))
        assert Counter(expected)==Counter({(op,v):200 for op in (0,1) for v in TRAIN})
        assert Counter(expected[:1200])==Counter({(op,v):100 for op in (0,1) for v in TRAIN})
        h=hashlib.sha256();labels=Counter()
        for op,v in expected:
            q='01'+format(op,'02b')+'0'+format(v,'03b')+'0';bits=format(v,'03b')
            a=(bits if op==0 else ''.join('1' if b=='0' else '0' for b in bits))+'0'
            for i,target in enumerate(a+'S'):
                labels[target]+=1;h.update((canonical([q+a[:i],target])+'\n').encode())
        assert dict(labels)==m['teacher_label_counts_per_student']=={'0':6000,'1':3600,'S':2400}
        assert h.hexdigest()==m['schedules'][f'{arm}-seed{seed}']['raw_teacher_target_stream_sha256']
        courses[f'{arm}-seed{seed}']=course
    assert np.array_equal(courses[f'early-seed{seed}'][1200:],courses[f'late-seed{seed}'][1200:])
    metadata.append({'seed':seed,'early_first300_op_counts':dict(Counter(map(int,courses[f'early-seed{seed}'][:300,0]))),
                     'same_prefix1200_multiset':True,'identical_final1200_stream':True})

fresh=HERE/'portable-gate';fresh.mkdir(parents=True,exist_ok=False)
for name in m['local_source_hashes']: shutil.copyfile(CODE/name,fresh/name)
for name in ('manifest.json','inputs.zip','source-freeze.json'): shutil.copyfile(P/name,fresh/name)
before={x.name:sha(x.read_bytes()) for x in fresh.iterdir()}
protected=(CODE.resolve(),P.resolve(),(ROOT/'work/sle-research-review').resolve(),(ROOT/'work/sle-ur1-20261113').resolve())
enabled=True;blocked=[];forbidden=[]
def hook(event,args):
    if enabled and event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
        path=Path(os.fsdecode(args[0])).resolve()
        if any(path.is_relative_to(root) for root in protected): blocked.append(1);raise AssertionError('Original dependency read')
sys.addaudithook(hook)
spec=importlib.util.spec_from_file_location('relocated_early_mix_gate',fresh/'run_early_mix.py')
r=importlib.util.module_from_spec(spec);sys.modules[spec.name]=r;spec.loader.exec_module(r)
native=r.source_model
def denied(*args,**kwargs): forbidden.append(1);raise AssertionError('Optimizer/inference forbidden in pre-run gate')
def guarded(content):
    cls=native(content)
    for name in ('step','lesson','loss_grad','forward','generate','grow'): setattr(cls,name,denied)
    return cls
r.source_model=guarded
r.execute=r.evaluate=r.generate=r.train_one=denied
actual,_cls,actual_initials,actual_courses=r.validate_inputs(fresh/'manifest.json',APPROVED)
assert actual==m and not blocked and not forbidden
for key in courses: assert np.array_equal(courses[key],actual_courses[key])
for seed,s in initials.items():
    assert all(np.array_equal(v,actual_initials[seed][k]) and v.dtype==actual_initials[seed][k].dtype for k,v in s.items())
enabled=False
assert before=={x.name:sha(x.read_bytes()) for x in fresh.iterdir()}
engineering=read(WORK/'engineering/checks.json')
assert engineering['status']=='PASS' and engineering['tests']==5 and engineering['formal_optimizer_updates']==engineering['formal_inference_calls']==0
assert engineering['source_hashes']==m['local_source_hashes']
for name,pin in m['local_source_hashes'].items(): assert sha((CODE/name).read_bytes())==pin
assert sha((P/'manifest.json').read_bytes())==APPROVED and sha((P/'inputs.zip').read_bytes())==ZIP_SHA
result={'status':'passed','manifest_sha256':APPROVED,'inputs_zip_sha256':ZIP_SHA,'source_hashes':m['local_source_hashes'],
        'portable_input_entries':11,'fresh_bundle_real_validator_passed_original_roots_blocked':True,
        'same_seed_full_initial_states_exact':3,'independent_schedules_verified':6,
        'exact_matching_final1200_stream_and_prefix1200_multisets':metadata,
        'each_arm_op_value_exposures':200,'each_arm_target_count':12000,'each_arm_training_dense_MAC':50508000,
        'primary_targets':72000,'replay_targets':72000,'primary_training_dense_MAC':303048000,'replay_training_dense_MAC':303048000,
        'teacher_label_counts_per_student':m['teacher_label_counts_per_student'],
        'source_review':{'original_Model_AST_unmodified':True,'only_binary_Q_plus_true_answer_prefix_to_training':True,
          'no_router_growth_or_feature_added':True,'checkpoint0_300_1200_2400_store_only_no_scores':True,
          'all6primary_and6replay_finish_before_any16Q_eval':True,
          'native_lesson_vs_independent_target_loop_fullstate_replay':True,
          'other_op_wrong_requires_full_answer_and_STOP':True,'opcode_probe_reuses_first_TF_logits_no_extra_case_or_forward':True,
          'all_seeds_and_exact_endpoints_no_extension_or_selection':True},
        'historical_scope':'P033 already tested matched multiset/per-op order earlymix. New fixed2073,C0,2400lesson/common finalstream comparison is bounded;5/6 are exposed diagnostics.',
        'engineering_native_calls_separate':{'optimizer_updates':6,'inference_calls':3},
        'material_findings_remaining':[],
        'required_root_before_formal':'Verify exact public Git preregistration and archived bytes,then one fresh formal output;no control/course rerun.',
        'reviewer_optimizer_calls':0,'reviewer_model_forward_calls':0,'reviewer_new_students':0,'external_model_calls':0}
with (HERE/'pre-run.json').open('x',encoding='utf-8',newline='\n') as stream:
    json.dump(result,stream,ensure_ascii=False,indent=2,allow_nan=False);stream.write('\n')
print(canonical({'status':'passed','manifest_sha256':APPROVED,'schedules':6,'archive_entries':11,
                 'optimizer_or_forward_calls':0,'output':str(HERE/'pre-run.json')}))
