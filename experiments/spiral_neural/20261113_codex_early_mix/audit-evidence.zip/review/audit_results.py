"""Independent early/late artifact audit: NumPy forward only, no optimizer.

Requires root's actual exit0 confirmation. Reads the frozen portable ZIP and
completed science output; never imports a learner, driver or historical main.
"""
import argparse
import ast
from collections import Counter
import gzip
import hashlib
import io
import json
import math
import os
from pathlib import Path
import platform
import re
import sys
import time
import zipfile
sys.dont_write_bytecode=True
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['OMP_NUM_THREADS']='1'
import numpy as np

APPROVED='c97a49f84e85ad801c9c4e93fbbd1194c217382b23bb16b9afeab0711d9080c7'
ZIP_SHA='3dd9be905ec50e2069c2fc1bd3c70616d6272218a11faa4a397e5a19400a471c'
COMMIT='b5cb521e0c0864bff88609370f451f4c701be7c4'
DRIVER='decbb4e6b843433c446fed067f806c5d586768067e306a7341692dd08e9130be'
TRAIN=(0,1,2,3,4,7)
POINTS=(0,300,1200,2400)
HERE=Path(__file__).resolve().parent
def need(ok,message):
    if not ok: raise AssertionError(message)
def canonical(v): return json.dumps(v,sort_keys=True,ensure_ascii=False,separators=(',',':'),allow_nan=False)
def sha_bytes(v): return hashlib.sha256(v).hexdigest()
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as s:
        for block in iter(lambda:s.read(1048576),b''): h.update(block)
    return h.hexdigest()
def parse(text):
    def pairs(items):
        out={}
        for k,v in items: need(k not in out,'duplicate JSON key');out[k]=v
        return out
    def bad(v): raise ValueError('nonfinite JSON')
    return json.loads(text,object_pairs_hook=pairs,parse_constant=bad)
def read(p): return parse(p.read_text(encoding='utf-8-sig'))
def equal(a,b,label): need(a==b,label+' differs')
def inventory(root): return {p.relative_to(root).as_posix():sha(p) for p in sorted(root.rglob('*')) if p.is_file()}
def state_sha(state):
    h=hashlib.sha256()
    for name,value in sorted(state.items()):
        h.update(canonical([name,value.dtype.str,list(value.shape)]).encode());h.update(value.tobytes(order='C'))
    return h.hexdigest()
def question(op,value): return '01'+format(op,'02b')+'0'+format(value,'03b')+'0'
def answer(op,value):
    bits=format(value,'03b')
    return (bits if op==0 else ''.join('1' if b=='0' else '0' for b in bits))+'0'
def load_state(raw,seed,lesson):
    with np.load(io.BytesIO(raw),allow_pickle=False) as archive: state={k:archive[k].copy() for k in archive.files}
    keys={f'{label}{i}' for label in ('p','m','v','birth') for i in range(4)}|{
        't','L','H','growth_rng','meta_seed','meta_events','meta_train_macs','meta_inference_macs','meta_inference_calls'}
    need(set(state)==keys,'all25 state fields')
    for label in ('p','m','v','birth'):
        for i,shape in enumerate(((26,69),(69,),(69,3),(3,))):
            v=state[f'{label}{i}'];need(v.shape==shape and v.dtype==(np.int64 if label=='birth' else np.float32),'state shape/dtype')
            need(bool(np.isfinite(v).all()),'finite state arrays')
            if label=='birth': need(not np.any(v),'unexpected parameter growth/birth')
            if label=='v': need(bool((v>=0).all()),'negative Adam second moment')
    need((int(state['L']),int(state['H']),int(state['meta_seed']))==(13,69,seed),'state identity')
    need(int(state['t'])==lesson*5 and int(state['meta_train_macs'])==lesson*5*4209,'state update/MAC count')
    need(int(state['meta_inference_calls'])==int(state['meta_inference_macs'])==0,'training pre-probe/engineering cost leaked into state')
    need(str(state['meta_events'])=='[]','unexpected model growth event')
    equal(json.loads(str(state['growth_rng'])),np.random.default_rng(seed+73000).bit_generator.state,'growth RNG unchanged')
    need(sum(state[f'{label}{i}'].nbytes for label in ('p','m','v','birth') for i in range(4))==41460,'array bytes')
    for value in state.values(): value.setflags(write=False)
    return state
def same_state(a,b,label):
    need(a.keys()==b.keys(),label+' keys')
    for k in a: need(a[k].dtype==b[k].dtype and a[k].shape==b[k].shape and np.array_equal(a[k],b[k]),label+' '+k)

def inputs(args):
    need(sha(args.manifest)==APPROVED,'approved manifest bytes')
    m=read(args.manifest);freeze=read(args.manifest.parent/'source-freeze.json')
    need(freeze['manifest_sha256']==APPROVED,'source freeze identity')
    need(m['local_source_hashes']['run_early_mix.py']==DRIVER,'frozen driver')
    for name,pin in m['local_source_hashes'].items(): need(sha(args.code_root/name)==pin,'core source '+name)
    archive=args.manifest.parent/m['archive']['file']
    need(sha(archive)==m['archive']['sha256']==ZIP_SHA,'frozen portable ZIP')
    with zipfile.ZipFile(archive) as z:
        need(len(z.namelist())==11 and set(z.namelist())==set(m['files']),'11 ZIP members')
        contents={name:z.read(name) for name in z.namelist()}
    for name,raw in contents.items(): equal({'sha256':sha_bytes(raw),'bytes':len(raw)},m['files'][name],'input '+name)
    need(sha_bytes(contents['source/p030_binary_continual.py'])==m['original_source_sha256'],'original public source')
    model=next(n for n in ast.parse(contents['source/p030_binary_continual.py'].decode()).body if isinstance(n,ast.ClassDef) and n.name=='Model')
    need(sha_bytes(ast.dump(model,include_attributes=False).encode())==m['Model_AST_sha256'],'unmodified Model AST')
    initials={};courses={}
    for seed in (101,202,303):
        s=load_state(contents[f'initial/seed{seed}.npz'],seed,0)
        need(state_sha(s)==m['initial_states'][str(seed)]['full_state_sha256'],'frozen full initial state')
        rng=np.random.default_rng(seed)
        need(np.array_equal(s['p0'],rng.normal(0,.2,(26,69)).astype(np.float32)),'initial W1 seed')
        need(np.array_equal(s['p2'],rng.normal(0,.15,(69,3)).astype(np.float32)),'initial W2 seed')
        for k in ('p1','p3',*[f'{label}{i}' for label in ('m','v','birth') for i in range(4)]): need(not np.any(s[k]),'initial zero '+k)
        initials[seed]=s
        streams={op:None for op in (0,1)}
        for op in (0,1):
            rng=np.random.default_rng(seed+121000+op)
            streams[op]=[int(v) for _ in range(200) for v in rng.permutation(TRAIN)]
        rng=np.random.default_rng(seed+122000)
        early=list(rng.permutation([0,1]))+list(rng.permutation([0]*599+[1]*599))
        late=[0]*300+list(np.random.default_rng(seed+123000).permutation([0]*300+[1]*600))
        tail=list(np.random.default_rng(seed+124000).permutation([0]*600+[1]*600))
        for arm,prefix in (('early',early),('late',late)):
            cursors=[0,0];expected=[]
            for op in prefix+tail:
                op=int(op);expected.append((op,streams[op][cursors[op]]));cursors[op]+=1
            course=np.load(io.BytesIO(contents[f'schedules/{arm}-seed{seed}.npy']),allow_pickle=False)
            need(course.shape==(2400,2) and course.dtype.str=='<i8' and np.array_equal(course,np.array(expected)),'exact RNG course')
            need(Counter(expected)==Counter({(o,v):200 for o in (0,1) for v in TRAIN}),'full course multiset')
            need(Counter(expected[:1200])==Counter({(o,v):100 for o in (0,1) for v in TRAIN}),'matched prefix multiset')
            courses[arm,seed]=course
        need(np.array_equal(courses['early',seed][1200:],courses['late',seed][1200:]),'common exact final1200stream')
    return m,initials,courses,archive

class Forward:
    def __init__(self,state): self.s=state;self.calls=0
    def __call__(self,text):
        need(0<len(text)<=13 and set(text)<=set('01'),'raw binary input')
        x=np.zeros((13,2),np.float32)
        for i,b in enumerate(text): x[i,int(b)]=1
        h=np.tanh(x.reshape(1,26)@self.s['p0']+self.s['p1']);self.calls+=1
        return (h@self.s['p2']+self.s['p3'])[0]
    def generate(self,q):
        tokens='';steps=[]
        for _ in range(8):
            prefix=q+tokens
            if len(prefix)>13: return {'tokens':tokens,'overflow':True,'cap_exhausted':False,'steps':steps}
            z=self(prefix);token='01S'[int(np.argmax(z))]
            steps.append({'prefix':prefix,'prediction':token,'logits_01S':z.tolist()});tokens+=token
            if token=='S': return {'tokens':tokens,'overflow':False,'cap_exhausted':False,'steps':steps}
        return {'tokens':tokens,'overflow':False,'cap_exhausted':True,'steps':steps}
def metric(rows):
    return {'questions':len(rows),'whole_correct':sum(r['whole_correct'] for r in rows),
            'TF_data_bits_correct':sum(t['prediction']==t['target'] for r in rows for t in r['TF'][:3]),'TF_data_bits_total':3*len(rows),
            'TF_tail0_correct':sum(r['TF'][3]['prediction']=='0' for r in rows),'TF_STOP_correct':sum(r['TF'][4]['prediction']=='S' for r in rows),
            'free_STOP_position_correct':sum(r['STOP_position_correct'] for r in rows),
            'wrong_as_other_op_full_answer':sum(r['wrong_as_other_op_full_answer'] for r in rows),
            'overflows':sum(r['generation']['overflow'] for r in rows),'cap_exhausted':sum(r['generation']['cap_exhausted'] for r in rows),
            'TF_CE_mean':sum(t['target_CE'] for r in rows for t in r['TF'])/(5*len(rows))}
def evaluate(state):
    before=state_sha(state);f=Forward(state);rows=[]
    for op in (0,1):
        for value in range(8):
            q,a=question(op,value),answer(op,value);tf=[]
            for position,label in enumerate(a+'S'):
                z=f(q+a[:position]).astype(np.float64);lp=z-np.logaddexp.reduce(z)
                tf.append({'position':position,'prefix':q+a[:position],'target':label,'prediction':'01S'[int(np.argmax(z))],
                           'logits_01S':z.tolist(),'probabilities_01S':np.exp(lp).tolist(),'target_CE':-float(lp['01S'.index(label)])})
            free=f.generate(q)
            rows.append({'op':op,'value':value,'split':'train' if value in TRAIN else 'diagnostic_heldout_exposed',
                         'Q':q,'A':a,'expected':a+'S','generation':free,'TF':tf,
                         'whole_correct':free['tokens']==a+'S' and not free['overflow'],
                         'STOP_position_correct':free['tokens'].endswith('S') and len(free['tokens'])==5,
                         'wrong_as_other_op_full_answer':free['tokens']==answer(1-op,value)+'S'})
    by={(r['op'],r['value']):r for r in rows};pairs=[]
    for value in range(8):
        a,b=by[0,value],by[1,value]
        need([i for i,(x,y) in enumerate(zip(a['Q'],b['Q'])) if x!=y]==[3],'legal opcode-only Q pair')
        first=[a['TF'][0],b['TF'][0]]
        pairs.append({'value':value,'A_prefix':'','only_changed_Q_position':3,
                      'predictions':[x['prediction'] for x in first],'targets':[x['target'] for x in first],
                      'raw_token_flip':first[0]['prediction']!=first[1]['prediction'],
                      'both_correct_and_flip':all(x['prediction']==x['target'] for x in first),
                      'TF_cache_refs':[[0,value,0],[1,value,0]]})
    scores={str(op):{'train':metric([r for r in rows if r['op']==op and r['value'] in TRAIN]),
                     'diagnostic_heldout_exposed':metric([r for r in rows if r['op']==op and r['value'] not in TRAIN])} for op in (0,1)}
    both={'train':sum(by[0,v]['whole_correct'] and by[1,v]['whole_correct'] for v in TRAIN),
          'diagnostic_heldout_exposed':sum(by[0,v]['whole_correct'] and by[1,v]['whole_correct'] for v in (5,6)),
          'train_total':6,'diagnostic_total':2}
    need(state_sha(state)==before,'checkpoint changed during independent inference')
    return {'metrics_by_op':scores,'same_payload_both_ops_correct':both,'truth':rows,
            'opcode_only_empty_A_prefix_probe':{'pairs':pairs,'total':8,'raw_token_flip':sum(r['raw_token_flip'] for r in pairs),
                                               'both_correct_and_flip':sum(r['both_correct_and_flip'] for r in pairs),'extra_forward_calls':0},
            'inference_calls':f.calls,'inference_dense_MAC':f.calls*2001,'learning_state_unchanged':True}

def trace_audit(folder,course,summary):
    h=hashlib.sha256();teacher=hashlib.sha256();anchors={};labels=Counter()
    points={n*5 for n in POINTS if n}|{n*5+1 for n in POINTS[:-1]}
    fields={'lesson','op','value','position_zero_based','prefix','target','prediction','loss','global_update','train_dense_MAC','inference_calls','inference_dense_MAC','full_state_sha256'}
    count=0
    with gzip.open(folder/'targets.jsonl.gz','rb') as stream:
        for lesson,(op,value) in enumerate(course,1):
            op,value=int(op),int(value);q,a=question(op,value),answer(op,value)
            for pos,target in enumerate(a+'S'):
                count+=1;raw=stream.readline(8193)
                need(raw and len(raw)<=8192 and raw.endswith(b'\n'),'bounded target line')
                record=parse(raw.decode());need(set(record)==fields,'trace fields')
                need(raw==(canonical(record)+'\n').encode(),'canonical target stream')
                need((record['lesson'],record['op'],record['value'],record['position_zero_based'],record['prefix'],record['target'])==
                     (lesson,op,value,pos,q+a[:pos],target),'target order/teacher-prefix/label')
                need(record['global_update']==count and record['train_dense_MAC']==count*4209,'target update/MAC')
                need(record['inference_calls']==record['inference_dense_MAC']==0,'hidden training inference charge')
                need(record['prediction'] in ('0','1','S') and isinstance(record['loss'],(float,int)) and math.isfinite(record['loss']) and record['loss']>=0,'finite prediction/loss')
                need(isinstance(record['full_state_sha256'],str) and re.fullmatch('[0-9a-f]{64}',record['full_state_sha256']),'per-target state fingerprint')
                h.update(raw);teacher.update((canonical([q+a[:pos],target])+'\n').encode());labels[target]+=1
                if count in points: anchors[count]=record
        need(not stream.read(1),'extra target records')
    need(count==12000 and labels=={'0':6000,'1':3600,'S':2400},'full target/label counts')
    equal(summary['trace'],{'targets':12000,'uncompressed_sha256':h.hexdigest()},'recorded target stream digest')
    need(summary['trace_file_sha256']==sha(folder/'targets.jsonl.gz'),'compressed trace SHA')
    return anchors,{'targets':count,'uncompressed_sha256':h.hexdigest(),'teacher_stream_sha256':teacher.hexdigest(),'gzip_sha256':sha(folder/'targets.jsonl.gz')}

def student(science,m,initial,course,arm,seed):
    folder=science/f'{arm}-seed{seed}';training=read(folder/'training-summary.json')
    need(training['targets']==12000 and training['lessons']==2400 and training['parameters']==2073,'training endpoint')
    need(training['training_dense_MAC']==50508000 and training['p_m_v_birth_array_bytes']==41460,'training cost/memory')
    need(training['training_inference_calls']==training['training_inference_MAC']==0,'training score embargo')
    anchors,trace=trace_audit(folder,course,training)
    need(trace['teacher_stream_sha256']==m['schedules'][f'{arm}-seed{seed}']['raw_teacher_target_stream_sha256'],'actual frozen teacher stream')
    curve=read(folder/'curve.json');points=[];checks=[];calls=0;last=None;final_failures=[]
    need(len(curve)==len(training['checkpoints'])==4,'fixed four checkpoints')
    for index,lesson in enumerate(POINTS):
        state=load_state((folder/f'state-{lesson:04}.npz').read_bytes(),seed,lesson)
        digest=state_sha(state)
        if lesson==0: same_state(state,initial,'complete paired initial state')
        else: need(digest==anchors[lesson*5]['full_state_sha256'],'exact saved-state target boundary anchor')
        equal(training['checkpoints'][index],{'lesson':lesson,'updates':lesson*5,'training_dense_MAC':lesson*5*4209,'full_state_sha256':digest},'checkpoint metadata')
        result=evaluate(state);calls+=result['inference_calls']
        if lesson<2400:
            nxt=anchors[lesson*5+1];row=next(r for r in result['truth'] if (r['op'],r['value'])==(nxt['op'],nxt['value']))
            need(nxt['position_zero_based']==0 and nxt['prediction']==row['TF'][0]['prediction'] and nxt['loss']==row['TF'][0]['target_CE'],'independent next-update prediction/loss anchor')
        name=f'truth-{lesson:04}.json';equal(read(folder/name),result,'all16 independent free/TF/metrics/opcode probes')
        point={'lesson':lesson,'updates':lesson*5,'training_dense_MAC':lesson*5*4209,'truth_file':name,
               **{k:v for k,v in result.items() if k!='truth'}}
        equal(curve[index],point,'complete independent curve point');points.append(point)
        checks.append({'lesson':lesson,'full_state_sha256':digest,'truth_canonical_sha256':sha_bytes(canonical(result).encode()),'inference_calls':result['inference_calls']})
        last=state;final_failures=[r for r in result['truth'] if not r['whole_correct']]
    final=load_state((folder/'final-state.npz').read_bytes(),seed,2400)
    same_state(last,final,'final archive versus2400checkpoint')
    need(training['final_full_state_sha256']==state_sha(final),'final fullstate digest')
    equal(read(folder/'final-failures.json'),final_failures,'all final failures')
    return {'arm':arm,'seed':seed,'points':points,'final':points[-1]}, {'arm':arm,'seed':seed,'trace':trace,'checkpoints':checks,
           'science_archives_loaded':5,'boundary_anchors':4,'next_prediction_loss_anchors':3,'independent_forward_calls':calls}

def run(args):
    need(args.root_confirmed_exit0,'Root confirmation required before any trained-state load')
    started=time.perf_counter();m,initials,courses,archive=inputs(args)
    compact=read(args.science/'compact.json');start=read(args.science/'execution-start.json')
    need(compact['status']=='complete' and compact['complete_primary_students']==compact['exact_replays']==6,'all6primary+6replay complete')
    need(not (args.science/'failure.json').exists(),'formal failure artifact')
    need(compact['manifest_sha256']==start['manifest_sha256']==APPROVED and compact['preregistration_commit']==start['preregistration_commit']==COMMIT,'actual preregistration identity')
    need((platform.python_version(),np.__version__)==('3.12.14','2.3.5'),'audit runtime')
    equal(read(args.science/'manifest.json'),m,'actual frozen manifest')
    before=inventory(args.science);prereg_before=inventory(args.manifest.parent)
    students=[];details=[]
    for seed in (101,202,303):
        for arm in ('early','late'):
            row,detail=student(args.science,m,initials[seed],courses[arm,seed],arm,seed)
            students.append(row);details.append(detail)
            print(canonical({'phase':'independent_readonly_audit','arm':arm,'seed':seed,'final_metrics':row['final']['metrics_by_op']}),flush=True)
    equal(compact['students'],students,'all final student/checkpoint records')
    paired=[]
    for seed in (101,202,303):
        final={r['arm']:r['final'] for r in students if r['seed']==seed}
        paired.append({'seed':seed,'difference':'early-minus-late',
                       'whole_correct_by_op_split':{str(op):{s:final['early']['metrics_by_op'][str(op)][s]['whole_correct']-final['late']['metrics_by_op'][str(op)][s]['whole_correct'] for s in ('train','diagnostic_heldout_exposed')} for op in (0,1)},
                       'same_payload_both_ops_correct':{s:final['early']['same_payload_both_ops_correct'][s]-final['late']['same_payload_both_ops_correct'][s] for s in ('train','diagnostic_heldout_exposed')}})
    equal(compact['paired_final_differences'],paired,'exact paired final arm differences')
    calls=sum(d['independent_forward_calls'] for d in details)
    for key,val in {'primary_targets':72000,'replay_targets':72000,'primary_training_dense_MAC':303048000,'replay_training_dense_MAC':303048000,
                    'training_inference_calls':0,'offline_inference_calls':calls,'offline_inference_dense_MAC':calls*2001,'array_bytes_per_student':41460,'external_model_calls':0}.items(): need(compact[key]==val,'complete cost '+key)
    timing=read(args.science/'timing.json')
    equal([(r['mode'],r['seed'],r['arm']) for r in timing['trajectories']],[(mode,s,arm) for mode in ('primary','replay') for s in (101,202,303) for arm in ('early','late')],'actual12trajectory records')
    need(all(math.isfinite(r['seconds']) and r['seconds']>0 for r in timing['trajectories']),'finite runtime')
    need(timing['total_seconds']>=sum(r['seconds'] for r in timing['trajectories']),'walltime scope')
    progress=[];final_stdout=[]
    for line in args.formal_log.read_text(encoding='utf-8-sig').splitlines():
        if line.strip().startswith('{'):
            value=parse(line)
            if value.get('mode') in ('primary','replay'): progress.append(value)
            if value.get('status')=='complete': final_stdout.append(value)
    equal(progress,[{'mode':mode,'arm':arm,'seed':s,'lesson':n} for mode in ('primary','replay') for s in (101,202,303) for arm in ('early','late') for n in POINTS[1:]],'36 actual primary/replay progress observations')
    equal(final_stdout,[compact],'completed process stdout')
    equal(before,inventory(args.science),'science unchanged during audit');equal(prereg_before,inventory(args.manifest.parent),'prereg unchanged during audit')
    for name,pin in m['local_source_hashes'].items(): need(sha(args.code_root/name)==pin,'core source unchanged after audit')
    need(sha(archive)==ZIP_SHA,'input ZIP unchanged after audit')
    totals={arm:{str(op):{s:sum(r['final']['metrics_by_op'][str(op)][s]['whole_correct'] for r in students if r['arm']==arm) for s in ('train','diagnostic_heldout_exposed')} for op in (0,1)} for arm in ('early','late')}
    result={'status':'passed','root_confirmed_formal_exit0':True,'formal_session':32331,'manifest_sha256':APPROVED,'inputs_zip_sha256':ZIP_SHA,
            'preregistration_commit':COMMIT,'source_hashes':m['local_source_hashes'],
            'primary_target_records_verified':72000,'full_checkpoints_independently_evaluated':24,'science_NPZ_archives_loaded_including6final_copies':30,
            'whole_free_generations_verified':384,'TF_logits_probabilities_CE_verified':1920,'opcode_conditional_pairs_verified':192,
            'exact_all_truth_metrics_STOP_other_op_curves_and_paired_final_differences':True,
            'state_boundary_anchors':24,'independent_next_update_prediction_loss_anchors':18,
            'same_full_initial_states_and_multisets_peroporders_common_tail_verified':True,
            'final_whole_correct_totals_by_arm_op_split':totals,'paired_final_differences':paired,
            'final_opcode_both_correct_per_student':[{'arm':r['arm'],'seed':r['seed'],'correct':r['final']['opcode_only_empty_A_prefix_probe']['both_correct_and_flip'],'total':8} for r in students],
            'native_offline_forward_calls':calls,'native_offline_dense_MAC':calls*2001,'audit_extra_forward_calls':calls,'audit_extra_dense_MAC':calls*2001,
            'primary_training_dense_MAC':303048000,'replay_training_dense_MAC':303048000,'training_inference_calls':0,'array_bytes_per_student':41460,
            'all_science_input_and_source_files_unchanged':True,'formal_wall_seconds':timing['total_seconds'],'audit_seconds':time.perf_counter()-started,
            'replay_scope':'Fixed driver completed6 independent target-loop replays,checking each prediction/loss/fullstate/counters and every saved full checkpoint/final state;12 trajectories/36 progress records and exit0 completion verified.',
            'independent_limit':'All primary trace metadata and aggregate/per-state fingerprints were checked with24 saved-state and18 numeric prediction/loss anchors. No intermediate gradient or stepwise weight recomputation was performed.',
            'interpretation_limit':'Three paired seeds in an exposed3bit domain;one diagnostic difference is not a general earlymix superiority,blind-test or internal routing claim.',
            'new_students':0,'optimizer_calls':0,'external_model_calls':0,'legacy_or_driver_modules_imported':False,'details':'review/post-run-details.json'}
    args.output_root.mkdir(parents=True,exist_ok=True)
    for path,value in ((args.output_root/'post-run-details.json',{'status':'passed','students':details,'science_inventory':before,'prereg_inventory':prereg_before}),
                       (args.output_root/'post-run.json',result)):
        with path.open('x',encoding='utf-8',newline='\n') as stream: json.dump(value,stream,ensure_ascii=False,indent=2,allow_nan=False);stream.write('\n')
    print(canonical({'status':'passed','totals':totals,'paired':paired,'audit_forward_calls':calls,'optimizer_calls':0,'output':str(args.output_root/'post-run.json')}))

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ('manifest','science','code-root','formal-log'): parser.add_argument('--'+name,type=Path,required=True)
    parser.add_argument('--output-root',type=Path,default=HERE);parser.add_argument('--root-confirmed-exit0',action='store_true')
    run(parser.parse_args())
if __name__=='__main__': main()
