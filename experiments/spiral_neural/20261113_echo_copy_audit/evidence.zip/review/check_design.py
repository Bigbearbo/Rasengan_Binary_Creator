"""Pure source/bit-geometry Echo design review. No trained array is loaded."""
import ast
import hashlib
import json
from pathlib import Path

ROOT=Path('D:/Codex用')
HERE=ROOT/'work/echo-copy-audit-20261113/review'
SOURCE=ROOT/'outputs/sle-research-review/p030_binary_continual.py'
REFERENCE=ROOT/'outputs/sle-p035/reference/p030_reference.py'
PRIOR=ROOT/'outputs/sle-p033/diagnostic.py'

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def tree(path): return ast.parse(path.read_text(encoding='utf-8'))
def node_dump(t,name):
    n=next(n for n in t.body if isinstance(n,(ast.ClassDef,ast.FunctionDef)) and n.name==name)
    return ast.dump(n,include_attributes=False)

original,reference=tree(SOURCE),tree(REFERENCE)
ast_matches={name:node_dump(original,name)==node_dump(reference,name)
             for name in ('Profile','Model','answer','encode','parse','split')}
assert all(ast_matches.values())
def q(v): return '01'+'000'+format(v,'03b')+'0'
def a(v): return format(v,'03b')+'0'
assert all(len(q(v))==9 and len(a(v))==4 for v in range(8))
own=[]
off=[]
for j in range(3):
    for x in range(8):
        if format(x,'03b')[j]!='0': continue
        y=x^(1<<(2-j))
        assert [i for i,(l,r) in enumerate(zip(q(x),q(y))) if l!=r]==[5+j]
        assert a(x)[:j]==a(y)[:j] and a(x)[j]!=a(y)[j]
        own.append({'target_bit':j,'flipped_Q_bit':j,'left':x,'right':y,
                    'left_prefix':q(x)+a(x)[:j],'right_prefix':q(y)+a(y)[:j]})
    for k in range(j+1,3):
        for x in range(8):
            if format(x,'03b')[k]!='0': continue
            y=x^(1<<(2-k))
            assert [i for i,(l,r) in enumerate(zip(q(x),q(y))) if l!=r]==[5+k]
            assert a(x)[:j]==a(y)[:j] and a(x)[j]==a(y)[j]
            off.append({'target_bit':j,'flipped_Q_bit':k,'left':x,'right':y,
                        'left_prefix':q(x)+a(x)[:j],'right_prefix':q(y)+a(y)[:j]})
assert len(own)==len(off)==12
assert len({(r['left'],r['right']) for r in own})==12
assert len({(r['left'],r['right']) for r in off})==8
assert len({(r['target_bit'],r['flipped_Q_bit'],r['left'],r['right']) for r in off})==12
tf={(v,j):q(v)+a(v)[:j] for v in range(8) for j in range(5)}
data_queries={tf[v,j] for v in range(8) for j in range(3)}
assert len(tf)==40 and len(set(tf.values()))==40 and len(data_queries)==24
assert {r[side] for r in own+off for side in ('left_prefix','right_prefix')}==data_queries
lookup={v:format(v,'03b')+'0S' for v in range(8)}
assert all(lookup[v]==format(v,'03b')+'0S' for v in range(8))
snapshots=[ROOT/f'work/sle-research-review/p030-binary-continual-20261112/dynamic-{seed}/{phase}/state.npz'
           for seed in (101,202,303) for phase in ('2a_echo_op2','2b_add_neg')]
assert len(snapshots)==6 and all(path.is_file() for path in snapshots)

checks={'status':'passed','source_hashes':{'P030_original':sha(SOURCE),'public_reference':sha(REFERENCE),'prior_P033_diagnostic':sha(PRIOR)},
        'AST_matches':ast_matches,'own_bit_pairs_per_snapshot':12,'off_target_conditional_pairs_per_snapshot':12,
        'distinct_off_target_whole_Q_pairs_per_snapshot':8,'unique_TF_data_queries_per_snapshot':24,
        'all_TF_queries_including_syntax_and_STOP_per_snapshot':40,
        'own_pairs':own,'off_target_pairs':off,'every_fixed_prefix_legal_for_both_members':True,
        'all_pair_queries_reusable_from_existing_8case_TF_table':True,
        'finite8entry_lookup_and_copy_observationally_equivalent_on_closed_domain':True,
        'trained_checkpoint_arrays_loaded':0,'model_inference_or_optimizer_calls':0,'external_model_calls':0}
review={'status':'design_review_passed','stage':'Design/source/bit-geometry review only; no trained model scores or checkpoint arrays read.',
        'candidate_snapshots':6,'candidate_data':'P030 dynamic101/202/303;end2a_echo_op2 andend2b_add_neg;not a new training run.',
        'source_hashes':checks['source_hashes'],'Model_and_codec_AST_equal_public_reference':True,
        'primary_readouts':['Autonomous full8 legal Echo answers including syntax0 and STOP, plus full TF/logits.',
                           'Own-bit pairs: both predictions correct and following the flipped true bit;12 unordered cube edges per snapshot.',
                           'Future-bit controls: both predictions correct and invariant;also report raw invariance/change separately.'],
        'counts':{'snapshots':6,'Echo_cases':48,'TF_queries_including_syntax_STOP':240,
                  'own_bit_pairs':72,'off_target_conditional_pairs':72,
                  'off_target_distinct_whole_Q_pairs_per_snapshot':8,
                  'unique_TF_data_queries_per_snapshot':24,'additional_pair_forward_calls_if_TF_reused':0},
        'required_before_trained_inference':[
          'Freeze off-target both-correct-and-invariant as correctness-conditioned evidence;constant wrong invariance is insufficient.',
          'Name the off-target unit(target_j,flipped_k,unordered_value_pair):12 conditions but8 distinct whole-Q pairs;do not treat conditions/seeds as independent large samples.',
          'Reconstruct historical optimizer occurrences through each snapshot from all actual prior phase traces, stopping at that snapshot;verify total targets against savedt.',
          'For every queried raw prefix record label counts for0/1/S,matching/conflicting counts,last optimized label,and phase/shape provenance;separate whole-Q-as-question exposure from exact optimizer-prefix exposure.',
          'Exclude validation/test/diagnostic forwards and historical replay from primary optimizer exposure;they are not extra teaching of the saved primary state.',
          'Pin six source snapshots and verify same Echo raw grammar and shape for the paired phases before inference;do not modify saved arrays or load optimizer code for execution.'],
        'interpretation':{
          'supported':'Finite conditional copy-consistent behavior and exact exposure-aware failures/successes;compare same raw inputs before/after mixed training descriptively.',
          'not_identifiable':'An arbitrary8-value table and a copy algorithm can agree everywhere on this finite domain;even complete success does not identify an internal algorithm.',
          'literal_cache_limit':'Correctness outside historical exact-prefix-label coverage shows that literal repetition of those optimized entries alone is incomplete;it does not exclude arbitrary lookup tables,defaults or interpolation.',
          'prefix_scope':'These are teacher-prefix conditional interventions;free generation and error propagation are separate readouts.',
          'before_after_limit':'Same raw/shape does not equal matched optimizer age or Echo exposure;do not isolate Neg semantics as the unique cause.',
          'split_scope':'train0,1,2,3,4,7;val5 influenced earlier stopping/growth;test6 is previously examined. No new blind-test claim.',
          'prior_work':'P033 diagnostic.py already has conditional bit-probability probes on36 frozen P032 states/4320 directed rows. This adds different P030 snapshots,undirected paired-correct metrics and actual optimizer exposure accounting.'},
        'formal_inference_release':'Wait for root to approve a frozen diagnostic implementation/source/input hash gate;this document is not a model-performance PASS.',
        'material_design_blocker':None,'trained_checkpoint_arrays_loaded':0,'trained_model_inference_calls':0,
        'optimizer_calls':0,'external_model_calls':0,'original_source_or_checkpoint_or_registry_or_Git_modified':False,
        'evidence':'review/design-checks.json'}
for name,value in (('design-checks.json',checks),('pre-run.json',review)):
    with (HERE/name).open('x',encoding='utf-8',newline='\n') as stream:
        json.dump(value,stream,ensure_ascii=False,indent=2,allow_nan=False);stream.write('\n')
print(json.dumps({'status':review['status'],'own_pairs_per_snapshot':12,'off_conditional_pairs_per_snapshot':12,
                  'off_distinct_Q_pairs_per_snapshot':8,'AST_all_equal':True,'trained_inference_calls':0,
                  'output':str(HERE/'pre-run.json')},ensure_ascii=False))
