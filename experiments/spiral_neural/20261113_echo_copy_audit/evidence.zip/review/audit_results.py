"""Independent NumPy Echo audit: no legacy imports, optimizer or new training."""
import argparse
import ast
from collections import Counter
import copy
import hashlib
import io
import json
import os
from pathlib import Path
import platform
import sys
import time
import zipfile
sys.dont_write_bytecode=True
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['OMP_NUM_THREADS']='1'
import numpy as np

MANIFEST_SHA='7a691fcf1b55e49cb01bef5c4f6debb3b72cbed0ca39733eb8588170b639f54d'
ZIP_SHA='7cd7b4d312ff944fe8c034db547b08698700002232b6ebee0bc3cddfc216324d'
HERE=Path(__file__).resolve().parent
def need(ok,message):
    if not ok: raise AssertionError(message)
def canonical(v): return json.dumps(v,sort_keys=True,ensure_ascii=False,separators=(',',':'),allow_nan=False)
def sha_bytes(v): return hashlib.sha256(v).hexdigest()
def sha(p): return sha_bytes(p.read_bytes())
def read(p):
    def pairs(items):
        out={}
        for k,v in items:
            need(k not in out,'duplicate JSON key');out[k]=v
        return out
    def bad(v): raise ValueError('Nonfinite JSON')
    return json.loads(p.read_text(encoding='utf-8'),object_pairs_hook=pairs,parse_constant=bad)
def state_sha(saved):
    h=hashlib.sha256()
    for key,value in sorted(saved.items()):
        h.update(canonical([key,value.dtype.str,list(value.shape)]).encode());h.update(value.tobytes(order='C'))
    return h.hexdigest()
def inventory(folder): return {p.relative_to(folder).as_posix():sha(p) for p in sorted(folder.rglob('*')) if p.is_file()}
def equal(actual,expected,label):
    need(actual==expected,label+' differs')
def q(value): return '01000'+format(value,'03b')+'0'
def a(value): return format(value,'03b')+'0'

def add(table,key,label,location):
    if key not in table: table[key]={'count':0,'labels':{},'first':location,'last':location,'last_label':label}
    entry=table[key];entry['count']+=1;entry['labels'][label]=entry['labels'].get(label,0)+1
    entry['last']=location;entry['last_label']=label

def histories(contents,p):
    output={};trace_rows=0
    for seed in p['seeds']:
        ledger={'raw_prefixes':{},'whole_questions':{},'teacher_answers_with_STOP':{},'targets':0,'phases':[]}
        for phase_index,phase in enumerate(p['history_phases']):
            trace=json.loads(contents[f'traces/dynamic-{seed}/{phase["name"]}/trace.json'])
            start=ledger['targets'];operations=Counter()
            schedule_seed=seed+100*phase_index
            op_rng=np.random.default_rng(schedule_seed+51000)
            value_rng={op:np.random.default_rng(schedule_seed+52000+op) for op in phase['ops']}
            queues={op:[] for op in phase['ops']};op_queue=[]
            for lesson,(op,value,_observed_predictions) in enumerate(trace,1):
                if not op_queue:
                    sequence=[1]*7+[0]*3 if phase['name']=='2b_add_neg' else phase['ops']
                    op_queue=op_rng.permutation(sequence).tolist()
                expected_op=int(op_queue.pop(0))
                if not queues[expected_op]: queues[expected_op]=value_rng[expected_op].permutation(phase['train']).tolist()
                expected_value=int(queues[expected_op].pop(0))
                need((op,value)==(expected_op,expected_value),'independent historical schedule')
                question='01'+format(op,f'0{phase["nop"]}b')+'0'+format(value,f'0{phase["nd"]}b')+'0'
                bits=format(value,f'0{phase["nd"]}b')
                answer=(bits if op==0 else ''.join('1' if b=='0' else '0' for b in bits))+'0'
                location={'phase':phase['name'],'lesson_index_1based':lesson,'op':op,'value':value,
                          'global_target_index_1based':ledger['targets']+1,'position_zero_based':0}
                add(ledger['whole_questions'],question,answer+'S',location)
                add(ledger['teacher_answers_with_STOP'],answer+'S',answer,location)
                for position,label in enumerate(answer+'S'):
                    ledger['targets']+=1
                    location={'phase':phase['name'],'lesson_index_1based':lesson,'op':op,'value':value,
                              'global_target_index_1based':ledger['targets'],'position_zero_based':position}
                    add(ledger['raw_prefixes'],question+answer[:position],label,location)
                operations[f'{op},{value}']+=1;trace_rows+=1
            ledger['phases'].append({'phase':phase['name'],'lessons':len(trace),'targets':ledger['targets']-start,
                                    'first_global_target_index_1based':start+1,'last_global_target_index_1based':ledger['targets'],
                                    'op_value_lesson_counts':dict(sorted(operations.items())),
                                    'schedule_seed':schedule_seed,'symbolic_original_schedule_exact':True})
            if phase['name'] in p['snapshots']: output[f'dynamic-{seed}/{phase["name"]}']=copy.deepcopy(ledger)
    return output,trace_rows

def exposure(ledger,prefix,target):
    entry=ledger['raw_prefixes'].get(prefix)
    if entry is None:
        return {'raw_prefix_seen':False,'classification':'unseen','optimizer_exposures':0,'label_counts':{},
                'same_label_exposures':0,'conflicting_label_exposures':0,'last_label':None,
                'last_label_matches_target':None,'first':None,'last':None}
    same=entry['labels'].get(target,0);conflict=entry['count']-same
    return {'raw_prefix_seen':True,'classification':'mixed' if same and conflict else 'same_only' if same else 'conflict_only',
            'optimizer_exposures':entry['count'],'label_counts':dict(sorted(entry['labels'].items())),
            'same_label_exposures':same,'conflicting_label_exposures':conflict,
            'last_label':entry['last_label'],'last_label_matches_target':entry['last_label']==target,
            'first':entry['first'],'last':entry['last']}

class MatrixForward:
    def __init__(self,state):
        self.state=state;self.calls=0
    def __call__(self,prefix):
        need(0<len(prefix)<=13 and set(prefix)<=set('01'),'binary prefix within frozen context')
        slots=np.zeros((13,2),np.float32)
        for i,bit in enumerate(prefix): slots[i,int(bit)]=1
        hidden=np.tanh(slots.reshape(1,26)@self.state['p0']+self.state['p1'])
        self.calls+=1
        return (hidden@self.state['p2']+self.state['p3'])[0]
    def generate(self,question):
        tokens='';steps=[]
        for _ in range(8):
            prefix=question+tokens
            if len(prefix)>13: return {'tokens':tokens,'overflow':True,'cap_exhausted':False,'steps':steps}
            logits=self(prefix)
            prediction='01S'[int(np.argmax(logits))]
            steps.append({'prefix':prefix,'prediction':prediction,'logits_01S':logits.tolist()})
            tokens+=prediction
            if prediction=='S': return {'tokens':tokens,'overflow':False,'cap_exhausted':False,'steps':steps}
        return {'tokens':tokens,'overflow':False,'cap_exhausted':True,'steps':steps}

def pairs(cache):
    current=[];future=[]
    for j in range(3):
        for k in range(j,3):
            for left in range(8):
                if format(left,'03b')[k]=='1': continue
                right=left+(1<<(2-k))
                x,y=cache[left][j],cache[right][j]
                need(x['correct_earlier_A_prefix']==y['correct_earlier_A_prefix'],'legal common teacher prefix')
                both=x['prediction']==x['target'] and y['prediction']==y['target']
                row={'output_data_position_j':j,'flipped_Q_data_position_k':k,'values':[left,right],
                     'same_correct_earlier_A_prefix':x['correct_earlier_A_prefix'],'TF_cache_refs':[[left,j],[right,j]],
                     'targets':[x['target'],y['target']],'predictions':[x['prediction'],y['prediction']],
                     'both_correct':both,'logit_delta_linf':float(np.max(np.abs(np.array(x['logits_01S'])-np.array(y['logits_01S']))))}
                if j==k:
                    row.update(raw_predicted_token_flip=x['prediction']!=y['prediction'],both_correct_and_follow=both);current.append(row)
                else:
                    row.update(raw_predicted_token_invariant=x['prediction']==y['prediction'],both_correct_and_invariant=both);future.append(row)
    need(len(current)==len(future)==12,'fixed pair counts')
    need(len({tuple(r['values']) for r in future})==8,'conditional versus whole-question pair count')
    return {'current_bit':{'conditional_pairs':12,'distinct_whole_Q_pairs':12,
                          'both_correct_and_follow':sum(r['both_correct_and_follow'] for r in current),
                          'raw_predicted_token_flip':sum(r['raw_predicted_token_flip'] for r in current),'rows':current},
            'future_bit':{'conditional_pairs':12,'distinct_whole_Q_pairs':8,
                         'both_correct_and_invariant':sum(r['both_correct_and_invariant'] for r in future),
                         'raw_predicted_token_invariant':sum(r['raw_predicted_token_invariant'] for r in future),'rows':future},
            'additional_forward_calls':0,'cached_data_logits':24,
            'sampling_limit':'Overlapping deterministic conditions over8 inputs; not independent statistical samples'}

def evaluate(saved,ledger):
    state_before=state_sha(saved);forward=MatrixForward(saved);rows=[];cache={}
    for value in range(8):
        question,answer=q(value),a(value);free=forward.generate(question);tf=[]
        for position,target in enumerate(answer+'S'):
            prefix=question+answer[:position]
            logits=forward(prefix).astype(np.float64);lp=logits-np.logaddexp.reduce(logits)
            tf.append({'position_zero_based':position,'role':'data' if position<3 else 'tail0' if position==3 else 'STOP',
                       'prefix':prefix,'target':target,'correct_earlier_A_prefix':answer[:position],
                       'prediction':'01S'[int(np.argmax(logits))],'logits_01S':logits.tolist(),
                       'probabilities_01S':np.exp(lp).tolist(),'target_CE':-float(lp['01S'.index(target)]),
                       'history_exposure':exposure(ledger,prefix,target)})
        cache[value]=tf[:3]
        whole=ledger['whole_questions'].get(question);teacher_answer=ledger['teacher_answers_with_STOP'].get(answer+'S')
        rows.append({'value':value,'historical_role':'optimizer_train' if value in (0,1,2,3,4,7) else 'validation_used_in_stage_gate' if value==5 else 'test_already_viewed',
                     'Q':question,'A':answer,'expected':answer+'S','generation':free,
                     'whole_correct':free['tokens']==answer+'S' and not free['overflow'],
                     'STOP_position_correct':free['tokens'].endswith('S') and len(free['tokens'])==len(answer)+1,
                     'whole_Q_optimizer_seen':whole is not None,'whole_Q_exposure':whole,
                     'whole_answer_bits_ever_teacher_answer':teacher_answer is not None,
                     'whole_answer_with_STOP_ever_teacher_answer':teacher_answer is not None,
                     'whole_answer_teacher_exposure':teacher_answer,'teacher_forcing':tf})
    paired=pairs(cache)
    need(state_sha(saved)==state_before,'read-only checkpoint arrays')
    categories=Counter(t['history_exposure']['classification'] for r in rows for t in r['teacher_forcing'])
    summary={'whole_correct':sum(r['whole_correct'] for r in rows),'whole_total':8,
             'optimizer_train_whole_correct':sum(r['whole_correct'] for r in rows if r['value'] in (0,1,2,3,4,7)),
             'validation5_whole_correct':rows[5]['whole_correct'],'test6_whole_correct':rows[6]['whole_correct'],
             'TF_data_correct':sum(t['prediction']==t['target'] for r in rows for t in r['teacher_forcing'][:3]),
             'TF_data_targets':24,'TF_all_correct':sum(t['prediction']==t['target'] for r in rows for t in r['teacher_forcing']),
             'TF_all_targets':40,'TF_prefix_exposure_categories':dict(sorted(categories.items())),
             'current_both_correct_and_follow':paired['current_bit']['both_correct_and_follow'],
             'current_raw_flip':paired['current_bit']['raw_predicted_token_flip'],
             'future_both_correct_and_invariant':paired['future_bit']['both_correct_and_invariant'],
             'future_raw_invariant':paired['future_bit']['raw_predicted_token_invariant'],
             'inference_calls':forward.calls,'inference_dense_MAC':forward.calls*2001,
             'learning_state_before_sha256':state_before,'learning_state_after_sha256':state_sha(saved),
             'history_optimizer_targets':ledger['targets'],'optimizer_calls':0}
    return {'summary':summary,'truth':rows,'pair_diagnostics':paired,'history_ledger':ledger},forward.calls

def run(args):
    need(args.root_confirmed_exit0,'Root confirmation required before trained inference')
    need(sha(args.manifest)==MANIFEST_SHA,'approved input manifest')
    manifest=read(args.manifest);archive_path=args.manifest.parent/manifest['archive']['file']
    need(sha(archive_path)==manifest['archive']['sha256']==ZIP_SHA,'frozen ZIP')
    for name,pin in manifest['source_hashes'].items(): need(sha(args.code_root/name)==pin,'frozen diagnostic source')
    with zipfile.ZipFile(archive_path) as archive:
        need(len(archive.namelist())==25 and set(archive.namelist())==set(manifest['files']),'25 archive inputs')
        contents={name:archive.read(name) for name in archive.namelist()}
    for name,data in contents.items(): equal({'sha256':sha_bytes(data),'bytes':len(data)},manifest['files'][name],'raw input '+name)
    need((platform.python_version(),np.__version__)==('3.12.14','2.3.5'),'audit runtime')
    before=inventory(args.results)
    compact=read(args.results/'compact.json')
    need(compact['status']=='complete' and compact['input_manifest_sha256']==MANIFEST_SHA,'completed readonly execution')
    old_histories,trace_rows=histories(contents,manifest['protocol'])
    rebuilt=[];details=[];total_calls=0;examples=[]
    for name,ledger in old_histories.items():
        with np.load(io.BytesIO(contents[f'checkpoints/{name}/state.npz']),allow_pickle=False) as archive:
            saved={key:archive[key].copy() for key in archive.files}
        need((int(saved['L']),int(saved['H']))==(13,69),'frozen model shape')
        need(int(saved['t'])==ledger['targets'],'historical target-count anchor')
        need(state_sha(saved)==manifest['snapshots'][name]['learning_state_sha256'],'full learning state hash')
        for value in saved.values(): value.setflags(write=False)
        result,calls=evaluate(saved,ledger);total_calls+=calls
        seed=int(name.split('/')[0].split('-')[1]);result['snapshot']=name;result['seed']=seed
        equal(read(args.results/(name.replace('/','--')+'.json')),result,'full independent snapshot free/TF/pairs/exposure '+name)
        rebuilt.append({'snapshot':name,'seed':seed,**result['summary']})
        details.append({'snapshot':name,'result_canonical_sha256':sha_bytes(canonical(result).encode()),'summary':result['summary']})
        for value in (5,6):
            row=result['truth'][value]
            examples.append({'snapshot':name,'value':value,'expected':row['expected'],'generated':row['generation']['tokens'],
                             'TF_predictions':''.join(t['prediction'] for t in row['teacher_forcing']),
                             'whole_Q_optimizer_seen':row['whole_Q_optimizer_seen'],
                             'whole_answer_teacher_exposures':(row['whole_answer_teacher_exposure'] or {}).get('count',0),
                             'prefix_exposure_classes':[t['history_exposure']['classification'] for t in row['teacher_forcing']]})
    equal(compact['snapshots'],rebuilt,'full snapshot summary')
    need(compact['inference_calls']==total_calls and compact['inference_dense_MAC']==total_calls*2001,'new inference cost')
    need(compact['pair_extra_forward_calls']==0 and not any(compact['optimizer_call_guards'].values()),'no learning or extra pair inference')
    need(compact['learning_state_all_exact_unchanged'] and compact['source_checkpoint_trace_hashes_unchanged'],'native state guard reports')
    before_originals=read(args.originals_before);after_originals=read(args.originals_after)
    need(before_originals['status']==after_originals['status']=='PASS','root original-file checks')
    equal(before_originals['files'],manifest['files'],'original25 before')
    equal(after_originals['files'],manifest['files'],'original25 after')
    equal(before,inventory(args.results),'result bytes unchanged by independent audit')
    need(sha(args.manifest)==MANIFEST_SHA and sha(archive_path)==ZIP_SHA,'archive unchanged after inference')
    for name,pin in manifest['source_hashes'].items(): need(sha(args.code_root/name)==pin,'core source unchanged after inference')
    groups={}
    for phase in manifest['protocol']['snapshots']:
        rows=[r for r in rebuilt if r['snapshot'].endswith('/'+phase)]
        groups[phase]={'whole_correct':sum(r['whole_correct'] for r in rows),'whole_total':24,
                       'current_both_correct_and_follow':sum(r['current_both_correct_and_follow'] for r in rows),'current_pairs':36,
                       'future_both_correct_and_invariant':sum(r['future_both_correct_and_invariant'] for r in rows),'future_conditional_pairs':36}
    result={'status':'passed','root_confirmed_readonly_exit0':True,'input_manifest_sha256':MANIFEST_SHA,'inputs_zip_sha256':ZIP_SHA,
            'source_hashes':manifest['source_hashes'],'snapshots_verified':6,'whole_free_generations_verified':48,
            'TF_predictions_logits_probabilities_CE_and_exposure_verified':240,'own_pairs_verified':72,'future_conditional_pairs_verified':72,
            'independently_rebuilt_history_ledgers':6,'primary_history_traces_verified':15,'historical_lesson_rows_verified':trace_rows,
            'exact_full_result_and_summary_match':True,'phase_totals':groups,'snapshot_summaries':rebuilt,'values5and6_examples':examples,
            'native_new_forward_calls':total_calls,'native_new_forward_dense_MAC':total_calls*2001,
            'audit_extra_forward_calls':total_calls,'audit_extra_forward_dense_MAC':total_calls*2001,
            'pair_extra_forward_calls':0,'all6learning_states_exact_unchanged':True,'root_original25_before_after_matches_verified':True,
            'source_inputs_and_result_files_unchanged':True,'new_students':0,'optimizer_calls':0,'external_model_calls':0,
            'legacy_Model_or_diagnostic_modules_imported':False,
            'scope_limit':'Closed exposed3bit behavior cannot identify copy algorithm versus arbitrary finite table;teacher-prefix conditional evidence and before/after changes do not isolate a unique internal mechanism or Neg causality.'}
    args.output_root.mkdir(parents=True,exist_ok=True)
    for path,value in ((args.output_root/'post-run-details.json',{'status':'passed','snapshots':details,'results_inventory':before}),
                       (args.output_root/'post-run.json',result)):
        with path.open('x',encoding='utf-8',newline='\n') as stream:
            json.dump(value,stream,ensure_ascii=False,indent=2,allow_nan=False);stream.write('\n')
    print(canonical({'status':'passed','phase_totals':groups,'forward_calls':total_calls,'optimizer_calls':0,'output':str(args.output_root/'post-run.json')}))

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ('manifest','results','code-root','originals-before','originals-after'): parser.add_argument('--'+name,type=Path,required=True)
    parser.add_argument('--output-root',type=Path,default=HERE);parser.add_argument('--root-confirmed-exit0',action='store_true')
    run(parser.parse_args())
if __name__=='__main__': main()
