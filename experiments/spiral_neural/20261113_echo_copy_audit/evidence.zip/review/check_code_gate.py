"""Echo code/input gate only: zero trained forward or optimizer calls."""
from collections import Counter
import copy
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import shutil
import sys
import zipfile
sys.dont_write_bytecode=True
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['OMP_NUM_THREADS']='1'
import numpy as np

ROOT=Path('D:/Codex用')
WORK=ROOT/'work/echo-copy-audit-20261113'
HERE=WORK/'review'
CODE=ROOT/'outputs/echo-copy-audit'
PREREG=WORK/'prereg'
MANIFEST_SHA='7a691fcf1b55e49cb01bef5c4f6debb3b72cbed0ca39733eb8588170b639f54d'
ZIP_SHA='7cd7b4d312ff944fe8c034db547b08698700002232b6ebee0bc3cddfc216324d'
def sha(data): return hashlib.sha256(data).hexdigest()
def canonical(value): return json.dumps(value,sort_keys=True,ensure_ascii=False,separators=(',',':'),allow_nan=False)
def read(path): return json.loads(path.read_text(encoding='utf-8'))
def state_sha(saved):
    h=hashlib.sha256()
    for name,value in sorted(saved.items()):
        h.update(canonical([name,value.dtype.str,list(value.shape)]).encode());h.update(value.tobytes(order='C'))
    return h.hexdigest()

assert sha((PREREG/'input-manifest.json').read_bytes())==MANIFEST_SHA
manifest=read(PREREG/'input-manifest.json')
freeze=read(PREREG/'source-freeze.json')
assert freeze['input_manifest_sha256']==MANIFEST_SHA
assert manifest['archive']['sha256']==ZIP_SHA==sha((PREREG/'inputs.zip').read_bytes())
assert manifest['source_hashes']==freeze['source_hashes']
for name,pin in manifest['source_hashes'].items(): assert sha((CODE/name).read_bytes())==pin
assert manifest['source_hashes']['diagnose.py']=='74a3c3a38ea3deccf7f9844cd4943f566da4dd4cf78d6765cb22081b8d82ca42'
expected={'reference/p030_reference.py','reference/p030_binary_continual.py',
          'provenance/public-checkpoint-pins.json','provenance/published-checkpoints-verified.json'}
p=manifest['protocol']
expected|={f'traces/dynamic-{seed}/{phase["name"]}/trace.json' for seed in p['seeds'] for phase in p['history_phases']}
expected|={f'checkpoints/dynamic-{seed}/{phase}/state.npz' for seed in p['seeds'] for phase in p['snapshots']}
with zipfile.ZipFile(PREREG/'inputs.zip') as archive:
    assert len(archive.namelist())==len(set(archive.namelist()))==25 and set(archive.namelist())==expected
    contents={name:archive.read(name) for name in archive.namelist()}
for name,data in contents.items(): assert {'sha256':sha(data),'bytes':len(data)}==manifest['files'][name]

def add(table,key,label,location):
    if key not in table: table[key]={'count':0,'labels':{},'first':location,'last':location,'last_label':label}
    item=table[key];item['count']+=1;item['labels'][label]=item['labels'].get(label,0)+1
    item['last']=location;item['last_label']=label

independent={}
for seed in p['seeds']:
    prefixes={};questions={};answers={};phases=[];targets=0
    for phase_index,phase in enumerate(p['history_phases']):
        trace=json.loads(contents[f'traces/dynamic-{seed}/{phase["name"]}/trace.json'])
        start=targets;operations=Counter()
        for lesson,item in enumerate(trace,1):
            op,value,_predictions=item
            assert op in phase['ops'] and value in phase['train']
            q='01'+format(op,f'0{phase["nop"]}b')+'0'+format(value,f'0{phase["nd"]}b')+'0'
            bits=format(value,f'0{phase["nd"]}b')
            a=(bits if op==0 else ''.join('1' if b=='0' else '0' for b in bits))+'0'
            location={'phase':phase['name'],'lesson_index_1based':lesson,'op':op,'value':value,
                      'global_target_index_1based':targets+1,'position_zero_based':0}
            add(questions,q,a+'S',location);add(answers,a+'S',a,location)
            for position,label in enumerate(a+'S'):
                targets+=1
                location={'phase':phase['name'],'lesson_index_1based':lesson,'op':op,'value':value,
                          'global_target_index_1based':targets,'position_zero_based':position}
                add(prefixes,q+a[:position],label,location)
            operations[f'{op},{value}']+=1
        phases.append({'phase':phase['name'],'lessons':len(trace),'targets':targets-start,
                       'first_global_target_index_1based':start+1,'last_global_target_index_1based':targets,
                       'op_value_lesson_counts':dict(sorted(operations.items())),
                       'schedule_seed':seed+100*phase_index,'symbolic_original_schedule_exact':True})
        if phase['name'] in p['snapshots']:
            name=f'dynamic-{seed}/{phase["name"]}'
            with np.load(io.BytesIO(contents[f'checkpoints/{name}/state.npz']),allow_pickle=False) as archive:
                saved={key:archive[key].copy() for key in archive.files}
            assert targets==int(saved['t'])==manifest['snapshots'][name]['optimizer_targets_reconstructed']
            assert state_sha(saved)==manifest['snapshots'][name]['learning_state_sha256']==freeze['snapshots'][name]
            assert (int(saved['L']),int(saved['H']))==(13,69)
            independent[name]=copy.deepcopy({'prefixes':prefixes,'questions':questions,'answers':answers,'phases':phases,'targets':targets})

fresh=HERE/'code-gate-portable'
fresh.mkdir(parents=True,exist_ok=False)
for name in manifest['source_hashes']: shutil.copyfile(CODE/name,fresh/name)
for name in ('input-manifest.json','inputs.zip','source-freeze.json'): shutil.copyfile(PREREG/name,fresh/name)
before={path.name:sha(path.read_bytes()) for path in fresh.iterdir()}
blocked=[]
enabled=True
protected=(CODE.resolve(),PREREG.resolve(),(ROOT/'work/sle-research-review').resolve(),(ROOT/'work/sle-ur1-20261113').resolve())
def guard(event,args):
    if enabled and event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
        path=Path(os.fsdecode(args[0])).resolve()
        if any(path.is_relative_to(root) for root in protected):
            blocked.append(str(path));raise AssertionError('Hidden original source/checkpoint access')
sys.addaudithook(guard)
spec=importlib.util.spec_from_file_location('echo_fresh_code_gate',fresh/'diagnose.py')
d=importlib.util.module_from_spec(spec);sys.modules[spec.name]=d;spec.loader.exec_module(d)
forbidden=[]
def deny(*args,**kwargs):
    forbidden.append(1);raise AssertionError('Trained model evaluation forbidden before root method gate')
for name in ('model_class','restore','generation','evaluate_snapshot','execute'): setattr(d,name,deny)
actual,restored,_=d.validated_inputs(fresh/'input-manifest.json',MANIFEST_SHA)
assert actual==manifest and restored==contents
histories=d.histories_from_inputs(restored,p)
for name,history in histories.items():
    ours=independent[name]
    assert history.targets==ours['targets'] and history.phases==ours['phases']
    assert history.prefixes==ours['prefixes'] and history.questions==ours['questions'] and history.answers==ours['answers']
    for value in range(8):
        q='01000'+format(value,'03b')+'0';a=format(value,'03b')+'0'
        for i,label in enumerate(a+'S'):
            entry=ours['prefixes'].get(q+a[:i]);actual=d.History.exposure(history,q+a[:i],label)
            if entry is None: assert actual['classification']=='unseen' and actual['optimizer_exposures']==0
            else:
                same=entry['labels'].get(label,0);conflict=entry['count']-same
                assert actual['classification']==('mixed' if same and conflict else 'same_only' if same else 'conflict_only')
                assert actual['same_label_exposures']==same and actual['conflicting_label_exposures']==conflict
                assert actual['last_label']==entry['last_label'] and actual['first']==entry['first'] and actual['last']==entry['last']
assert not blocked and not forbidden
enabled=False
assert before=={path.name:sha(path.read_bytes()) for path in fresh.iterdir()}
for name,pin in manifest['source_hashes'].items(): assert sha((CODE/name).read_bytes())==pin
assert sha((PREREG/'input-manifest.json').read_bytes())==MANIFEST_SHA and sha((PREREG/'inputs.zip').read_bytes())==ZIP_SHA
engineering=read(WORK/'engineering/checks.json')
assert engineering['status']=='PASS' and engineering['tests']==7 and engineering['source_hashes']==manifest['source_hashes']
result={'status':'passed','input_manifest_sha256':MANIFEST_SHA,'inputs_zip_sha256':ZIP_SHA,
        'source_hashes':manifest['source_hashes'],'public_raw_checkpoint_pin_matches':6,'portable_zip_entries':25,
        'fresh_bundle_validation_original_roots_blocked':True,'independent_primary_history_traces':15,
        'six_snapshot_target_counts_and_complete_prefix_label_first_last_ledgers_exact':True,
        'query_prefix_exposure_readouts_verified_without_model':240,
        'own_and_future_both_correct_conditions_and_unit_counts':'source-reviewed;all pair logits reused from24 legal TFdata queries',
        'all_four_design_clarifications_implemented':True,'readonly_Model_hard_guards':'step/lesson/loss_grad/grow/trainingTrue denied;source reviewed and7synthetic tests passed',
        'material_findings_remaining':[],
        'report_wording_notes':['A future raw-invariant token can be wrong;use the paired-correct result.',
           'P033 already contained conditional sensitivity probes;claim only the new P030 paired-correct/exposure analysis.',
           'Never identify an internal copy algorithm from this closed8-value table or attribute the paired phase change uniquely to Neg.'],
        'trained_forward_calls':0,'optimizer_calls':0,'external_model_calls':0,
        'frozen_archive_and_core_source_unchanged':True,
        'original_workspace_files_scope':'Root separately checks25 originals before/after;this gate restores and validates the portable archive.',
        'local_method_freeze_sufficient_for_posthoc_readonly_audit':True}
with (HERE/'code-gate.json').open('x',encoding='utf-8',newline='\n') as stream:
    json.dump(result,stream,ensure_ascii=False,indent=2,allow_nan=False);stream.write('\n')
print(canonical({'status':'passed','input_manifest_sha256':MANIFEST_SHA,'zip_entries':25,
                 'trained_forward_calls':0,'optimizer_calls':0,'output':str(HERE/'code-gate.json')}))
